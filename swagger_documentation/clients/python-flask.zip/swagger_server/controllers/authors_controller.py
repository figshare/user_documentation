import connexion
from swagger_server.models.author import Author
from swagger_server.models.author_complete import AuthorComplete
from swagger_server.models.error_message import ErrorMessage
from swagger_server.models.private_authors_search import PrivateAuthorsSearch
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def private_author_details(author_id):
    """
    Author details
    View author details
    :param author_id: Author unique identifier
    :type author_id: int

    :rtype: AuthorComplete
    """
    return 'do some magic!'


def private_authors_search(search=None):
    """
    Search Authors
    Search for authors
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[Author]
    """
    if connexion.request.is_json:
        search = PrivateAuthorsSearch.from_dict(connexion.request.get_json())
    return 'do some magic!'
