import connexion
import six

from swagger_server.models.author import Author  # noqa: E501
from swagger_server.models.author_complete import AuthorComplete  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.private_authors_search import PrivateAuthorsSearch  # noqa: E501
from swagger_server import util


def private_author_details(author_id):  # noqa: E501
    """Author details

    View author details # noqa: E501

    :param author_id: Author unique identifier
    :type author_id: int

    :rtype: AuthorComplete
    """
    return 'do some magic!'


def private_authors_search(search=None):  # noqa: E501
    """Search Authors

    Search for authors # noqa: E501

    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[Author]
    """
    if connexion.request.is_json:
        search = PrivateAuthorsSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
