import connexion
from swagger_server.models.account_create import AccountCreate
from swagger_server.models.account_group_roles import AccountGroupRoles
from swagger_server.models.account_group_roles_create import AccountGroupRolesCreate
from swagger_server.models.account_update import AccountUpdate
from swagger_server.models.article import Article
from swagger_server.models.category import Category
from swagger_server.models.error_message import ErrorMessage
from swagger_server.models.group import Group
from swagger_server.models.institution import Institution
from swagger_server.models.institution_accounts_search import InstitutionAccountsSearch
from swagger_server.models.response_message import ResponseMessage
from swagger_server.models.role import Role
from swagger_server.models.short_account import ShortAccount
from swagger_server.models.user import User
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def institution_articles(institution_string_id, resource_id, filename):
    """
    Public Licenses
    Returns a list of articles belonging to the institution
    :param institution_string_id: 
    :type institution_string_id: str
    :param resource_id: 
    :type resource_id: str
    :param filename: 
    :type filename: str

    :rtype: List[Article]
    """
    return 'do some magic!'


def institution_hrfeed_upload(hrfeed=None):
    """
    Private Institution HRfeed Upload
    More info in the &lt;a href&#x3D;\&quot;#hr_feed\&quot;&gt;HR Feed section&lt;/a&gt;
    :param hrfeed: You can find an example in the Hr Feed section
    :type hrfeed: werkzeug.datastructures.FileStorage

    :rtype: ResponseMessage
    """
    return 'do some magic!'


def private_account_institution_user(account_id):
    """
    Private Account Institution User
    Retrieve institution user information using the account_id
    :param account_id: Account identifier the user is associated to
    :type account_id: int

    :rtype: User
    """
    return 'do some magic!'


def private_categories_list():
    """
    Private Account Categories
    List institution categories (including parent Categories)

    :rtype: List[Category]
    """
    return 'do some magic!'


def private_institution_account_group_role_delete(account_id, group_id, role_id):
    """
    Delete Institution Account Group Role
    Delete Institution Account Group Role
    :param account_id: Account identifier for which to remove the role
    :type account_id: int
    :param group_id: Group identifier for which to remove the role
    :type group_id: int
    :param role_id: Role identifier
    :type role_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_institution_account_group_roles(account_id):
    """
    List Institution Account Group Roles
    List Institution Account Group Roles
    :param account_id: Account identifier the user is associated to
    :type account_id: int

    :rtype: AccountGroupRoles
    """
    return 'do some magic!'


def private_institution_account_group_roles_create(account_id, Account):
    """
    Add Institution Account Group Roles
    Add Institution Account Group Roles
    :param account_id: Account identifier the user is associated to
    :type account_id: int
    :param Account: Account description
    :type Account: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Account = AccountGroupRolesCreate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_institution_accounts_create(Account):
    """
    Create new Institution Account
    Create a new Account by sending account information
    :param Account: Account description
    :type Account: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Account = AccountCreate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_institution_accounts_list(page=None, page_size=None, limit=None, offset=None, is_active=None, institution_user_id=None, email=None):
    """
    Private Account Institution Accounts
    Returns the accounts for which the account has administrative privileges (assigned and inherited).
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param is_active: Filter by active status
    :type is_active: int
    :param institution_user_id: Filter by institution_user_id
    :type institution_user_id: str
    :param email: Filter by email
    :type email: str

    :rtype: List[ShortAccount]
    """
    return 'do some magic!'


def private_institution_accounts_search(search):
    """
    Private Account Institution Accounts Search
    Returns the accounts for which the account has administrative privileges (assigned and inherited).
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[ShortAccount]
    """
    if connexion.request.is_json:
        search = InstitutionAccountsSearch.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_institution_accounts_update(account_id, Account):
    """
    Update Institution Account
    Update Institution Account
    :param account_id: Account identifier the user is associated to
    :type account_id: int
    :param Account: Account description
    :type Account: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Account = AccountUpdate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_institution_articles(page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, published_since=None, modified_since=None, status=None, resource_doi=None, item_type=None):
    """
    Private Institution Articles
    Get Articles from own institution. User must be administrator of the institution
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param published_since: Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
    :type published_since: str
    :param modified_since: Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
    :type modified_since: str
    :param status: only return collections with this status
    :type status: int
    :param resource_doi: only return collections with this resource_doi
    :type resource_doi: str
    :param item_type: Only return collections with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code, 11 - Metadata, 12 - Preprint
    :type item_type: int

    :rtype: List[Article]
    """
    return 'do some magic!'


def private_institution_details():
    """
    Private Account Institutions
    Account institution details

    :rtype: Institution
    """
    return 'do some magic!'


def private_institution_groups_list():
    """
    Private Account Institution Groups
    Returns the groups for which the account has administrative privileges (assigned and inherited).

    :rtype: List[Group]
    """
    return 'do some magic!'


def private_institution_roles_list():
    """
    Private Account Institution Roles
    Returns the roles available for groups and the institution group.

    :rtype: List[Role]
    """
    return 'do some magic!'
