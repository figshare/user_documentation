import connexion
from swagger_server.models.account import Account
from swagger_server.models.category import Category
from swagger_server.models.error_message import ErrorMessage
from swagger_server.models.funding_information import FundingInformation
from swagger_server.models.funding_search import FundingSearch
from swagger_server.models.item_type import ItemType
from swagger_server.models.license import License
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def categories_list():
    """
    Public Categories
    Returns a list of public categories

    :rtype: List[Category]
    """
    return 'do some magic!'


def file_download(file_id):
    """
    Public File Download
    Starts the download of a file
    :param file_id: 
    :type file_id: int

    :rtype: None
    """
    return 'do some magic!'


def item_types_list(group_id=None):
    """
    Item Types
    Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.
    :param group_id: Identifier of the group for which the item types are requested
    :type group_id: int

    :rtype: List[ItemType]
    """
    return 'do some magic!'


def licenses_list():
    """
    Public Licenses
    Returns a list of public licenses

    :rtype: List[License]
    """
    return 'do some magic!'


def private_account():
    """
    Private Account information
    Account information for token/personal token

    :rtype: Account
    """
    return 'do some magic!'


def private_funding_search(search=None):
    """
    Search Funding
    Search for fundings
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[FundingInformation]
    """
    if connexion.request.is_json:
        search = FundingSearch.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_licenses_list():
    """
    Private Account Licenses
    This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account&#39;s institution.

    :rtype: List[License]
    """
    return 'do some magic!'
