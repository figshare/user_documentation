import connexion
from swagger_server.models.article import Article
from swagger_server.models.article_create import ArticleCreate
from swagger_server.models.common_search import CommonSearch
from swagger_server.models.error_message import ErrorMessage
from swagger_server.models.location import Location
from swagger_server.models.private_file import PrivateFile
from swagger_server.models.project import Project
from swagger_server.models.project_article import ProjectArticle
from swagger_server.models.project_collaborator import ProjectCollaborator
from swagger_server.models.project_collaborator_invite import ProjectCollaboratorInvite
from swagger_server.models.project_complete import ProjectComplete
from swagger_server.models.project_complete_private import ProjectCompletePrivate
from swagger_server.models.project_create import ProjectCreate
from swagger_server.models.project_note import ProjectNote
from swagger_server.models.project_note_create import ProjectNoteCreate
from swagger_server.models.project_note_private import ProjectNotePrivate
from swagger_server.models.project_private import ProjectPrivate
from swagger_server.models.project_update import ProjectUpdate
from swagger_server.models.response_message import ResponseMessage
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def private_project_article_delete(project_id, article_id):
    """
    Delete project article
    Delete project article
    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_article_details(project_id, article_id):
    """
    Project article details
    Project article details
    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int

    :rtype: ProjectArticle
    """
    return 'do some magic!'


def private_project_article_file(project_id, article_id, file_id):
    """
    Project article file details
    Project article file details
    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int
    :param file_id: File unique identifier
    :type file_id: int

    :rtype: PrivateFile
    """
    return 'do some magic!'


def private_project_article_files(project_id, article_id):
    """
    Project article list files
    List article files
    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int

    :rtype: List[PrivateFile]
    """
    return 'do some magic!'


def private_project_articles_create(project_id, Article, page=None, page_size=None, limit=None, offset=None):
    """
    Create project article
    Create a new Article and associate it with this project
    :param project_id: Project unique identifier
    :type project_id: int
    :param Article: Article description
    :type Article: dict | bytes
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: Location
    """
    if connexion.request.is_json:
        Article = ArticleCreate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_project_articles_list(project_id, page=None, page_size=None, limit=None, offset=None):
    """
    List project articles
    List project articles
    :param project_id: Project unique identifier
    :type project_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: List[Article]
    """
    return 'do some magic!'


def private_project_collaborator_delete(project_id, user_id):
    """
    Remove project collaborator
    Remove project collaborator
    :param project_id: Project unique identifier
    :type project_id: int
    :param user_id: User unique identifier
    :type user_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_collaborators_invite(project_id, Collaborator):
    """
    Invite project collaborators
    Invite users to collaborate on project or view the project
    :param project_id: Project unique identifier
    :type project_id: int
    :param Collaborator: viewer or collaborator role. User user_id or email of user
    :type Collaborator: dict | bytes

    :rtype: ResponseMessage
    """
    if connexion.request.is_json:
        Collaborator = ProjectCollaboratorInvite.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_project_collaborators_list(project_id):
    """
    List project collaborators
    List Project collaborators and invited users
    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: List[ProjectCollaborator]
    """
    return 'do some magic!'


def private_project_create(Project):
    """
    Create project
    Create a new project
    :param Project: Project  description
    :type Project: dict | bytes

    :rtype: Location
    """
    if connexion.request.is_json:
        Project = ProjectCreate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_project_delete(project_id):
    """
    Delete project
    A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 
    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_details(project_id):
    """
    View project details
    View a private project
    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: ProjectCompletePrivate
    """
    return 'do some magic!'


def private_project_leave(project_id):
    """
    Private Project Leave
    Please note: project&#39;s owner cannot leave the project.
    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_note(project_id, note_id):
    """
    Project note details
    
    :param project_id: Project unique identifier
    :type project_id: int
    :param note_id: Note unique identifier
    :type note_id: int

    :rtype: ProjectNotePrivate
    """
    return 'do some magic!'


def private_project_note_delete(project_id, note_id):
    """
    Delete project note
    
    :param project_id: Project unique identifier
    :type project_id: int
    :param note_id: Note unique identifier
    :type note_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_project_note_update(project_id, note_id, Note):
    """
    Update project note
    
    :param project_id: Project unique identifier
    :type project_id: int
    :param note_id: Note unique identifier
    :type note_id: int
    :param Note: Note message
    :type Note: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Note = ProjectNoteCreate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_project_notes_create(project_id, Note):
    """
    Create project note
    Create a new project note
    :param project_id: Project unique identifier
    :type project_id: int
    :param Note: Note message
    :type Note: dict | bytes

    :rtype: Location
    """
    if connexion.request.is_json:
        Note = ProjectNoteCreate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_project_notes_list(project_id, page=None, page_size=None, limit=None, offset=None):
    """
    List project notes
    List project notes
    :param project_id: Project unique identifier
    :type project_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: List[ProjectNote]
    """
    return 'do some magic!'


def private_project_publish(project_id):
    """
    Private Project Publish
    Publish a project. Possible after all items inside it are public
    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: ResponseMessage
    """
    return 'do some magic!'


def private_project_update(project_id, Project):
    """
    Update project
    Updating an project by passing body parameters
    :param project_id: Project unique identifier
    :type project_id: int
    :param Project: Project description
    :type Project: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Project = ProjectUpdate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_projects_list(page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, storage=None, roles=None):
    """
    Private Projects
    List private projects
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param storage: only return collections from this institution
    :type storage: str
    :param roles: Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;.
    :type roles: str

    :rtype: List[ProjectPrivate]
    """
    return 'do some magic!'


def private_projects_search(search=None):
    """
    Private Projects search
    Search inside the private projects
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[ProjectPrivate]
    """
    if connexion.request.is_json:
        search = CommonSearch.from_dict(connexion.request.get_json())
    return 'do some magic!'


def project_articles(project_id):
    """
    Public Project Articles
    List articles in project
    :param project_id: Project Unique identifier
    :type project_id: int

    :rtype: List[Article]
    """
    return 'do some magic!'


def project_details(project_id):
    """
    Public Project
    View a project
    :param project_id: Project Unique identifier
    :type project_id: int

    :rtype: ProjectComplete
    """
    return 'do some magic!'


def projects_list(page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, institution=None, published_since=None, group=None):
    """
    Public Projects
    Returns a list of public projects
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param institution: only return collections from this institution
    :type institution: int
    :param published_since: Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
    :type published_since: str
    :param group: only return collections from this group
    :type group: int

    :rtype: List[Project]
    """
    return 'do some magic!'


def projects_search(search=None):
    """
    Public Projects Search
    Returns a list of public articles
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[Project]
    """
    if connexion.request.is_json:
        search = CommonSearch.from_dict(connexion.request.get_json())
    return 'do some magic!'
