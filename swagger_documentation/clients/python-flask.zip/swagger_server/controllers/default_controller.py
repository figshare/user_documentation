import connexion
from swagger_server.models.account_report import AccountReport
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def account_article_report_generate():
    """
    Initiate a new Report
    Initiate a new Article Report for this Account

    :rtype: AccountReport
    """
    return 'do some magic!'
