import connexion
from swagger_server.models.article import Article
from swagger_server.models.articles_creator import ArticlesCreator
from swagger_server.models.author import Author
from swagger_server.models.authors_creator import AuthorsCreator
from swagger_server.models.categories_creator import CategoriesCreator
from swagger_server.models.category import Category
from swagger_server.models.collection import Collection
from swagger_server.models.collection_complete import CollectionComplete
from swagger_server.models.collection_complete_private import CollectionCompletePrivate
from swagger_server.models.collection_create import CollectionCreate
from swagger_server.models.collection_doi import CollectionDOI
from swagger_server.models.collection_handle import CollectionHandle
from swagger_server.models.collection_private_link_creator import CollectionPrivateLinkCreator
from swagger_server.models.collection_search import CollectionSearch
from swagger_server.models.collection_update import CollectionUpdate
from swagger_server.models.collection_versions import CollectionVersions
from swagger_server.models.error_message import ErrorMessage
from swagger_server.models.location import Location
from swagger_server.models.location_warnings import LocationWarnings
from swagger_server.models.private_collection_search import PrivateCollectionSearch
from swagger_server.models.private_link import PrivateLink
from swagger_server.models.resource import Resource
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def collection_articles(collection_id, page=None, page_size=None, limit=None, offset=None):
    """
    Public Collection Articles
    Returns a list of public collection articles
    :param collection_id: Collection Unique identifier
    :type collection_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: List[Article]
    """
    return 'do some magic!'


def collection_details(collection_id):
    """
    Collection details
    View a collection
    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: CollectionComplete
    """
    return 'do some magic!'


def collection_version_details(collection_id, version_id):
    """
    Collection Version details
    View details for a certain version of a collection
    :param collection_id: Collection Unique identifier
    :type collection_id: int
    :param version_id: Version Number
    :type version_id: int

    :rtype: CollectionComplete
    """
    return 'do some magic!'


def collection_versions(collection_id):
    """
    Collection Versions list
    Returns a list of public collection Versions
    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: List[CollectionVersions]
    """
    return 'do some magic!'


def collections_list(page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, institution=None, published_since=None, modified_since=None, group=None, resource_doi=None, doi=None, handle=None):
    """
    Public Collections
    Returns a list of public collections
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param institution: only return collections from this institution
    :type institution: int
    :param published_since: Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
    :type published_since: str
    :param modified_since: Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
    :type modified_since: str
    :param group: only return collections from this group
    :type group: int
    :param resource_doi: only return collections with this resource_doi
    :type resource_doi: str
    :param doi: only return collections with this doi
    :type doi: str
    :param handle: only return collections with this handle
    :type handle: str

    :rtype: List[Collection]
    """
    return 'do some magic!'


def collections_search(search=None):
    """
    Public Collections Search
    Returns a list of public collections
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[Collection]
    """
    if connexion.request.is_json:
        search = CollectionSearch.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_article_delete(collection_id, article_id):
    """
    Delete collection article
    De-associate article from collection
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param article_id: Collection article unique identifier
    :type article_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_collection_articles_add(collection_id, articles):
    """
    Add collection articles
    Associate new articles with the collection. This will add new articles to the list of already associated articles
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param articles: Articles list
    :type articles: dict | bytes

    :rtype: Location
    """
    if connexion.request.is_json:
        articles = ArticlesCreator.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_articles_list(collection_id):
    """
    List collection articles
    List collection articles
    :param collection_id: Collection unique identifier
    :type collection_id: int

    :rtype: List[Article]
    """
    return 'do some magic!'


def private_collection_articles_replace(collection_id, articles):
    """
    Replace collection articles
    Associate new articles with the collection. This will remove all already associated articles and add these new ones
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param articles: Articles List
    :type articles: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        articles = ArticlesCreator.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_author_delete(collection_id, author_id):
    """
    Delete collection author
    Delete collection author
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param author_id: Collection Author unique identifier
    :type author_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_collection_authors_add(collection_id, Authors):
    """
    Add collection authors
    Associate new authors with the collection. This will add new authors to the list of already associated authors
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param Authors: List of authors
    :type Authors: dict | bytes

    :rtype: Location
    """
    if connexion.request.is_json:
        Authors = AuthorsCreator.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_authors_list(collection_id):
    """
    List collection authors
    List collection authors
    :param collection_id: Collection unique identifier
    :type collection_id: int

    :rtype: List[Author]
    """
    return 'do some magic!'


def private_collection_authors_replace(collection_id, Authors):
    """
    Replace collection authors
    Associate new authors with the collection. This will remove all already associated authors and add these new ones
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param Authors: List of authors
    :type Authors: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Authors = AuthorsCreator.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_categories_add(collection_id, categories):
    """
    Add collection categories
    Associate new categories with the collection. This will add new categories to the list of already associated categories
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param categories: Categories list
    :type categories: dict | bytes

    :rtype: Location
    """
    if connexion.request.is_json:
        categories = CategoriesCreator.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_categories_list(collection_id):
    """
    List collection categories
    List collection categories
    :param collection_id: Collection unique identifier
    :type collection_id: int

    :rtype: List[Category]
    """
    return 'do some magic!'


def private_collection_categories_replace(collection_id, categories):
    """
    Replace collection categories
    Associate new categories with the collection. This will remove all already associated categories and add these new ones
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param categories: Categories list
    :type categories: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        categories = CategoriesCreator.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_category_delete(collection_id, category_id):
    """
    Delete collection category
    De-associate category from collection
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param category_id: Collection category unique identifier
    :type category_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_collection_create(Collection):
    """
    Create collection
    Create a new Collection by sending collection information
    :param Collection: Collection description
    :type Collection: dict | bytes

    :rtype: LocationWarnings
    """
    if connexion.request.is_json:
        Collection = CollectionCreate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_delete(collection_id):
    """
    Delete collection
    Delete n collection
    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: None
    """
    return 'do some magic!'


def private_collection_details(collection_id):
    """
    Collection details
    View a collection
    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: CollectionCompletePrivate
    """
    return 'do some magic!'


def private_collection_private_link_create(collection_id, private_link=None):
    """
    Create collection private link
    Create new private link
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param private_link: 
    :type private_link: dict | bytes

    :rtype: Location
    """
    if connexion.request.is_json:
        private_link = CollectionPrivateLinkCreator.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_private_link_delete(collection_id, link_id):
    """
    Disable private link
    Disable/delete private link for this collection
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param link_id: Private link token
    :type link_id: str

    :rtype: None
    """
    return 'do some magic!'


def private_collection_private_link_update(collection_id, link_id, private_link=None):
    """
    Update collection private link
    Update existing private link for this collection
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param link_id: Private link token
    :type link_id: str
    :param private_link: 
    :type private_link: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        private_link = CollectionPrivateLinkCreator.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_private_links_list(collection_id):
    """
    List collection private links
    List article private links
    :param collection_id: Collection unique identifier
    :type collection_id: int

    :rtype: List[PrivateLink]
    """
    return 'do some magic!'


def private_collection_publish(collection_id):
    """
    Private Collection Publish
    When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.
    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: Location
    """
    return 'do some magic!'


def private_collection_reserve_doi(collection_id):
    """
    Private Collection Reserve DOI
    Reserve DOI for collection
    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: CollectionDOI
    """
    return 'do some magic!'


def private_collection_reserve_handle(collection_id):
    """
    Private Collection Reserve Handle
    Reserve Handle for collection
    :param collection_id: Collection Unique identifier
    :type collection_id: int

    :rtype: CollectionHandle
    """
    return 'do some magic!'


def private_collection_resource(collection_id, Resource):
    """
    Private Collection Resource
    Edit collection resource data.
    :param collection_id: Collection unique identifier
    :type collection_id: int
    :param Resource: Resource data
    :type Resource: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        Resource = Resource.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collection_update(collection_id, Collection):
    """
    Update collection
    Update collection details; request can also be made with the PATCH method.
    :param collection_id: Collection Unique identifier
    :type collection_id: int
    :param Collection: Collection description
    :type Collection: dict | bytes

    :rtype: LocationWarnings
    """
    if connexion.request.is_json:
        Collection = CollectionUpdate.from_dict(connexion.request.get_json())
    return 'do some magic!'


def private_collections_list(page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None):
    """
    Private Collections List
    List private collections
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing(the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str

    :rtype: List[Collection]
    """
    return 'do some magic!'


def private_collections_search(search):
    """
    Private Collections Search
    Returns a list of private Collections
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[Collection]
    """
    if connexion.request.is_json:
        search = PrivateCollectionSearch.from_dict(connexion.request.get_json())
    return 'do some magic!'
