# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.account_report import AccountReport
from swagger_server.models.article import Article
from swagger_server.models.article_complete import ArticleComplete
from swagger_server.models.article_complete_private import ArticleCompletePrivate
from swagger_server.models.article_confidentiality import ArticleConfidentiality
from swagger_server.models.article_create import ArticleCreate
from swagger_server.models.article_doi import ArticleDOI
from swagger_server.models.article_embargo import ArticleEmbargo
from swagger_server.models.article_embargo_updater import ArticleEmbargoUpdater
from swagger_server.models.article_handle import ArticleHandle
from swagger_server.models.article_metadata_reason import ArticleMetadataReason
from swagger_server.models.article_metadata_reason_updater import ArticleMetadataReasonUpdater
from swagger_server.models.article_search import ArticleSearch
from swagger_server.models.article_update import ArticleUpdate
from swagger_server.models.article_versions import ArticleVersions
from swagger_server.models.article_with_project import ArticleWithProject
from swagger_server.models.author import Author
from swagger_server.models.authors_creator import AuthorsCreator
from swagger_server.models.categories_creator import CategoriesCreator
from swagger_server.models.category import Category
from swagger_server.models.confidentiality_creator import ConfidentialityCreator
from swagger_server.models.error_message import ErrorMessage
from swagger_server.models.file_creator import FileCreator
from swagger_server.models.file_id import FileId
from swagger_server.models.location import Location
from swagger_server.models.location_warnings import LocationWarnings
from swagger_server.models.location_warnings_update import LocationWarningsUpdate
from swagger_server.models.private_article_search import PrivateArticleSearch
from swagger_server.models.private_file import PrivateFile
from swagger_server.models.private_link import PrivateLink
from swagger_server.models.private_link_creator import PrivateLinkCreator
from swagger_server.models.private_link_response import PrivateLinkResponse
from swagger_server.models.public_file import PublicFile
from swagger_server.models.resource import Resource
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestArticlesController(BaseTestCase):
    """ ArticlesController integration test stubs """

    def test_account_article_report(self):
        """
        Test case for account_article_report

        Account Article Report
        """
        query_string = [('group_id', 789)]
        response = self.client.open('/v2/account/articles/export',
                                    method='GET',
                                    query_string=query_string)
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_account_article_report_generate(self):
        """
        Test case for account_article_report_generate

        Initiate a new Report
        """
        response = self.client.open('/v2/account/articles/export',
                                    method='POST')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_article_details(self):
        """
        Test case for article_details

        View article details
        """
        response = self.client.open('/v2/articles/{article_id}'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_article_file_details(self):
        """
        Test case for article_file_details

        Article file details
        """
        response = self.client.open('/v2/articles/{article_id}/files/{file_id}'.format(article_id=2, file_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_article_files(self):
        """
        Test case for article_files

        List article files
        """
        response = self.client.open('/v2/articles/{article_id}/files'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_article_version_confidentiality(self):
        """
        Test case for article_version_confidentiality

        Public Article Confidentiality for article version
        """
        response = self.client.open('/v2/articles/{article_id}/versions/{v_number}/confidentiality'.format(article_id=2, v_number=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_article_version_details(self):
        """
        Test case for article_version_details

        Article details for version
        """
        response = self.client.open('/v2/articles/{article_id}/versions/{v_number}'.format(article_id=2, v_number=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_article_version_embargo(self):
        """
        Test case for article_version_embargo

        Public Article Embargo for article version
        """
        response = self.client.open('/v2/articles/{article_id}/versions/{v_number}/embargo'.format(article_id=2, v_number=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_article_version_update(self):
        """
        Test case for article_version_update

        Update article version
        """
        Article = ArticleUpdate()
        response = self.client.open('/v2/account/articles/{article_id}/versions/{version_id}/'.format(article_id=2, version_id=2),
                                    method='PUT',
                                    data=json.dumps(Article),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_article_version_update_thumb(self):
        """
        Test case for article_version_update_thumb

        Update article version thumbnail
        """
        FileId = FileId()
        response = self.client.open('/v2/account/articles/{article_id}/versions/{version_id}/update_thumb'.format(article_id=2, version_id=2),
                                    method='PUT',
                                    data=json.dumps(FileId),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_article_versions(self):
        """
        Test case for article_versions

        List article versions
        """
        response = self.client.open('/v2/articles/{article_id}/versions'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_articles_list(self):
        """
        Test case for articles_list

        Public Articles
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000),
                        ('order', 'published_date'),
                        ('order_direction', 'desc'),
                        ('institution', 789),
                        ('published_since', 'published_since_example'),
                        ('modified_since', 'modified_since_example'),
                        ('group', 789),
                        ('resource_doi', 'resource_doi_example'),
                        ('item_type', 789),
                        ('doi', 'doi_example'),
                        ('handle', 'handle_example')]
        response = self.client.open('/v2/articles',
                                    method='GET',
                                    query_string=query_string)
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_articles_search(self):
        """
        Test case for articles_search

        Public Articles Search
        """
        search = ArticleSearch()
        response = self.client.open('/v2/articles/search',
                                    method='POST',
                                    data=json.dumps(search),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_author_delete(self):
        """
        Test case for private_article_author_delete

        Delete article author
        """
        response = self.client.open('/v2/account/articles/{article_id}/authors/{author_id}'.format(article_id=2, author_id=2),
                                    method='DELETE')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_authors_add(self):
        """
        Test case for private_article_authors_add

        Add article authors
        """
        Authors = AuthorsCreator()
        response = self.client.open('/v2/account/articles/{article_id}/authors'.format(article_id=2),
                                    method='POST',
                                    data=json.dumps(Authors),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_authors_list(self):
        """
        Test case for private_article_authors_list

        List article authors
        """
        response = self.client.open('/v2/account/articles/{article_id}/authors'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_authors_replace(self):
        """
        Test case for private_article_authors_replace

        Replace article authors
        """
        Authors = AuthorsCreator()
        response = self.client.open('/v2/account/articles/{article_id}/authors'.format(article_id=2),
                                    method='PUT',
                                    data=json.dumps(Authors),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_categories_add(self):
        """
        Test case for private_article_categories_add

        Add article categories
        """
        categories = CategoriesCreator()
        response = self.client.open('/v2/account/articles/{article_id}/categories'.format(article_id=2),
                                    method='POST',
                                    data=json.dumps(categories),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_categories_list(self):
        """
        Test case for private_article_categories_list

        List article categories
        """
        response = self.client.open('/v2/account/articles/{article_id}/categories'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_categories_replace(self):
        """
        Test case for private_article_categories_replace

        Replace article categories
        """
        categories = CategoriesCreator()
        response = self.client.open('/v2/account/articles/{article_id}/categories'.format(article_id=2),
                                    method='PUT',
                                    data=json.dumps(categories),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_category_delete(self):
        """
        Test case for private_article_category_delete

        Delete article category
        """
        response = self.client.open('/v2/account/articles/{article_id}/categories/{category_id}'.format(article_id=2, category_id=2),
                                    method='DELETE')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_confidentiality_delete(self):
        """
        Test case for private_article_confidentiality_delete

        Delete article confidentiality
        """
        response = self.client.open('/v2/account/articles/{article_id}/confidentiality'.format(article_id=2),
                                    method='DELETE')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_confidentiality_details(self):
        """
        Test case for private_article_confidentiality_details

        Article confidentiality details
        """
        response = self.client.open('/v2/account/articles/{article_id}/confidentiality'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_confidentiality_update(self):
        """
        Test case for private_article_confidentiality_update

        Update article confidentiality
        """
        reason = ConfidentialityCreator()
        response = self.client.open('/v2/account/articles/{article_id}/confidentiality'.format(article_id=2),
                                    method='PUT',
                                    data=json.dumps(reason),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_create(self):
        """
        Test case for private_article_create

        Create new Article
        """
        Article = ArticleCreate()
        response = self.client.open('/v2/account/articles',
                                    method='POST',
                                    data=json.dumps(Article),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_delete(self):
        """
        Test case for private_article_delete

        Delete article
        """
        response = self.client.open('/v2/account/articles/{article_id}'.format(article_id=2),
                                    method='DELETE')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_details(self):
        """
        Test case for private_article_details

        Article details
        """
        response = self.client.open('/v2/account/articles/{article_id}'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_embargo_delete(self):
        """
        Test case for private_article_embargo_delete

        Delete Article Embargo
        """
        response = self.client.open('/v2/account/articles/{article_id}/embargo'.format(article_id=2),
                                    method='DELETE')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_embargo_details(self):
        """
        Test case for private_article_embargo_details

        Article Embargo Details
        """
        response = self.client.open('/v2/account/articles/{article_id}/embargo'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_embargo_update(self):
        """
        Test case for private_article_embargo_update

        Update Article Embargo
        """
        Embargo = ArticleEmbargoUpdater()
        response = self.client.open('/v2/account/articles/{article_id}/embargo'.format(article_id=2),
                                    method='PUT',
                                    data=json.dumps(Embargo),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_file(self):
        """
        Test case for private_article_file

        Single File
        """
        response = self.client.open('/v2/account/articles/{article_id}/files/{file_id}'.format(article_id=2, file_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_file_delete(self):
        """
        Test case for private_article_file_delete

        File Delete
        """
        response = self.client.open('/v2/account/articles/{article_id}/files/{file_id}'.format(article_id=2, file_id=2),
                                    method='DELETE')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_files_list(self):
        """
        Test case for private_article_files_list

        List article files
        """
        response = self.client.open('/v2/account/articles/{article_id}/files'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_metadata_reason_details(self):
        """
        Test case for private_article_metadata_reason_details

        Article Metadata Reason Details
        """
        response = self.client.open('/v2/account/articles/{article_id}/metadata_reason'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_metadata_reason_update(self):
        """
        Test case for private_article_metadata_reason_update

        Update Article Metadata Reason
        """
        Metadata_Reason = ArticleMetadataReasonUpdater()
        response = self.client.open('/v2/account/articles/{article_id}/metadata_reason'.format(article_id=2),
                                    method='PUT',
                                    data=json.dumps(Metadata_Reason),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_private_link(self):
        """
        Test case for private_article_private_link

        List private links
        """
        response = self.client.open('/v2/account/articles/{article_id}/private_links'.format(article_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_private_link_create(self):
        """
        Test case for private_article_private_link_create

        Create private link
        """
        private_link = PrivateLinkCreator()
        response = self.client.open('/v2/account/articles/{article_id}/private_links'.format(article_id=2),
                                    method='POST',
                                    data=json.dumps(private_link),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_private_link_delete(self):
        """
        Test case for private_article_private_link_delete

        Disable private link
        """
        response = self.client.open('/v2/account/articles/{article_id}/private_links/{link_id}'.format(article_id=2, link_id='link_id_example'),
                                    method='DELETE')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_private_link_update(self):
        """
        Test case for private_article_private_link_update

        Update private link
        """
        private_link = PrivateLinkCreator()
        response = self.client.open('/v2/account/articles/{article_id}/private_links/{link_id}'.format(article_id=2, link_id='link_id_example'),
                                    method='PUT',
                                    data=json.dumps(private_link),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_publish(self):
        """
        Test case for private_article_publish

        Private Article Publish
        """
        response = self.client.open('/v2/account/articles/{article_id}/publish'.format(article_id=2),
                                    method='POST')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_reserve_doi(self):
        """
        Test case for private_article_reserve_doi

        Private Article Reserve DOI
        """
        response = self.client.open('/v2/account/articles/{article_id}/reserve_doi'.format(article_id=2),
                                    method='POST')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_reserve_handle(self):
        """
        Test case for private_article_reserve_handle

        Private Article Reserve Handle
        """
        response = self.client.open('/v2/account/articles/{article_id}/reserve_handle'.format(article_id=2),
                                    method='POST')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_resource(self):
        """
        Test case for private_article_resource

        Private Article Resource
        """
        Resource = Resource()
        response = self.client.open('/v2/account/articles/{article_id}/resource'.format(article_id=2),
                                    method='POST',
                                    data=json.dumps(Resource),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_update(self):
        """
        Test case for private_article_update

        Update article
        """
        Article = ArticleUpdate()
        response = self.client.open('/v2/account/articles/{article_id}'.format(article_id=2),
                                    method='PUT',
                                    data=json.dumps(Article),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_upload_complete(self):
        """
        Test case for private_article_upload_complete

        Complete Upload
        """
        response = self.client.open('/v2/account/articles/{article_id}/files/{file_id}'.format(article_id=2, file_id=2),
                                    method='POST')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_article_upload_initiate(self):
        """
        Test case for private_article_upload_initiate

        Initiate Upload
        """
        File = FileCreator()
        response = self.client.open('/v2/account/articles/{article_id}/files'.format(article_id=2),
                                    method='POST',
                                    data=json.dumps(File),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_articles_list(self):
        """
        Test case for private_articles_list

        Private Articles
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000)]
        response = self.client.open('/v2/account/articles',
                                    method='GET',
                                    query_string=query_string)
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_articles_search(self):
        """
        Test case for private_articles_search

        Private Articles search
        """
        search = PrivateArticleSearch()
        response = self.client.open('/v2/account/articles/search',
                                    method='POST',
                                    data=json.dumps(search),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
