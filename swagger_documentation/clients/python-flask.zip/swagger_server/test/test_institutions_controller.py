# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.article import Article
from swagger_server.models.category import Category
from swagger_server.models.error_message import ErrorMessage
from swagger_server.models.group import Group
from swagger_server.models.institution import Institution
from swagger_server.models.institution_accounts_search import InstitutionAccountsSearch
from swagger_server.models.response_message import ResponseMessage
from swagger_server.models.short_account import ShortAccount
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestInstitutionsController(BaseTestCase):
    """ InstitutionsController integration test stubs """

    def test_institution_articles(self):
        """
        Test case for institution_articles

        Public Licenses
        """
        query_string = [('resource_id', 'resource_id_example'),
                        ('filename', 'filename_example')]
        response = self.client.open('/v2/institutions/{institution_string_id}/articles/filter-by'.format(institution_string_id='institution_string_id_example'),
                                    method='GET',
                                    query_string=query_string)
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_institution_hrfeed_upload(self):
        """
        Test case for institution_hrfeed_upload

        Private Institution HRfeed Upload
        """
        data = dict(hrfeed=(BytesIO(b'some file data'), 'file.txt'))
        response = self.client.open('/v2/institution/hrfeed/upload',
                                    method='POST',
                                    data=data,
                                    content_type='multipart/form-data')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_categories_list(self):
        """
        Test case for private_categories_list

        Private Account Categories
        """
        response = self.client.open('/v2/account/categories',
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_institution_accounts_list(self):
        """
        Test case for private_institution_accounts_list

        Private Account Institution Accounts
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000),
                        ('is_active', 1)]
        response = self.client.open('/v2/account/institution/accounts',
                                    method='GET',
                                    query_string=query_string)
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_institution_accounts_search(self):
        """
        Test case for private_institution_accounts_search

        Private Account Institution Accounts Search
        """
        search = InstitutionAccountsSearch()
        response = self.client.open('/v2/account/institution/accounts/search',
                                    method='POST',
                                    data=json.dumps(search),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_institution_articles(self):
        """
        Test case for private_institution_articles

        Private Institution Articles
        """
        query_string = [('page', 5000),
                        ('page_size', 1000),
                        ('limit', 1000),
                        ('offset', 5000),
                        ('order', 'published_date'),
                        ('order_direction', 'desc'),
                        ('published_since', 'published_since_example'),
                        ('modified_since', 'modified_since_example'),
                        ('status', 789),
                        ('resource_doi', 'resource_doi_example'),
                        ('item_type', 12)]
        response = self.client.open('/v2/account/institution/articles',
                                    method='GET',
                                    query_string=query_string)
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_institution_details(self):
        """
        Test case for private_institution_details

        Private Account Institutions
        """
        response = self.client.open('/v2/account/institution',
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_institution_groups_list(self):
        """
        Test case for private_institution_groups_list

        Private Account Institution Groups
        """
        response = self.client.open('/v2/account/institution/groups',
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
