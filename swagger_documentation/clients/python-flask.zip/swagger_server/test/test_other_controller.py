# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.account import Account
from swagger_server.models.category import Category
from swagger_server.models.error_message import ErrorMessage
from swagger_server.models.funding_information import FundingInformation
from swagger_server.models.funding_search import FundingSearch
from swagger_server.models.license import License
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestOtherController(BaseTestCase):
    """ OtherController integration test stubs """

    def test_categories_list(self):
        """
        Test case for categories_list

        Public Categories
        """
        response = self.client.open('/v2/categories',
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_file_download(self):
        """
        Test case for file_download

        Public File Download
        """
        response = self.client.open('/v2/file/download/{file_id}'.format(file_id=2),
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_licenses_list(self):
        """
        Test case for licenses_list

        Public Licenses
        """
        response = self.client.open('/v2/licenses',
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_account(self):
        """
        Test case for private_account

        Private Account information
        """
        response = self.client.open('/v2/account',
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_funding_search(self):
        """
        Test case for private_funding_search

        Search Funding
        """
        search = FundingSearch()
        response = self.client.open('/v2/account/funding/search',
                                    method='POST',
                                    data=json.dumps(search),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_private_licenses_list(self):
        """
        Test case for private_licenses_list

        Private Account Licenses
        """
        response = self.client.open('/v2/account/licenses',
                                    method='GET')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
