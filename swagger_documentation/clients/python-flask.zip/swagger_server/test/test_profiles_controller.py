# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.profile_update_data import ProfileUpdateData  # noqa: E501
from swagger_server.test import BaseTestCase


class TestProfilesController(BaseTestCase):
    """ProfilesController integration test stubs"""

    def test_update_user_profile(self):
        """Test case for update_user_profile

        Update public profile
        """
        User_profile_data = ProfileUpdateData()
        response = self.client.open(
            '/v2/account/profile/{user_id}'.format(user_id=2),
            method='PUT',
            data=json.dumps(User_profile_data),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_user_profile_picture(self):
        """Test case for update_user_profile_picture

        Update public profile picture
        """
        data = dict(profile_picture=(BytesIO(b'some file data'), 'file.txt'))
        response = self.client.open(
            '/v2/account/profile/{user_id}/picture'.format(user_id=2),
            method='POST',
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
