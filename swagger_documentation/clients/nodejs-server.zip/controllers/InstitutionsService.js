'use strict';

exports.institution_articles = function(args, res, next) {
  /**
   * Public Licenses
   * Returns a list of articles belonging to the institution
   *
   * institution_string_id String 
   * resource_id String 
   * filename String 
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "defined_type" : 3,
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "title" : "Test article title",
  "url" : "http://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.institution_hrfeed_upload = function(args, res, next) {
  /**
   * Private Institution HRfeed Upload
   * More info in the <a href=\"#hr_feed\">HR Feed section</a>
   *
   * hrfeed File You can find an example in the Hr Feed section (optional)
   * returns ResponseMessage
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "Project 1 has been published"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_categories_list = function(args, res, next) {
  /**
   * Private Account Categories
   * List institution categories (including parent Categories)
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "parent_id" : 1,
  "id" : 11,
  "title" : "Anatomy"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_accounts_list = function(args, res, next) {
  /**
   * Private Account Institution Accounts
   * Returns the accounts for which the account has administrative privileges (assigned and inherited).
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * is_active Long Filter by active status (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "last_name" : "John",
  "active" : 0,
  "id" : 1495682,
  "first_name" : "Doe",
  "email" : "user@domain.com",
  "institution_id" : 1
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_accounts_search = function(args, res, next) {
  /**
   * Private Account Institution Accounts Search
   * Returns the accounts for which the account has administrative privileges (assigned and inherited).
   *
   * search InstitutionAccountsSearch Search Parameters
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "last_name" : "John",
  "active" : 0,
  "id" : 1495682,
  "first_name" : "Doe",
  "email" : "user@domain.com",
  "institution_id" : 1
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_articles = function(args, res, next) {
  /**
   * Private Institution Articles
   * Get Articles from own institution. User must be administrator of the institution
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * order String The field by which to order. Default varies by endpoint/resource. (optional)
   * order_direction String  (optional)
   * published_since String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
   * modified_since String Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
   * status Long only return collections with this status (optional)
   * resource_doi String only return collections with this resource_doi (optional)
   * item_type Long Only return collections with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code, 12 - Preprint (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "defined_type" : 3,
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "title" : "Test article title",
  "url" : "http://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_details = function(args, res, next) {
  /**
   * Private Account Institutions
   * Account institution details
   *
   * returns Institution
   **/
  var examples = {};
  examples['application/json'] = {
  "name" : "Institution",
  "id" : 0
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_groups_list = function(args, res, next) {
  /**
   * Private Account Institution Groups
   * Returns the groups for which the account has administrative privileges (assigned and inherited).
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "parent_id" : 0,
  "name" : "Materials",
  "resource_id" : "",
  "id" : 1
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

