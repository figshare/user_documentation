'use strict';

exports.account_institution_curation = function(args, res, next) {
  /**
   * Institution Curation Review
   * Retrieve a certain curation review by its ID
   *
   * curation_id Long ID of the curation
   * returns CurationDetail
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.account_institution_curation_comments = function(args, res, next) {
  /**
   * Institution Curation Review Comments
   * Retrieve a certain curation review's comments.
   *
   * curation_id Long ID of the curation
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * returns CurationComment
   **/
  var examples = {};
  examples['application/json'] = {
  "account_id" : 6,
  "id" : 0,
  "text" : "aeiou",
  "type" : "comment"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.account_institution_curation_comments_0 = function(args, res, next) {
  /**
   * POST Institution Curation Review Comment
   * Add a new comment to the review.
   *
   * curation_id Long ID of the curation
   * curationComment CurationCommentCreate The content/value of the comment.
   * no response value expected for this operation
   **/
  res.end();
}

exports.account_institution_curations = function(args, res, next) {
  /**
   * Institution Curation Reviews
   * Retrieve a list of curation reviews for this institution
   *
   * group_id Long Filter by the group ID (optional)
   * article_id Long Retrieve the reviews for this article (optional)
   * status String Filter by the status of the review (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * returns Curation
   **/
  var examples = {};
  examples['application/json'] = {
  "article_id" : 5,
  "account_id" : 1,
  "group_id" : 6,
  "comments_count" : 7,
  "id" : 0,
  "created_date" : "aeiou",
  "modified_date" : "aeiou",
  "version" : 2,
  "assigned_to" : 5,
  "status" : "pending"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.institution_articles = function(args, res, next) {
  /**
   * Public Licenses
   * Returns a list of articles belonging to the institution
   *
   * institution_string_id String 
   * resource_id String 
   * filename String 
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/media/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "handle" : "111184/figshare.1234",
  "title" : "Test article title",
  "defined_type_name" : "media",
  "url" : "http://api.figshare.com/articles/1434614",
  "defined_type" : 3,
  "timeline" : "",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.institution_hrfeed_upload = function(args, res, next) {
  /**
   * Private Institution HRfeed Upload
   * More info in the <a href=\"#hr_feed\">HR Feed section</a>
   *
   * hrfeed File You can find an example in the Hr Feed section (optional)
   * returns ResponseMessage
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "Project 1 has been published"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_account_institution_user = function(args, res, next) {
  /**
   * Private Account Institution User
   * Retrieve institution user information using the account_id
   *
   * account_id Long Account identifier the user is associated to
   * returns User
   **/
  var examples = {};
  examples['application/json'] = {
  "orcid_id" : "1234-5678-9123-1234",
  "url_name" : "John_Doe",
  "is_active" : true,
  "name" : "John Doe",
  "is_public" : true,
  "last_name" : "John",
  "id" : 1495682,
  "first_name" : "Doe",
  "job_title" : "programmer"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_categories_list = function(args, res, next) {
  /**
   * Private Account Categories
   * List institution categories (including parent Categories)
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "parent_id" : 1,
  "id" : 11,
  "title" : "Anatomy"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_group_embargo_options_details = function(args, res, next) {
  /**
   * Private Account Institution Group Embargo Options
   * Account institution group embargo options details
   *
   * group_id Long Group identifier
   * returns GroupEmbargoOptions
   **/
  var examples = {};
  examples['application/json'] = {
  "ip_name" : "Figshare IP range",
  "id" : 364,
  "type" : "ip_range"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_account_group_role_delete = function(args, res, next) {
  /**
   * Delete Institution Account Group Role
   * Delete Institution Account Group Role
   *
   * account_id Long Account identifier for which to remove the role
   * group_id Long Group identifier for which to remove the role
   * role_id Long Role identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_institution_account_group_roles = function(args, res, next) {
  /**
   * List Institution Account Group Roles
   * List Institution Account Group Roles
   *
   * account_id Long Account identifier the user is associated to
   * returns AccountGroupRoles
   **/
  var examples = {};
  examples['application/json'] = {
  "2" : [ {
    "category" : "group",
    "id" : 7,
    "name" : "User"
  } ]
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_account_group_roles_create = function(args, res, next) {
  /**
   * Add Institution Account Group Roles
   * Add Institution Account Group Roles
   *
   * account_id Long Account identifier the user is associated to
   * account AccountGroupRolesCreate Account description
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_institution_accounts_create = function(args, res, next) {
  /**
   * Create new Institution Account
   * Create a new Account by sending account information
   *
   * account AccountCreate Account description
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_institution_accounts_list = function(args, res, next) {
  /**
   * Private Account Institution Accounts
   * Returns the accounts for which the account has administrative privileges (assigned and inherited).
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * is_active Long Filter by active status (optional)
   * institution_user_id String Filter by institution_user_id (optional)
   * email String Filter by email (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "institution_user_id" : "1",
  "last_name" : "John",
  "active" : 0,
  "id" : 1495682,
  "first_name" : "Doe",
  "email" : "user@domain.com",
  "institution_id" : 1
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_accounts_search = function(args, res, next) {
  /**
   * Private Account Institution Accounts Search
   * Returns the accounts for which the account has administrative privileges (assigned and inherited).
   *
   * search InstitutionAccountsSearch Search Parameters
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "institution_user_id" : "1",
  "last_name" : "John",
  "active" : 0,
  "id" : 1495682,
  "first_name" : "Doe",
  "email" : "user@domain.com",
  "institution_id" : 1
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_accounts_update = function(args, res, next) {
  /**
   * Update Institution Account
   * Update Institution Account
   *
   * account_id Long Account identifier the user is associated to
   * account AccountUpdate Account description
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_institution_articles = function(args, res, next) {
  /**
   * Private Institution Articles
   * Get Articles from own institution. User must be administrator of the institution
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * order String The field by which to order. Default varies by endpoint/resource. (optional)
   * order_direction String  (optional)
   * published_since String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
   * modified_since String Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
   * status Long only return collections with this status (optional)
   * resource_doi String only return collections with this resource_doi (optional)
   * item_type Long Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/media/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "handle" : "111184/figshare.1234",
  "title" : "Test article title",
  "defined_type_name" : "media",
  "url" : "http://api.figshare.com/articles/1434614",
  "defined_type" : 3,
  "timeline" : "",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_details = function(args, res, next) {
  /**
   * Private Account Institutions
   * Account institution details
   *
   * returns Institution
   **/
  var examples = {};
  examples['application/json'] = {
  "name" : "Institution",
  "id" : 0
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_embargo_options_details = function(args, res, next) {
  /**
   * Private Account Institution embargo options
   * Account institution embargo options details
   *
   * returns GroupEmbargoOptions
   **/
  var examples = {};
  examples['application/json'] = {
  "ip_name" : "Figshare IP range",
  "id" : 364,
  "type" : "ip_range"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_groups_list = function(args, res, next) {
  /**
   * Private Account Institution Groups
   * Returns the groups for which the account has administrative privileges (assigned and inherited).
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "association_criteria" : "IT",
  "parent_id" : 0,
  "name" : "Materials",
  "resource_id" : "",
  "id" : 1
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_institution_roles_list = function(args, res, next) {
  /**
   * Private Account Institution Roles
   * Returns the roles available for groups and the institution group.
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "name" : "Curator",
  "description" : "aeiou",
  "id" : 1,
  "category" : "group"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

