'use strict';

var url = require('url');

var Collections = require('./CollectionsService');

module.exports.collection_articles = function collection_articles (req, res, next) {
  Collections.collection_articles(req.swagger.params, res, next);
};

module.exports.collection_details = function collection_details (req, res, next) {
  Collections.collection_details(req.swagger.params, res, next);
};

module.exports.collection_version_details = function collection_version_details (req, res, next) {
  Collections.collection_version_details(req.swagger.params, res, next);
};

module.exports.collection_versions = function collection_versions (req, res, next) {
  Collections.collection_versions(req.swagger.params, res, next);
};

module.exports.collections_list = function collections_list (req, res, next) {
  Collections.collections_list(req.swagger.params, res, next);
};

module.exports.collections_search = function collections_search (req, res, next) {
  Collections.collections_search(req.swagger.params, res, next);
};

module.exports.private_collection_article_delete = function private_collection_article_delete (req, res, next) {
  Collections.private_collection_article_delete(req.swagger.params, res, next);
};

module.exports.private_collection_articles_add = function private_collection_articles_add (req, res, next) {
  Collections.private_collection_articles_add(req.swagger.params, res, next);
};

module.exports.private_collection_articles_list = function private_collection_articles_list (req, res, next) {
  Collections.private_collection_articles_list(req.swagger.params, res, next);
};

module.exports.private_collection_articles_replace = function private_collection_articles_replace (req, res, next) {
  Collections.private_collection_articles_replace(req.swagger.params, res, next);
};

module.exports.private_collection_author_delete = function private_collection_author_delete (req, res, next) {
  Collections.private_collection_author_delete(req.swagger.params, res, next);
};

module.exports.private_collection_authors_add = function private_collection_authors_add (req, res, next) {
  Collections.private_collection_authors_add(req.swagger.params, res, next);
};

module.exports.private_collection_authors_list = function private_collection_authors_list (req, res, next) {
  Collections.private_collection_authors_list(req.swagger.params, res, next);
};

module.exports.private_collection_authors_replace = function private_collection_authors_replace (req, res, next) {
  Collections.private_collection_authors_replace(req.swagger.params, res, next);
};

module.exports.private_collection_categories_add = function private_collection_categories_add (req, res, next) {
  Collections.private_collection_categories_add(req.swagger.params, res, next);
};

module.exports.private_collection_categories_list = function private_collection_categories_list (req, res, next) {
  Collections.private_collection_categories_list(req.swagger.params, res, next);
};

module.exports.private_collection_categories_replace = function private_collection_categories_replace (req, res, next) {
  Collections.private_collection_categories_replace(req.swagger.params, res, next);
};

module.exports.private_collection_category_delete = function private_collection_category_delete (req, res, next) {
  Collections.private_collection_category_delete(req.swagger.params, res, next);
};

module.exports.private_collection_create = function private_collection_create (req, res, next) {
  Collections.private_collection_create(req.swagger.params, res, next);
};

module.exports.private_collection_delete = function private_collection_delete (req, res, next) {
  Collections.private_collection_delete(req.swagger.params, res, next);
};

module.exports.private_collection_details = function private_collection_details (req, res, next) {
  Collections.private_collection_details(req.swagger.params, res, next);
};

module.exports.private_collection_private_link_create = function private_collection_private_link_create (req, res, next) {
  Collections.private_collection_private_link_create(req.swagger.params, res, next);
};

module.exports.private_collection_private_link_delete = function private_collection_private_link_delete (req, res, next) {
  Collections.private_collection_private_link_delete(req.swagger.params, res, next);
};

module.exports.private_collection_private_link_update = function private_collection_private_link_update (req, res, next) {
  Collections.private_collection_private_link_update(req.swagger.params, res, next);
};

module.exports.private_collection_private_links_list = function private_collection_private_links_list (req, res, next) {
  Collections.private_collection_private_links_list(req.swagger.params, res, next);
};

module.exports.private_collection_publish = function private_collection_publish (req, res, next) {
  Collections.private_collection_publish(req.swagger.params, res, next);
};

module.exports.private_collection_reserve_doi = function private_collection_reserve_doi (req, res, next) {
  Collections.private_collection_reserve_doi(req.swagger.params, res, next);
};

module.exports.private_collection_update = function private_collection_update (req, res, next) {
  Collections.private_collection_update(req.swagger.params, res, next);
};

module.exports.private_collections_list = function private_collections_list (req, res, next) {
  Collections.private_collections_list(req.swagger.params, res, next);
};

module.exports.private_collections_search = function private_collections_search (req, res, next) {
  Collections.private_collections_search(req.swagger.params, res, next);
};
