'use strict';

var url = require('url');

var Institutions = require('./InstitutionsService');

module.exports.institution_articles = function institution_articles (req, res, next) {
  Institutions.institution_articles(req.swagger.params, res, next);
};

module.exports.institution_hrfeed_upload = function institution_hrfeed_upload (req, res, next) {
  Institutions.institution_hrfeed_upload(req.swagger.params, res, next);
};

module.exports.private_account_institution_user = function private_account_institution_user (req, res, next) {
  Institutions.private_account_institution_user(req.swagger.params, res, next);
};

module.exports.private_categories_list = function private_categories_list (req, res, next) {
  Institutions.private_categories_list(req.swagger.params, res, next);
};

module.exports.private_institution_account_group_role_delete = function private_institution_account_group_role_delete (req, res, next) {
  Institutions.private_institution_account_group_role_delete(req.swagger.params, res, next);
};

module.exports.private_institution_account_group_roles = function private_institution_account_group_roles (req, res, next) {
  Institutions.private_institution_account_group_roles(req.swagger.params, res, next);
};

module.exports.private_institution_account_group_roles_create = function private_institution_account_group_roles_create (req, res, next) {
  Institutions.private_institution_account_group_roles_create(req.swagger.params, res, next);
};

module.exports.private_institution_accounts_create = function private_institution_accounts_create (req, res, next) {
  Institutions.private_institution_accounts_create(req.swagger.params, res, next);
};

module.exports.private_institution_accounts_list = function private_institution_accounts_list (req, res, next) {
  Institutions.private_institution_accounts_list(req.swagger.params, res, next);
};

module.exports.private_institution_accounts_search = function private_institution_accounts_search (req, res, next) {
  Institutions.private_institution_accounts_search(req.swagger.params, res, next);
};

module.exports.private_institution_accounts_update = function private_institution_accounts_update (req, res, next) {
  Institutions.private_institution_accounts_update(req.swagger.params, res, next);
};

module.exports.private_institution_articles = function private_institution_articles (req, res, next) {
  Institutions.private_institution_articles(req.swagger.params, res, next);
};

module.exports.private_institution_details = function private_institution_details (req, res, next) {
  Institutions.private_institution_details(req.swagger.params, res, next);
};

module.exports.private_institution_groups_list = function private_institution_groups_list (req, res, next) {
  Institutions.private_institution_groups_list(req.swagger.params, res, next);
};

module.exports.private_institution_roles_list = function private_institution_roles_list (req, res, next) {
  Institutions.private_institution_roles_list(req.swagger.params, res, next);
};
