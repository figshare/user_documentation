'use strict';

var url = require('url');

var Other = require('./OtherService');

module.exports.categories_list = function categories_list (req, res, next) {
  Other.categories_list(req.swagger.params, res, next);
};

module.exports.file_download = function file_download (req, res, next) {
  Other.file_download(req.swagger.params, res, next);
};

module.exports.licenses_list = function licenses_list (req, res, next) {
  Other.licenses_list(req.swagger.params, res, next);
};

module.exports.private_account = function private_account (req, res, next) {
  Other.private_account(req.swagger.params, res, next);
};

module.exports.private_licenses_list = function private_licenses_list (req, res, next) {
  Other.private_licenses_list(req.swagger.params, res, next);
};
