'use strict';

var url = require('url');

var Authors = require('./AuthorsService');

module.exports.private_author_details = function private_author_details (req, res, next) {
  Authors.private_author_details(req.swagger.params, res, next);
};

module.exports.private_authors_search = function private_authors_search (req, res, next) {
  Authors.private_authors_search(req.swagger.params, res, next);
};
