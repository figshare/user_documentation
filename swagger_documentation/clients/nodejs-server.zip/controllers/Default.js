'use strict';

var url = require('url');

var Default = require('./DefaultService');

module.exports.account_article_report_generate = function account_article_report_generate (req, res, next) {
  Default.account_article_report_generate(req.swagger.params, res, next);
};
