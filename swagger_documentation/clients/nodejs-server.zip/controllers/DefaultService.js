'use strict';

exports.account_article_report_generate = function(args, res, next) {
  /**
   * Initiate a new Report
   * Initiate a new Article Report for this Account
   *
   * returns AccountReport
   **/
  var examples = {};
  examples['application/json'] = {
  "account_id" : 6,
  "group_id" : 1,
  "download_url" : "https://some.com/storage/path/123/report-456.xlsx",
  "id" : 0,
  "created_date" : "2017-05-15T15:12:26Z",
  "status" : "missing"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

