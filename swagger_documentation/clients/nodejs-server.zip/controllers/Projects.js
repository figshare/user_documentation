'use strict';

var url = require('url');

var Projects = require('./ProjectsService');

module.exports.private_project_article_delete = function private_project_article_delete (req, res, next) {
  Projects.private_project_article_delete(req.swagger.params, res, next);
};

module.exports.private_project_article_details = function private_project_article_details (req, res, next) {
  Projects.private_project_article_details(req.swagger.params, res, next);
};

module.exports.private_project_article_file = function private_project_article_file (req, res, next) {
  Projects.private_project_article_file(req.swagger.params, res, next);
};

module.exports.private_project_article_files = function private_project_article_files (req, res, next) {
  Projects.private_project_article_files(req.swagger.params, res, next);
};

module.exports.private_project_articles_create = function private_project_articles_create (req, res, next) {
  Projects.private_project_articles_create(req.swagger.params, res, next);
};

module.exports.private_project_articles_list = function private_project_articles_list (req, res, next) {
  Projects.private_project_articles_list(req.swagger.params, res, next);
};

module.exports.private_project_collaborator__Delete = function private_project_collaborator__Delete (req, res, next) {
  Projects.private_project_collaborator__Delete(req.swagger.params, res, next);
};

module.exports.private_project_collaborators_invite = function private_project_collaborators_invite (req, res, next) {
  Projects.private_project_collaborators_invite(req.swagger.params, res, next);
};

module.exports.private_project_collaborators_list = function private_project_collaborators_list (req, res, next) {
  Projects.private_project_collaborators_list(req.swagger.params, res, next);
};

module.exports.private_project_create = function private_project_create (req, res, next) {
  Projects.private_project_create(req.swagger.params, res, next);
};

module.exports.private_project_delete = function private_project_delete (req, res, next) {
  Projects.private_project_delete(req.swagger.params, res, next);
};

module.exports.private_project_details = function private_project_details (req, res, next) {
  Projects.private_project_details(req.swagger.params, res, next);
};

module.exports.private_project_leave = function private_project_leave (req, res, next) {
  Projects.private_project_leave(req.swagger.params, res, next);
};

module.exports.private_project_note = function private_project_note (req, res, next) {
  Projects.private_project_note(req.swagger.params, res, next);
};

module.exports.private_project_note_delete = function private_project_note_delete (req, res, next) {
  Projects.private_project_note_delete(req.swagger.params, res, next);
};

module.exports.private_project_note_update = function private_project_note_update (req, res, next) {
  Projects.private_project_note_update(req.swagger.params, res, next);
};

module.exports.private_project_notes_create = function private_project_notes_create (req, res, next) {
  Projects.private_project_notes_create(req.swagger.params, res, next);
};

module.exports.private_project_notes_list = function private_project_notes_list (req, res, next) {
  Projects.private_project_notes_list(req.swagger.params, res, next);
};

module.exports.private_project_publish = function private_project_publish (req, res, next) {
  Projects.private_project_publish(req.swagger.params, res, next);
};

module.exports.private_project_update = function private_project_update (req, res, next) {
  Projects.private_project_update(req.swagger.params, res, next);
};

module.exports.private_projects_list = function private_projects_list (req, res, next) {
  Projects.private_projects_list(req.swagger.params, res, next);
};

module.exports.private_projects_search = function private_projects_search (req, res, next) {
  Projects.private_projects_search(req.swagger.params, res, next);
};

module.exports.project_articles = function project_articles (req, res, next) {
  Projects.project_articles(req.swagger.params, res, next);
};

module.exports.project_details = function project_details (req, res, next) {
  Projects.project_details(req.swagger.params, res, next);
};

module.exports.projects_list = function projects_list (req, res, next) {
  Projects.projects_list(req.swagger.params, res, next);
};

module.exports.projects_search = function projects_search (req, res, next) {
  Projects.projects_search(req.swagger.params, res, next);
};
