'use strict';

exports.collection_articles = function(args, res, next) {
  /**
   * Public Collection Articles
   * Returns a list of public collection articles
   *
   * collection_id Long Collection Unique identifier
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/media/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "handle" : "111184/figshare.1234",
  "title" : "Test article title",
  "defined_type_name" : "media",
  "url" : "http://api.figshare.com/articles/1434614",
  "defined_type" : 3,
  "timeline" : "",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.collection_details = function(args, res, next) {
  /**
   * Collection details
   * View a collection
   *
   * collection_id Long Collection Unique identifier
   * returns CollectionComplete
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.collection_version_details = function(args, res, next) {
  /**
   * Collection Version details
   * View details for a certain version of a collection
   *
   * collection_id Long Collection Unique identifier
   * version_id Long Version Number
   * returns CollectionComplete
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.collection_versions = function(args, res, next) {
  /**
   * Collection Versions list
   * Returns a list of public collection Versions
   *
   * collection_id Long Collection Unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "id" : 1,
  "url" : "https://api.figshare.com/v2/collections/2000005/versions/1"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.collections_list = function(args, res, next) {
  /**
   * Public Collections
   * Returns a list of public collections
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * order String The field by which to order. Default varies by endpoint/resource. (optional)
   * order_direction String  (optional)
   * institution Long only return collections from this institution (optional)
   * published_since String Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD (optional)
   * modified_since String Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD (optional)
   * group Long only return collections from this group (optional)
   * resource_doi String only return collections with this resource_doi (optional)
   * doi String only return collections with this doi (optional)
   * handle String only return collections with this handle (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "handle" : "111184/figshare.1234",
  "id" : 123,
  "title" : "Sample collection",
  "url" : "https://api.figshare.com/v2/collections/123",
  "doi" : "10.6084/m9.figshare.123"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.collections_search = function(args, res, next) {
  /**
   * Public Collections Search
   * Returns a list of public collections
   *
   * search CollectionSearch Search Parameters (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "handle" : "111184/figshare.1234",
  "id" : 123,
  "title" : "Sample collection",
  "url" : "https://api.figshare.com/v2/collections/123",
  "doi" : "10.6084/m9.figshare.123"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_article_delete = function(args, res, next) {
  /**
   * Delete collection article
   * De-associate article from collection
   *
   * collection_id Long Collection unique identifier
   * article_id Long Collection article unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collection_articles_add = function(args, res, next) {
  /**
   * Add collection articles
   * Associate new articles with the collection. This will add new articles to the list of already associated articles
   *
   * collection_id Long Collection unique identifier
   * articles ArticlesCreator Articles list
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_articles_list = function(args, res, next) {
  /**
   * List collection articles
   * List collection articles
   *
   * collection_id Long Collection unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/media/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "handle" : "111184/figshare.1234",
  "title" : "Test article title",
  "defined_type_name" : "media",
  "url" : "http://api.figshare.com/articles/1434614",
  "defined_type" : 3,
  "timeline" : "",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_articles_replace = function(args, res, next) {
  /**
   * Replace collection articles
   * Associate new articles with the collection. This will remove all already associated articles and add these new ones
   *
   * collection_id Long Collection unique identifier
   * articles ArticlesCreator Articles List
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collection_author_delete = function(args, res, next) {
  /**
   * Delete collection author
   * Delete collection author
   *
   * collection_id Long Collection unique identifier
   * author_id Long Collection Author unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collection_authors_add = function(args, res, next) {
  /**
   * Add collection authors
   * Associate new authors with the collection. This will add new authors to the list of already associated authors
   *
   * collection_id Long Collection unique identifier
   * authors AuthorsCreator List of authors
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_authors_list = function(args, res, next) {
  /**
   * List collection authors
   * List collection authors
   *
   * collection_id Long Collection unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "orcid_id" : "1234-5678-9123-1234",
  "url_name" : "John_Doe",
  "full_name" : "John Doe",
  "is_active" : false,
  "id" : 97657
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_authors_replace = function(args, res, next) {
  /**
   * Replace collection authors
   * Associate new authors with the collection. This will remove all already associated authors and add these new ones
   *
   * collection_id Long Collection unique identifier
   * authors AuthorsCreator List of authors
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collection_categories_add = function(args, res, next) {
  /**
   * Add collection categories
   * Associate new categories with the collection. This will add new categories to the list of already associated categories
   *
   * collection_id Long Collection unique identifier
   * categories CategoriesCreator Categories list
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_categories_list = function(args, res, next) {
  /**
   * List collection categories
   * List collection categories
   *
   * collection_id Long Collection unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "parent_id" : 1,
  "id" : 11,
  "title" : "Anatomy"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_categories_replace = function(args, res, next) {
  /**
   * Replace collection categories
   * Associate new categories with the collection. This will remove all already associated categories and add these new ones
   *
   * collection_id Long Collection unique identifier
   * categories CategoriesCreator Categories list
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collection_category_delete = function(args, res, next) {
  /**
   * Delete collection category
   * De-associate category from collection
   *
   * collection_id Long Collection unique identifier
   * category_id Long Collection category unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collection_create = function(args, res, next) {
  /**
   * Create collection
   * Create a new Collection by sending collection information
   *
   * collection CollectionCreate Collection description
   * returns CollectionComplete
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_delete = function(args, res, next) {
  /**
   * Delete collection
   * Delete n collection
   *
   * collection_id Long Collection Unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collection_details = function(args, res, next) {
  /**
   * Collection details
   * View a collection
   *
   * collection_id Long Collection Unique identifier
   * returns CollectionComplete
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_private_link_create = function(args, res, next) {
  /**
   * Create collection private link
   * Create new private link
   *
   * collection_id Long Collection unique identifier
   * private_link CollectionPrivateLinkCreator  (optional)
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_private_link_delete = function(args, res, next) {
  /**
   * Disable private link
   * Disable/delete private link for this collection
   *
   * collection_id Long Collection unique identifier
   * link_id String Private link token
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collection_private_link_update = function(args, res, next) {
  /**
   * Update collection private link
   * Update existing private link for this collection
   *
   * collection_id Long Collection unique identifier
   * link_id String Private link token
   * private_link CollectionPrivateLinkCreator  (optional)
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collection_private_links_list = function(args, res, next) {
  /**
   * List collection private links
   * List article private links
   *
   * collection_id Long Collection unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "is_active" : true,
  "expires_date" : "2015-07-03T00:00:00",
  "id" : "0cfb0dbeac92df445df4aba45f63fdc85fa0b9a888b64e157ce3c93b576aa300fb3621ef3a219515dd482"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_publish = function(args, res, next) {
  /**
   * Private Collection Publish
   * When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.
   *
   * collection_id Long Collection Unique identifier
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_reserve_doi = function(args, res, next) {
  /**
   * Private Collection Reserve DOI
   * Reserve DOI for collection
   *
   * collection_id Long Collection Unique identifier
   * returns CollectionDOI
   **/
  var examples = {};
  examples['application/json'] = {
  "doi" : "10.5072/FK2.FIGSHARE.20345"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_reserve_handle = function(args, res, next) {
  /**
   * Private Collection Reserve Handle
   * Reserve Handle for collection
   *
   * collection_id Long Collection Unique identifier
   * returns CollectionHandle
   **/
  var examples = {};
  examples['application/json'] = {
  "handle" : "11172/FK2.FIGSHARE.20345"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collection_update = function(args, res, next) {
  /**
   * Update collection
   * Update collection details
   *
   * collection_id Long Collection Unique identifier
   * collection CollectionUpdate Collection description
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_collections_list = function(args, res, next) {
  /**
   * Private Collections List
   * List private collections
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * order String The field by which to order. Default varies by endpoint/resource. (optional)
   * order_direction String  (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "handle" : "111184/figshare.1234",
  "id" : 123,
  "title" : "Sample collection",
  "url" : "https://api.figshare.com/v2/collections/123",
  "doi" : "10.6084/m9.figshare.123"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_collections_search = function(args, res, next) {
  /**
   * Private Collections Search
   * Returns a list of private Collections
   *
   * search PrivateCollectionSearch Search Parameters
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "handle" : "111184/figshare.1234",
  "id" : 123,
  "title" : "Sample collection",
  "url" : "https://api.figshare.com/v2/collections/123",
  "doi" : "10.6084/m9.figshare.123"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

