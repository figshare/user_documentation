'use strict';

exports.account_article_report = function(args, res, next) {
  /**
   * Account Article Report
   * Return status on all reports generated for the account from the oauth credentials
   *
   * group_id Long A group ID to filter by (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "account_id" : 6,
  "group_id" : 1,
  "download_url" : "https://some.com/storage/path/123/report-456.xlsx",
  "id" : 0,
  "created_date" : "2017-05-15T15:12:26Z",
  "status" : "missing"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.account_article_report_generate = function(args, res, next) {
  /**
   * Initiate a new Report
   * Initiate a new Article Report for this Account
   *
   * returns AccountReport
   **/
  var examples = {};
  examples['application/json'] = {
  "account_id" : 6,
  "group_id" : 1,
  "download_url" : "https://some.com/storage/path/123/report-456.xlsx",
  "id" : 0,
  "created_date" : "2017-05-15T15:12:26Z",
  "status" : "missing"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.article_details = function(args, res, next) {
  /**
   * View article details
   * View an article
   *
   * article_id Long Article Unique identifier
   * returns ArticleComplete
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.article_file_details = function(args, res, next) {
  /**
   * Article file details
   * File by id
   *
   * article_id Long Article Unique identifier
   * file_id Long File Unique identifier
   * returns PublicFile
   **/
  var examples = {};
  examples['application/json'] = {
  "size" : 14848,
  "supplied_md5" : "043a51806d646e88cafbf19e7b82846f",
  "name" : "test.xls",
  "download_url" : "https://ndownloader.figshare.com/files/3000002",
  "computed_md5" : "043a51806d646e88cafbf19e7b82846f",
  "id" : 3000002,
  "is_link_only" : false
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.article_files = function(args, res, next) {
  /**
   * List article files
   * Files list for article
   *
   * article_id Long Article Unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "size" : 14848,
  "supplied_md5" : "043a51806d646e88cafbf19e7b82846f",
  "name" : "test.xls",
  "download_url" : "https://ndownloader.figshare.com/files/3000002",
  "computed_md5" : "043a51806d646e88cafbf19e7b82846f",
  "id" : 3000002,
  "is_link_only" : false
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.article_version_confidentiality = function(args, res, next) {
  /**
   * Public Article Confidentiality for article version
   * Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
   *
   * article_id Long Article Unique identifier
   * v_number Long Version Number
   * returns ArticleConfidentiality
   **/
  var examples = {};
  examples['application/json'] = {
  "reason" : "need to",
  "is_confidential" : true
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.article_version_details = function(args, res, next) {
  /**
   * Article details for version
   * Article with specified version
   *
   * article_id Long Article Unique identifier
   * v_number Long Article Version Number
   * returns ArticleComplete
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.article_version_embargo = function(args, res, next) {
  /**
   * Public Article Embargo for article version
   * Embargo for article version
   *
   * article_id Long Article Unique identifier
   * v_number Long Version Number
   * returns ArticleEmbargo
   **/
  var examples = {};
  examples['application/json'] = {
  "is_embargoed" : true,
  "embargo_title" : "File(s) under embargo",
  "embargo_reason" : "",
  "embargo_options" : [ {
    "id" : 13,
    "type" : "ip_range",
    "group_ids" : [ ],
    "ip_name" : "bacau"
  }, {
    "id" : 12,
    "type" : "logged_in",
    "ip_name" : "",
    "group_ids" : [ 550, 9448 ]
  } ]
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.article_version_update = function(args, res, next) {
  /**
   * Update article version
   * Updating an article version by passing body parameters; request can also be made with the PATCH method.
   *
   * article_id Long Article unique identifier
   * version_id Long Article version identifier
   * article ArticleUpdate Article description
   * returns LocationWarningsUpdate
   **/
  var examples = {};
  examples['application/json'] = {
  "warnings" : [ "aeiou" ],
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.article_version_update_thumb = function(args, res, next) {
  /**
   * Update article version thumbnail
   * For a given public article version update the article thumbnail by choosing one of the associated files
   *
   * article_id Long Article unique identifier
   * version_id Long Article version identifier
   * fileId FileId File ID
   * no response value expected for this operation
   **/
  res.end();
}

exports.article_versions = function(args, res, next) {
  /**
   * List article versions
   * List public article versions
   *
   * article_id Long Article Unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "version" : 1,
  "url" : "https://api.figshare.com/v2/articles/2000005/versions/1"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.articles_list = function(args, res, next) {
  /**
   * Public Articles
   * Returns a list of public articles
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * order String The field by which to order. Default varies by endpoint/resource. (optional)
   * order_direction String  (optional)
   * institution Long only return articles from this institution (optional)
   * published_since String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
   * modified_since String Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
   * group Long only return articles from this group (optional)
   * resource_doi String only return articles with this resource_doi (optional)
   * item_type Long Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
   * doi String only return articles with this doi (optional)
   * handle String only return articles with this handle (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/media/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "handle" : "111184/figshare.1234",
  "title" : "Test article title",
  "defined_type_name" : "media",
  "url" : "http://api.figshare.com/articles/1434614",
  "defined_type" : 3,
  "timeline" : "",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.articles_search = function(args, res, next) {
  /**
   * Public Articles Search
   * Returns a list of public articles, filtered by the search parameters
   *
   * search ArticleSearch Search Parameters (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ "" ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_author_delete = function(args, res, next) {
  /**
   * Delete article author
   * De-associate author from article
   *
   * article_id Long Article unique identifier
   * author_id Long Article Author unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_authors_add = function(args, res, next) {
  /**
   * Add article authors
   * Associate new authors with the article. This will add new authors to the list of already associated authors
   *
   * article_id Long Article unique identifier
   * authors AuthorsCreator Authors description
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_authors_list = function(args, res, next) {
  /**
   * List article authors
   * List article authors
   *
   * article_id Long Article unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "orcid_id" : "1234-5678-9123-1234",
  "url_name" : "John_Doe",
  "full_name" : "John Doe",
  "is_active" : false,
  "id" : 97657
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_authors_replace = function(args, res, next) {
  /**
   * Replace article authors
   * Associate new authors with the article. This will remove all already associated authors and add these new ones
   *
   * article_id Long Article unique identifier
   * authors AuthorsCreator Authors description
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_categories_add = function(args, res, next) {
  /**
   * Add article categories
   * Associate new categories with the article. This will add new categories to the list of already associated categories
   *
   * article_id Long Article unique identifier
   * categories CategoriesCreator 
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_categories_list = function(args, res, next) {
  /**
   * List article categories
   * List article categories
   *
   * article_id Long Article unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "path" : "/450/1024/6532",
  "taxonomy_id" : 4,
  "parent_id" : 1,
  "id" : 11,
  "source_id" : "300204",
  "title" : "Anatomy"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_categories_replace = function(args, res, next) {
  /**
   * Replace article categories
   * Associate new categories with the article. This will remove all already associated categories and add these new ones
   *
   * article_id Long Article unique identifier
   * categories CategoriesCreator 
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_category_delete = function(args, res, next) {
  /**
   * Delete article category
   * De-associate category from article
   *
   * article_id Long Article unique identifier
   * category_id Long Category unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_confidentiality_delete = function(args, res, next) {
  /**
   * Delete article confidentiality
   * Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
   *
   * article_id Long Article unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_confidentiality_details = function(args, res, next) {
  /**
   * Article confidentiality details
   * View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
   *
   * article_id Long Article unique identifier
   * returns ArticleConfidentiality
   **/
  var examples = {};
  examples['application/json'] = {
  "reason" : "need to",
  "is_confidential" : true
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_confidentiality_update = function(args, res, next) {
  /**
   * Update article confidentiality
   * Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
   *
   * article_id Long Article unique identifier
   * reason ConfidentialityCreator 
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_create = function(args, res, next) {
  /**
   * Create new Article
   * Create a new Article by sending article information
   *
   * article ArticleCreate Article description
   * returns LocationWarnings
   **/
  var examples = {};
  examples['application/json'] = {
  "warnings" : [ "aeiou" ],
  "location" : "http://example.com/aeiou",
  "entity_id" : 33334444
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_delete = function(args, res, next) {
  /**
   * Delete article
   * Delete an article
   *
   * article_id Long Article unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_details = function(args, res, next) {
  /**
   * Article details
   * View a private article
   *
   * article_id Long Article unique identifier
   * returns ArticleCompletePrivate
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_embargo_delete = function(args, res, next) {
  /**
   * Delete Article Embargo
   * Will lift the embargo for the specified article
   *
   * article_id Long Article unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_embargo_details = function(args, res, next) {
  /**
   * Article Embargo Details
   * View a private article embargo details
   *
   * article_id Long Article unique identifier
   * returns ArticleEmbargo
   **/
  var examples = {};
  examples['application/json'] = {
  "is_embargoed" : true,
  "embargo_title" : "File(s) under embargo",
  "embargo_reason" : "",
  "embargo_options" : [ {
    "id" : 13,
    "type" : "ip_range",
    "group_ids" : [ ],
    "ip_name" : "bacau"
  }, {
    "id" : 12,
    "type" : "logged_in",
    "ip_name" : "",
    "group_ids" : [ 550, 9448 ]
  } ]
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_embargo_update = function(args, res, next) {
  /**
   * Update Article Embargo
   * Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.
   *
   * article_id Long Article unique identifier
   * embargo ArticleEmbargoUpdater Embargo description
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_file = function(args, res, next) {
  /**
   * Single File
   * View details of file for specified article
   *
   * article_id Long Article unique identifier
   * file_id Long File unique identifier
   * returns PrivateFile
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_file_delete = function(args, res, next) {
  /**
   * File Delete
   * Complete file upload
   *
   * article_id Long Article unique identifier
   * file_id Long File unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_files_list = function(args, res, next) {
  /**
   * List article files
   * List private files
   *
   * article_id Long Article unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ "" ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_metadata_reason_details = function(args, res, next) {
  /**
   * Article Metadata Reason Details
   * View a private article's metadata reason
   *
   * article_id Long Article unique identifier
   * returns ArticleMetadataReason
   **/
  var examples = {};
  examples['application/json'] = {
  "is_metadata_record" : true
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_metadata_reason_update = function(args, res, next) {
  /**
   * Update Article Metadata Reason
   * Set the metadata reason for the specified article
   *
   * article_id Long Article unique identifier
   * metadata Reason ArticleMetadataReasonUpdater Metadata Reason
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_private_link = function(args, res, next) {
  /**
   * List private links
   * List private links
   *
   * article_id Long Article unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "is_active" : true,
  "html_location" : "https://figshare.com/s/d5ec7a85bcd6dbe9d9b2",
  "expires_date" : "2015-07-03T00:00:00",
  "id" : "0cfb0dbeac92df445df4aba45f63fdc85fa0b9a888b64e157ce3c93b576aa300fb3621ef3a219515dd482"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_private_link_create = function(args, res, next) {
  /**
   * Create private link
   * Create new private link for this article
   *
   * article_id Long Article unique identifier
   * private_link PrivateLinkCreator  (optional)
   * returns PrivateLinkResponse
   **/
  var examples = {};
  examples['application/json'] = {
  "html_location" : "https://figshare.com/s/d5ec7a85bcd6dbe9d9b2",
  "location" : "http://example.com/aeiou",
  "token" : "d5ec7a85bcd6dbe9d9b2"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_private_link_delete = function(args, res, next) {
  /**
   * Disable private link
   * Disable/delete private link for this article
   *
   * article_id Long Article unique identifier
   * link_id String Private link token
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_private_link_update = function(args, res, next) {
  /**
   * Update private link
   * Update existing private link for this article
   *
   * article_id Long Article unique identifier
   * link_id String Private link token
   * private_link PrivateLinkCreator  (optional)
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_publish = function(args, res, next) {
  /**
   * Private Article Publish
   * - If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.
   *
   * article_id Long Article unique identifier
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_reserve_doi = function(args, res, next) {
  /**
   * Private Article Reserve DOI
   * Reserve DOI for article
   *
   * article_id Long Article unique identifier
   * returns ArticleDOI
   **/
  var examples = {};
  examples['application/json'] = {
  "doi" : "10.5072/FK2.FIGSHARE.20345"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_reserve_handle = function(args, res, next) {
  /**
   * Private Article Reserve Handle
   * Reserve Handle for article
   *
   * article_id Long Article unique identifier
   * returns ArticleHandle
   **/
  var examples = {};
  examples['application/json'] = {
  "handle" : "11172/FK2.FIGSHARE.20345"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_resource = function(args, res, next) {
  /**
   * Private Article Resource
   * Edit article resource data.
   *
   * article_id Long Article unique identifier
   * resource Resource Resource data
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_update = function(args, res, next) {
  /**
   * Update article
   * Updating an article by passing body parameters; request can also be made with the PATCH method.
   *
   * article_id Long Article unique identifier
   * article ArticleUpdate Article description
   * returns LocationWarningsUpdate
   **/
  var examples = {};
  examples['application/json'] = {
  "warnings" : [ "aeiou" ],
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_article_upload_complete = function(args, res, next) {
  /**
   * Complete Upload
   * Complete file upload
   *
   * article_id Long Article unique identifier
   * file_id Long File unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_article_upload_initiate = function(args, res, next) {
  /**
   * Initiate Upload
   * Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).
   *
   * article_id Long Article unique identifier
   * file FileCreator 
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_articles_list = function(args, res, next) {
  /**
   * Private Articles
   * Get Own Articles
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/media/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "handle" : "111184/figshare.1234",
  "title" : "Test article title",
  "defined_type_name" : "media",
  "url" : "http://api.figshare.com/articles/1434614",
  "defined_type" : 3,
  "timeline" : "",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_articles_search = function(args, res, next) {
  /**
   * Private Articles search
   * Returns a list of private articles filtered by the search parameters
   *
   * search PrivateArticleSearch Search Parameters
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ "" ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

