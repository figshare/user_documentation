'use strict';

var url = require('url');

var Articles = require('./ArticlesService');

module.exports.article_details = function article_details (req, res, next) {
  Articles.article_details(req.swagger.params, res, next);
};

module.exports.article_file_details = function article_file_details (req, res, next) {
  Articles.article_file_details(req.swagger.params, res, next);
};

module.exports.article_files = function article_files (req, res, next) {
  Articles.article_files(req.swagger.params, res, next);
};

module.exports.article_version_confidentiality = function article_version_confidentiality (req, res, next) {
  Articles.article_version_confidentiality(req.swagger.params, res, next);
};

module.exports.article_version_details = function article_version_details (req, res, next) {
  Articles.article_version_details(req.swagger.params, res, next);
};

module.exports.article_version_embargo = function article_version_embargo (req, res, next) {
  Articles.article_version_embargo(req.swagger.params, res, next);
};

module.exports.article_versions = function article_versions (req, res, next) {
  Articles.article_versions(req.swagger.params, res, next);
};

module.exports.articles_list = function articles_list (req, res, next) {
  Articles.articles_list(req.swagger.params, res, next);
};

module.exports.articles_search = function articles_search (req, res, next) {
  Articles.articles_search(req.swagger.params, res, next);
};

module.exports.private_article_author_delete = function private_article_author_delete (req, res, next) {
  Articles.private_article_author_delete(req.swagger.params, res, next);
};

module.exports.private_article_authors_add = function private_article_authors_add (req, res, next) {
  Articles.private_article_authors_add(req.swagger.params, res, next);
};

module.exports.private_article_authors_list = function private_article_authors_list (req, res, next) {
  Articles.private_article_authors_list(req.swagger.params, res, next);
};

module.exports.private_article_authors_replace = function private_article_authors_replace (req, res, next) {
  Articles.private_article_authors_replace(req.swagger.params, res, next);
};

module.exports.private_article_categories_add = function private_article_categories_add (req, res, next) {
  Articles.private_article_categories_add(req.swagger.params, res, next);
};

module.exports.private_article_categories_list = function private_article_categories_list (req, res, next) {
  Articles.private_article_categories_list(req.swagger.params, res, next);
};

module.exports.private_article_categories_replace = function private_article_categories_replace (req, res, next) {
  Articles.private_article_categories_replace(req.swagger.params, res, next);
};

module.exports.private_article_category_delete = function private_article_category_delete (req, res, next) {
  Articles.private_article_category_delete(req.swagger.params, res, next);
};

module.exports.private_article_confidentiality_delete = function private_article_confidentiality_delete (req, res, next) {
  Articles.private_article_confidentiality_delete(req.swagger.params, res, next);
};

module.exports.private_article_confidentiality_details = function private_article_confidentiality_details (req, res, next) {
  Articles.private_article_confidentiality_details(req.swagger.params, res, next);
};

module.exports.private_article_confidentiality_update = function private_article_confidentiality_update (req, res, next) {
  Articles.private_article_confidentiality_update(req.swagger.params, res, next);
};

module.exports.private_article_create = function private_article_create (req, res, next) {
  Articles.private_article_create(req.swagger.params, res, next);
};

module.exports.private_article_delete = function private_article_delete (req, res, next) {
  Articles.private_article_delete(req.swagger.params, res, next);
};

module.exports.private_article_details = function private_article_details (req, res, next) {
  Articles.private_article_details(req.swagger.params, res, next);
};

module.exports.private_article_embargo_delete = function private_article_embargo_delete (req, res, next) {
  Articles.private_article_embargo_delete(req.swagger.params, res, next);
};

module.exports.private_article_embargo_details = function private_article_embargo_details (req, res, next) {
  Articles.private_article_embargo_details(req.swagger.params, res, next);
};

module.exports.private_article_embargo_update = function private_article_embargo_update (req, res, next) {
  Articles.private_article_embargo_update(req.swagger.params, res, next);
};

module.exports.private_article_file = function private_article_file (req, res, next) {
  Articles.private_article_file(req.swagger.params, res, next);
};

module.exports.private_article_file_delete = function private_article_file_delete (req, res, next) {
  Articles.private_article_file_delete(req.swagger.params, res, next);
};

module.exports.private_article_files_list = function private_article_files_list (req, res, next) {
  Articles.private_article_files_list(req.swagger.params, res, next);
};

module.exports.private_article_private_link = function private_article_private_link (req, res, next) {
  Articles.private_article_private_link(req.swagger.params, res, next);
};

module.exports.private_article_private_link_create = function private_article_private_link_create (req, res, next) {
  Articles.private_article_private_link_create(req.swagger.params, res, next);
};

module.exports.private_article_private_link_delete = function private_article_private_link_delete (req, res, next) {
  Articles.private_article_private_link_delete(req.swagger.params, res, next);
};

module.exports.private_article_private_link_update = function private_article_private_link_update (req, res, next) {
  Articles.private_article_private_link_update(req.swagger.params, res, next);
};

module.exports.private_article_publish = function private_article_publish (req, res, next) {
  Articles.private_article_publish(req.swagger.params, res, next);
};

module.exports.private_article_reserve_doi = function private_article_reserve_doi (req, res, next) {
  Articles.private_article_reserve_doi(req.swagger.params, res, next);
};

module.exports.private_article_update = function private_article_update (req, res, next) {
  Articles.private_article_update(req.swagger.params, res, next);
};

module.exports.private_article_upload_complete = function private_article_upload_complete (req, res, next) {
  Articles.private_article_upload_complete(req.swagger.params, res, next);
};

module.exports.private_article_upload_initiate = function private_article_upload_initiate (req, res, next) {
  Articles.private_article_upload_initiate(req.swagger.params, res, next);
};

module.exports.private_articles_list = function private_articles_list (req, res, next) {
  Articles.private_articles_list(req.swagger.params, res, next);
};

module.exports.private_articles_search = function private_articles_search (req, res, next) {
  Articles.private_articles_search(req.swagger.params, res, next);
};
