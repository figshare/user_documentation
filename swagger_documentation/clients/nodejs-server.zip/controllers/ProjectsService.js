'use strict';

exports.private_project_article_delete = function(args, res, next) {
  /**
   * Delete project article
   * Delete project article
   *
   * project_id Long Project unique identifier
   * article_id Long Project Article unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_project_article_details = function(args, res, next) {
  /**
   * Project article details
   * Project article details
   *
   * project_id Long Project unique identifier
   * article_id Long Project Article unique identifier
   * returns ProjectArticle
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_article_file = function(args, res, next) {
  /**
   * Project article file details
   * Project article file details
   *
   * project_id Long Project unique identifier
   * article_id Long Project Article unique identifier
   * file_id Long File unique identifier
   * returns PrivateFile
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_article_files = function(args, res, next) {
  /**
   * Project article list files
   * List article files
   *
   * project_id Long Project unique identifier
   * article_id Long Project Article unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ "" ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_articles_create = function(args, res, next) {
  /**
   * Create project article
   * Create a new Article and associate it with this project
   *
   * project_id Long Project unique identifier
   * article ArticleCreate Article description
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_articles_list = function(args, res, next) {
  /**
   * List project articles
   * List project articles
   *
   * project_id Long Project unique identifier
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "defined_type" : 3,
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "handle" : "111184/figshare.1234",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "title" : "Test article title",
  "url" : "http://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_collaborator__Delete = function(args, res, next) {
  /**
   * Remove project collaborator
   * Remove project collaborator
   *
   * project_id Long Project unique identifier
   * user_id Long User unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_project_collaborators_invite = function(args, res, next) {
  /**
   * Invite project collaborators
   * Invite users to collaborate on project or view the project
   *
   * project_id Long Project unique identifier
   * collaborator ProjectCollaboratorInvite viewer or collaborator role. User user_id or email of user
   * returns ResponseMessage
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "Project 1 has been published"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_collaborators_list = function(args, res, next) {
  /**
   * List project collaborators
   * List Project collaborators and invited users
   *
   * project_id Long Project unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "role_name" : "Owner",
  "user_id" : 1,
  "name" : "name",
  "status" : "invited"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_create = function(args, res, next) {
  /**
   * Create project
   * Create a new project
   *
   * project ProjectCreate Project  description
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_delete = function(args, res, next) {
  /**
   * Delete project
   * A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 
   *
   * project_id Long Project unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_project_details = function(args, res, next) {
  /**
   * View project details
   * View a private project
   *
   * project_id Long Project unique identifier
   * returns ProjectCompletePrivate
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_leave = function(args, res, next) {
  /**
   * Private Project Leave
   * Please note: project's owner cannot leave the project.
   *
   * project_id Long Project unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_project_note = function(args, res, next) {
  /**
   * Project note details
   *
   * project_id Long Project unique identifier
   * note_id Long Note unique identifier
   * returns ProjectNotePrivate
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_note_delete = function(args, res, next) {
  /**
   * Delete project note
   *
   * project_id Long Project unique identifier
   * note_id Long Note unique identifier
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_project_note_update = function(args, res, next) {
  /**
   * Update project note
   *
   * project_id Long Project unique identifier
   * note_id Long Note unique identifier
   * note ProjectNoteCreate Note message
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_project_notes_create = function(args, res, next) {
  /**
   * Create project note
   * Create a new project note
   *
   * project_id Long Project unique identifier
   * note ProjectNoteCreate Note message
   * returns Location
   **/
  var examples = {};
  examples['application/json'] = {
  "location" : "http://example.com/aeiou"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_notes_list = function(args, res, next) {
  /**
   * List project notes
   * List project notes
   *
   * project_id Long Project unique identifier
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "user_id" : 100008,
  "user_name" : "user",
  "id" : 1,
  "abstract" : "text",
  "created_date" : "2017-05-16T16:49:11Z",
  "modified_date" : "2017-05-16T16:49:11Z"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_publish = function(args, res, next) {
  /**
   * Private Project Publish
   * Publish a project. Possible after all items inside it are public
   *
   * project_id Long Project unique identifier
   * returns ResponseMessage
   **/
  var examples = {};
  examples['application/json'] = {
  "message" : "Project 1 has been published"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_project_update = function(args, res, next) {
  /**
   * Update project
   * Updating an project by passing body parameters
   *
   * project_id Long Project unique identifier
   * project ProjectUpdate Project description
   * no response value expected for this operation
   **/
  res.end();
}

exports.private_projects_list = function(args, res, next) {
  /**
   * Private Projects
   * List private projects
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * order String The field by which to order. Default varies by endpoint/resource. (optional)
   * order_direction String  (optional)
   * storage String only return collections from this institution (optional)
   * roles String Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\". (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ "" ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_projects_search = function(args, res, next) {
  /**
   * Private Projects search
   * Search inside the private projects
   *
   * search CommonSearch Search Parameters (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ "" ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.project_articles = function(args, res, next) {
  /**
   * Public Project Articles
   * List articles in project
   *
   * project_id Long Project Unique identifier
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "defined_type" : 3,
  "url_private_html" : "https://figshare.com/account/articles/1434614",
  "thumb" : "https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png",
  "url_public_html" : "https://figshare.com/articles/Test_article_title/1434614",
  "url_private_api" : "https://api.figshare.com/account/articles/1434614",
  "handle" : "111184/figshare.1234",
  "id" : 1434614,
  "url_public_api" : "https://api.figshare.com/articles/1434614",
  "title" : "Test article title",
  "url" : "http://api.figshare.com/articles/1434614",
  "doi" : "10.6084/m9.figshare.1434614"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.project_details = function(args, res, next) {
  /**
   * Public Project
   * View a project
   *
   * project_id Long Project Unique identifier
   * returns ProjectComplete
   **/
  var examples = {};
  examples['application/json'] = "";
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.projects_list = function(args, res, next) {
  /**
   * Public Projects
   * Returns a list of public projects
   *
   * page Long Page number. Used for pagination with page_size (optional)
   * page_size Long The number of results included on a page. Used for pagination with page (optional)
   * limit Long Number of results included on a page. Used for pagination with query (optional)
   * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
   * order String The field by which to order. Default varies by endpoint/resource. (optional)
   * order_direction String  (optional)
   * institution Long only return collections from this institution (optional)
   * published_since String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
   * group Long only return collections from this group (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "id" : 1,
  "title" : "project",
  "url" : "http://api.figshare.com/v2/account/projects/1"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.projects_search = function(args, res, next) {
  /**
   * Public Projects Search
   * Returns a list of public articles
   *
   * search CommonSearch Search Parameters (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "id" : 1,
  "title" : "project",
  "url" : "http://api.figshare.com/v2/account/projects/1"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

