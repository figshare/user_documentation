'use strict';

exports.categories_list = function(args, res, next) {
  /**
   * Public Categories
   * Returns a list of public categories
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "path" : "/450/1024/6532",
  "taxonomy_id" : 4,
  "parent_id" : 1,
  "id" : 11,
  "source_id" : "300204",
  "title" : "Anatomy"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.file_download = function(args, res, next) {
  /**
   * Public File Download
   * Starts the download of a file
   *
   * file_id Long 
   * no response value expected for this operation
   **/
  res.end();
}

exports.item_types_list = function(args, res, next) {
  /**
   * Item Types
   * Returns a list of Item Types available to the authenticated user. If no user is authenticated, returns the item types available for Figshare.
   *
   * group_id Long Identifier of the group for which the item types are requested (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "is_selectable" : 0,
  "url_name" : "journal_contribution",
  "public_description" : "This is the description of an item type",
  "name" : "journal contribution",
  "icon" : "paper",
  "id" : 1,
  "string_id" : "journal_contribution"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.licenses_list = function(args, res, next) {
  /**
   * Public Licenses
   * Returns a list of public licenses
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "name" : "CC BY",
  "value" : 1,
  "url" : "http://creativecommons.org/licenses/by/4.0/"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_account = function(args, res, next) {
  /**
   * Private Account information
   * Account information for token/personal token
   *
   * returns Account
   **/
  var examples = {};
  examples['application/json'] = {
  "institution_user_id" : "djohn42",
  "last_name" : "John",
  "active" : 0,
  "pending_quota_request" : true,
  "modified_date" : "2018-05-22T04:04:04",
  "institution_id" : 1,
  "group_id" : 0,
  "maximum_file_size" : 0,
  "used_quota" : 0,
  "quota" : 0,
  "used_quota_public" : 0,
  "id" : 1495682,
  "used_quota_private" : 0,
  "created_date" : "2018-05-22T04:04:04",
  "first_name" : "Doe",
  "email" : "user@domain.com"
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_funding_search = function(args, res, next) {
  /**
   * Search Funding
   * Search for fundings
   *
   * search FundingSearch Search Parameters (optional)
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "grant_code" : "aeiou",
  "funder_name" : "aeiou",
  "id" : 1,
  "title" : "Scholarly funding",
  "is_user_defined" : true,
  "url" : "https://app.dimensions.ai/details/grant/1"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.private_licenses_list = function(args, res, next) {
  /**
   * Private Account Licenses
   * This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "name" : "CC BY",
  "value" : 1,
  "url" : "http://creativecommons.org/licenses/by/4.0/"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

