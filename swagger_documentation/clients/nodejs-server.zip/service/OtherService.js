'use strict';


/**
 * Public Categories
 * Returns a list of public categories
 *
 * returns List
 **/
exports.categories_list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public File Download
 * Starts the download of a file
 *
 * file_id Long 
 * no response value expected for this operation
 **/
exports.file_download = function(file_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Item Types
 * Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.
 *
 * group_id Long Identifier of the group for which the item types are requested (optional)
 * returns List
 **/
exports.item_types_list = function(group_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Licenses
 * Returns a list of public licenses
 *
 * returns List
 **/
exports.licenses_list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account information
 * Account information for token/personal token
 *
 * returns Account
 **/
exports.private_account = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Search Funding
 * Search for fundings
 *
 * search FundingSearch Search Parameters (optional)
 * returns List
 **/
exports.private_funding_search = function(search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account Licenses
 * This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.
 *
 * returns List
 **/
exports.private_licenses_list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

