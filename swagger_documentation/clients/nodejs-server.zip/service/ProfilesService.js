'use strict';


/**
 * Update public profile
 * Updates the fields of the user's public profile.
 *
 * user_id Long User ID
 * user profile data ProfileUpdateData 
 * no response value expected for this operation
 **/
exports.update_user_profile = function(user_id,user profile data) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update public profile picture
 * Updates the profile picture of the user's public profile.
 *
 * user_id Long User ID
 * profile_picture File User profile picture
 * no response value expected for this operation
 **/
exports.update_user_profile_picture = function(user_id,profile_picture) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

