'use strict';


/**
 * Institution Curation Review
 * Retrieve a certain curation review by its ID
 *
 * curation_id Long ID of the curation
 * returns CurationDetail
 **/
exports.account_institution_curation = function(curation_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Institution Curation Review Comments
 * Retrieve a certain curation review's comments.
 *
 * curation_id Long ID of the curation
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns CurationComment
 **/
exports.account_institution_curation_comments = function(curation_id,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * POST Institution Curation Review Comment
 * Add a new comment to the review.
 *
 * curation_id Long ID of the curation
 * curationComment CurationCommentCreate The content/value of the comment.
 * no response value expected for this operation
 **/
exports.account_institution_curation_comments_0 = function(curation_id,curationComment) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Institution Curation Reviews
 * Retrieve a list of curation reviews for this institution
 *
 * group_id Long Filter by the group ID (optional)
 * article_id Long Retrieve the reviews for this article (optional)
 * status String Filter by the status of the review (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns Curation
 **/
exports.account_institution_curations = function(group_id,article_id,status,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private account institution group custom fields
 * Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.
 *
 * group_id Long Group_id (optional)
 * returns List
 **/
exports.custom_fields_list = function(group_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Custom fields values files upload
 * Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>
 *
 * custom_field_id Long Custom field identifier
 * external_file File CSV file to be uploaded (optional)
 * returns Object
 **/
exports.custom_fields_upload = function(custom_field_id,external_file) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Institution Articles
 * Returns a list of articles belonging to the institution
 *
 * institution_string_id String 
 * resource_id String 
 * filename String 
 * returns List
 **/
exports.institution_articles = function(institution_string_id,resource_id,filename) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Institution HRfeed Upload
 * More info in the <a href=\"#hr_feed\">HR Feed section</a>
 *
 * hrfeed File You can find an example in the Hr Feed section (optional)
 * returns ResponseMessage
 **/
exports.institution_hrfeed_upload = function(hrfeed) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account Institution User
 * Retrieve institution user information using the account_id
 *
 * account_id Long Account identifier the user is associated to
 * returns User
 **/
exports.private_account_institution_user = function(account_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account Categories
 * List institution categories (including parent Categories)
 *
 * returns List
 **/
exports.private_categories_list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account Institution Group Embargo Options
 * Account institution group embargo options details
 *
 * group_id Long Group identifier
 * returns List
 **/
exports.private_group_embargo_options_details = function(group_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Institution Account Group Role
 * Delete Institution Account Group Role
 *
 * account_id Long Account identifier for which to remove the role
 * group_id Long Group identifier for which to remove the role
 * role_id Long Role identifier
 * no response value expected for this operation
 **/
exports.private_institution_account_group_role_delete = function(account_id,group_id,role_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * List Institution Account Group Roles
 * List Institution Account Group Roles
 *
 * account_id Long Account identifier the user is associated to
 * returns AccountGroupRoles
 **/
exports.private_institution_account_group_roles = function(account_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Add Institution Account Group Roles
 * Add Institution Account Group Roles
 *
 * account_id Long Account identifier the user is associated to
 * account AccountGroupRolesCreate Account description
 * no response value expected for this operation
 **/
exports.private_institution_account_group_roles_create = function(account_id,account) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create new Institution Account
 * Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.
 *
 * account AccountCreate Account description
 * no response value expected for this operation
 **/
exports.private_institution_accounts_create = function(account) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Private Account Institution Accounts
 * Returns the accounts for which the account has administrative privileges (assigned and inherited).
 *
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * is_active Long Filter by active status (optional)
 * institution_user_id String Filter by institution_user_id (optional)
 * email String Filter by email (optional)
 * id_lte Long Retrieve accounts with an ID lower or equal to the specified value (optional)
 * id_gte Long Retrieve accounts with an ID greater or equal to the specified value (optional)
 * returns List
 **/
exports.private_institution_accounts_list = function(page,page_size,limit,offset,is_active,institution_user_id,email,id_lte,id_gte) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account Institution Accounts Search
 * Returns the accounts for which the account has administrative privileges (assigned and inherited).
 *
 * search InstitutionAccountsSearch Search Parameters
 * returns List
 **/
exports.private_institution_accounts_search = function(search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Institution Account
 * Update Institution Account
 *
 * account_id Long Account identifier the user is associated to
 * account AccountUpdate Account description
 * no response value expected for this operation
 **/
exports.private_institution_accounts_update = function(account_id,account) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Private Institution Articles
 * Get Articles from own institution. User must be administrator of the institution
 *
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * order String The field by which to order. Default varies by endpoint/resource. (optional)
 * order_direction String  (optional)
 * published_since String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
 * modified_since String Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
 * status Long only return collections with this status (optional)
 * resource_doi String only return collections with this resource_doi (optional)
 * item_type Long Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
 * returns List
 **/
exports.private_institution_articles = function(page,page_size,limit,offset,order,order_direction,published_since,modified_since,status,resource_doi,item_type) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account Institutions
 * Account institution details
 *
 * returns Institution
 **/
exports.private_institution_details = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account Institution embargo options
 * Account institution embargo options details
 *
 * returns List
 **/
exports.private_institution_embargo_options_details = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account Institution Groups
 * Returns the groups for which the account has administrative privileges (assigned and inherited).
 *
 * returns List
 **/
exports.private_institution_groups_list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Account Institution Roles
 * Returns the roles available for groups and the institution group.
 *
 * returns List
 **/
exports.private_institution_roles_list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

