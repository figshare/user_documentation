goog.provide('API.Client.ProjectNoteCreate');

/**
 * @record
 */
API.Client.ProjectNoteCreate = function() {}

/**
 * Text of the note
 * @type {!string}
 * @export
 */
API.Client.ProjectNoteCreate.prototype.text;

