goog.provide('API.Client.ProjectCollaboratorInvite');

/**
 * @record
 */
API.Client.ProjectCollaboratorInvite = function() {}

/**
 * Role of the the collaborator inside the project
 * @type {!string}
 * @export
 */
API.Client.ProjectCollaboratorInvite.prototype.roleName;

/**
 * User id of the collaborator
 * @type {!number}
 * @export
 */
API.Client.ProjectCollaboratorInvite.prototype.userId;

/**
 * Collaborator email
 * @type {!string}
 * @export
 */
API.Client.ProjectCollaboratorInvite.prototype.email;

/**
 * Text sent when inviting the user to the project
 * @type {!string}
 * @export
 */
API.Client.ProjectCollaboratorInvite.prototype.comment;

/** @enum {string} */
API.Client.ProjectCollaboratorInvite.RoleNameEnum = { 
  viewer: 'viewer',
  collaborator: 'collaborator',
}
