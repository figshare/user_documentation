goog.provide('API.Client.ArticlesCreator');

/**
 * @record
 */
API.Client.ArticlesCreator = function() {}

/**
 * List of article ids
 * @type {!Array<!number>}
 * @export
 */
API.Client.ArticlesCreator.prototype.articles;

