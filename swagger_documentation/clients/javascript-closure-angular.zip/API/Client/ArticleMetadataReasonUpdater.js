goog.provide('API.Client.ArticleMetadataReasonUpdater');

/**
 * @record
 */
API.Client.ArticleMetadataReasonUpdater = function() {}

/**
 * Reason for defining the article as metadata record
 * @type {!string}
 * @export
 */
API.Client.ArticleMetadataReasonUpdater.prototype.metadataReason;

