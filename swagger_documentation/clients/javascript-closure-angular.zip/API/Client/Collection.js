goog.provide('API.Client.Collection');

/**
 * @record
 */
API.Client.Collection = function() {}

/**
 * Collection id
 * @type {!number}
 * @export
 */
API.Client.Collection.prototype.id;

/**
 * Collection title
 * @type {!string}
 * @export
 */
API.Client.Collection.prototype.title;

/**
 * Collection DOI
 * @type {!string}
 * @export
 */
API.Client.Collection.prototype.doi;

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.Collection.prototype.url;

