goog.provide('API.Client.ProjectCompletePrivate');

/**
 * @record
 */
API.Client.ProjectCompletePrivate = function() {}

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.url;

/**
 * Project id
 * @type {!number}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.id;

/**
 * Project title
 * @type {!string}
 * @export
 */
API.Client.ProjectCompletePrivate.prototype.title;

