goog.provide('API.Client.CollectionCreate');

/**
 * @record
 */
API.Client.CollectionCreate = function() {}

/**
 * Grant number or funding authority
 * @type {!string}
 * @export
 */
API.Client.CollectionCreate.prototype.funding;

/**
 * Funding creation / update items
 * @type {!Array<!API.Client.FundingCreate>}
 * @export
 */
API.Client.CollectionCreate.prototype.fundingList;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.CollectionCreate.prototype.title;

/**
 * The article description. In a publisher case, usually this is the remote article description
 * @type {!string}
 * @export
 */
API.Client.CollectionCreate.prototype.description;

/**
 * List of articles to be associated with the collection
 * @type {!Array<!number>}
 * @export
 */
API.Client.CollectionCreate.prototype.articles;

/**
 * List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. No more than 10 authors. For adding more authors use the specific authors endpoint.
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.CollectionCreate.prototype.authors;

/**
 * List of category ids to be associated with the article(e.g [1, 23, 33, 66])
 * @type {!Array<!number>}
 * @export
 */
API.Client.CollectionCreate.prototype.categories;

/**
 * List of tags to be associated with the article. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionCreate.prototype.tags;

/**
 * List of tags to be associated with the article. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionCreate.prototype.keywords;

/**
 * List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionCreate.prototype.references;

/**
 * List of key, values pairs to be associated with the article
 * @type {!API.Client.Object}
 * @export
 */
API.Client.CollectionCreate.prototype.customFields;

/**
 * Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
 * @type {!string}
 * @export
 */
API.Client.CollectionCreate.prototype.doi;

/**
 * Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
 * @type {!string}
 * @export
 */
API.Client.CollectionCreate.prototype.handle;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article id
 * @type {!string}
 * @export
 */
API.Client.CollectionCreate.prototype.resourceId;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.CollectionCreate.prototype.resourceDoi;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article link
 * @type {!string}
 * @export
 */
API.Client.CollectionCreate.prototype.resourceLink;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.CollectionCreate.prototype.resourceTitle;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article version
 * @type {!number}
 * @export
 */
API.Client.CollectionCreate.prototype.resourceVersion;

/**
 * Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
 * @type {!number}
 * @export
 */
API.Client.CollectionCreate.prototype.groupId;

/**
 * Various timeline dates
 * @type {!API.Client.TimelineUpdate}
 * @export
 */
API.Client.CollectionCreate.prototype.timeline;

