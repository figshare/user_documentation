goog.provide('API.Client.ProjectPrivate');

/**
 * @record
 */
API.Client.ProjectPrivate = function() {}

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.url;

/**
 * Project id
 * @type {!number}
 * @export
 */
API.Client.ProjectPrivate.prototype.id;

/**
 * Project title
 * @type {!string}
 * @export
 */
API.Client.ProjectPrivate.prototype.title;

