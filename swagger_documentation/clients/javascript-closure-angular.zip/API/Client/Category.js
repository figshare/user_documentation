goog.provide('API.Client.Category');

/**
 * @record
 */
API.Client.Category = function() {}

/**
 * Parent category
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.parentId;

/**
 * Category id
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.id;

/**
 * Category title
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.title;

