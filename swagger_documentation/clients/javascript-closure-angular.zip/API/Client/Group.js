goog.provide('API.Client.Group');

/**
 * @record
 */
API.Client.Group = function() {}

/**
 * Group id
 * @type {!number}
 * @export
 */
API.Client.Group.prototype.id;

/**
 * Group name
 * @type {!string}
 * @export
 */
API.Client.Group.prototype.name;

/**
 * Group resource id
 * @type {!string}
 * @export
 */
API.Client.Group.prototype.resourceId;

/**
 * Parent group if any
 * @type {!number}
 * @export
 */
API.Client.Group.prototype.parentId;

/**
 * HR code associated with group, if code exists
 * @type {!string}
 * @export
 */
API.Client.Group.prototype.associationCriteria;

