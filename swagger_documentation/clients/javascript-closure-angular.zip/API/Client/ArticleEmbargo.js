goog.provide('API.Client.ArticleEmbargo');

/**
 * @record
 */
API.Client.ArticleEmbargo = function() {}

/**
 * True if embargoed
 * @type {!boolean}
 * @export
 */
API.Client.ArticleEmbargo.prototype.isEmbargoed;

/**
 * Reason for embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleEmbargo.prototype.embargoReason;

