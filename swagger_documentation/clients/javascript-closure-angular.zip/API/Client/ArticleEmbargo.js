goog.provide('API.Client.ArticleEmbargo');

/**
 * @record
 */
API.Client.ArticleEmbargo = function() {}

/**
 * True if embargoed
 * @type {!boolean}
 * @export
 */
API.Client.ArticleEmbargo.prototype.isEmbargoed;

/**
 * Reason for embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleEmbargo.prototype.embargoReason;

/**
 * List of embargo permissions that are associated with the article. If the type is logged_in and the group_ids list is empty, then the whole institution can see the article; if there are multiple group_ids, then only users that are under those groups can see the article.
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.ArticleEmbargo.prototype.embargoOptions;

