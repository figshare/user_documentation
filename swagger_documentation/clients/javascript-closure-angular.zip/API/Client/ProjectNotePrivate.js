goog.provide('API.Client.ProjectNotePrivate');

/**
 * @record
 */
API.Client.ProjectNotePrivate = function() {}

/**
 * Project note id
 * @type {!number}
 * @export
 */
API.Client.ProjectNotePrivate.prototype.id;

/**
 * User who wrote the note
 * @type {!number}
 * @export
 */
API.Client.ProjectNotePrivate.prototype.userId;

/**
 * Note Abstract - short/truncated content
 * @type {!string}
 * @export
 */
API.Client.ProjectNotePrivate.prototype._abstract;

/**
 * Username of the one who wrote the note
 * @type {!string}
 * @export
 */
API.Client.ProjectNotePrivate.prototype.userName;

/**
 * Date when note was created
 * @type {!string}
 * @export
 */
API.Client.ProjectNotePrivate.prototype.createdDate;

/**
 * Date when note was last modified
 * @type {!string}
 * @export
 */
API.Client.ProjectNotePrivate.prototype.modifiedDate;

