goog.provide('API.Client.ErrorMessage');

/**
 * @record
 */
API.Client.ErrorMessage = function() {}

/**
 * A machine friendly error code, used by the dev team to identify the error.
 * @type {!number}
 * @export
 */
API.Client.ErrorMessage.prototype.code;

/**
 * A human friendly message explaining the error.
 * @type {!string}
 * @export
 */
API.Client.ErrorMessage.prototype.message;

