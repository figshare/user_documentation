goog.provide('API.Client.ArticleCreate');

/**
 * @record
 */
API.Client.ArticleCreate = function() {}

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleCreate.prototype.title;

/**
 * The article description. In a publisher case, usually this is the remote article description
 * @type {!string}
 * @export
 */
API.Client.ArticleCreate.prototype.description;

/**
 * List of tags to be associated with the article. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleCreate.prototype.tags;

/**
 * List of tags to be associated with the article. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleCreate.prototype.keywords;

/**
 * List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleCreate.prototype.references;

/**
 * List of category ids to be associated with the article(e.g [1, 23, 33, 66])
 * @type {!Array<!number>}
 * @export
 */
API.Client.ArticleCreate.prototype.categories;

/**
 * List of authors to be assosciated with the article. The list can contain author ids or author names. No more than 10 authors. For adding more authors use the specific authors endpoint.
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.ArticleCreate.prototype.authors;

/**
 * List of key, values pairs to be associated with the article
 * @type {!API.Client.Object}
 * @export
 */
API.Client.ArticleCreate.prototype.customFields;

/**
 * Article type
 * @type {!string}
 * @export
 */
API.Client.ArticleCreate.prototype.definedType;

/**
 * Grant number or funding authority
 * @type {!string}
 * @export
 */
API.Client.ArticleCreate.prototype.funding;

/**
 * License id for this article.
 * @type {!number}
 * @export
 */
API.Client.ArticleCreate.prototype.license;

/**
 * Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
 * @type {!string}
 * @export
 */
API.Client.ArticleCreate.prototype.doi;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.ArticleCreate.prototype.resourceDoi;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.ArticleCreate.prototype.resourceTitle;

/**
 * Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
 * @type {!number}
 * @export
 */
API.Client.ArticleCreate.prototype.groupId;

/** @enum {string} */
API.Client.ArticleCreate.DefinedTypeEnum = { 
  figure: 'figure',
  media: 'media',
  dataset: 'dataset',
  fileset: 'fileset',
  poster: 'poster',
  paper: 'paper',
  presentation: 'presentation',
  thesis: 'thesis',
  code: 'code',
  metadata: 'metadata',
  preprint: 'preprint',
}
