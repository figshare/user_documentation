goog.provide('API.Client.PrivateLinkCreator');

/**
 * @record
 */
API.Client.PrivateLinkCreator = function() {}

/**
 * Date when this private link should expire - optional. By default private links expire in 365 days.
 * @type {!string}
 * @export
 */
API.Client.PrivateLinkCreator.prototype.expiresDate;

/**
 * Optional, default true. Set to false to give private link users editing rights for this collection.
 * @type {!boolean}
 * @export
 */
API.Client.PrivateLinkCreator.prototype.readOnly;

