goog.provide('API.Client.AuthorsCreator');

/**
 * @record
 */
API.Client.AuthorsCreator = function() {}

/**
 * List of authors to be assosciated with the article. The list can contain author ids or author names [{\"id\": 12121}, {\"id\": 34345}, {\"name\": \"John Doe\"}]. No more than 10 authors. For adding more authors use the specific authors endpoint.
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.AuthorsCreator.prototype.authors;

