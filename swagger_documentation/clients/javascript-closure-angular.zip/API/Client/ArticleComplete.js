goog.provide('API.Client.ArticleComplete');

/**
 * @record
 */
API.Client.ArticleComplete = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPrivateApi;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.ArticleComplete.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.definedTypeName;

