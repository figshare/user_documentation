goog.provide('API.Client.ArticleComplete');

/**
 * @record
 */
API.Client.ArticleComplete = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.doi;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPrivateApi;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.thumb;

/**
 * Type of article identificator
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.definedType;

