goog.provide('API.Client.ArticleComplete');

/**
 * @record
 */
API.Client.ArticleComplete = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.doi;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.urlPrivateApi;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ArticleComplete.prototype.thumb;

/**
 * Integer which is mapped to item types as: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code, 11 - Metadata, 12 - Preprint
 * @type {!number}
 * @export
 */
API.Client.ArticleComplete.prototype.definedType;

