goog.provide('API.Client.AuthorComplete');

/**
 * @record
 */
API.Client.AuthorComplete = function() {}

/**
 * Author id
 * @type {!number}
 * @export
 */
API.Client.AuthorComplete.prototype.id;

/**
 * Author full name
 * @type {!string}
 * @export
 */
API.Client.AuthorComplete.prototype.fullName;

/**
 * True if author has published items
 * @type {!boolean}
 * @export
 */
API.Client.AuthorComplete.prototype.isActive;

/**
 * Author url name
 * @type {!string}
 * @export
 */
API.Client.AuthorComplete.prototype.urlName;

/**
 * Author Orcid
 * @type {!string}
 * @export
 */
API.Client.AuthorComplete.prototype.orcidId;

