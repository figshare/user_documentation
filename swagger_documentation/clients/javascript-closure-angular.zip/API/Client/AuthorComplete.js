goog.provide('API.Client.AuthorComplete');

/**
 * @record
 */
API.Client.AuthorComplete = function() {}

/**
 * Author id
 * @type {!number}
 * @export
 */
API.Client.AuthorComplete.prototype.id;

/**
 * Author full name
 * @type {!string}
 * @export
 */
API.Client.AuthorComplete.prototype.fullName;

/**
 * True if author has published items
 * @type {!boolean}
 * @export
 */
API.Client.AuthorComplete.prototype.isActive;

/**
 * Author url name
 * @type {!string}
 * @export
 */
API.Client.AuthorComplete.prototype.urlName;

/**
 * Author Orcid
 * @type {!string}
 * @export
 */
API.Client.AuthorComplete.prototype.orcidId;

/**
 * Institution id
 * @type {!number}
 * @export
 */
API.Client.AuthorComplete.prototype.institutionId;

/**
 * Group id
 * @type {!number}
 * @export
 */
API.Client.AuthorComplete.prototype.groupId;

/**
 * First Name
 * @type {!string}
 * @export
 */
API.Client.AuthorComplete.prototype.firstName;

/**
 * Last Name
 * @type {!string}
 * @export
 */
API.Client.AuthorComplete.prototype.lastName;

/**
 * if 1 then the author has published items
 * @type {!number}
 * @export
 */
API.Client.AuthorComplete.prototype.isPublic;

/**
 * Job title
 * @type {!string}
 * @export
 */
API.Client.AuthorComplete.prototype.jobTitle;

