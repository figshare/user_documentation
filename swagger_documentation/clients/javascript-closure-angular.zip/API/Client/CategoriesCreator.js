goog.provide('API.Client.CategoriesCreator');

/**
 * @record
 */
API.Client.CategoriesCreator = function() {}

/**
 * List of category ids
 * @type {!Array<!number>}
 * @export
 */
API.Client.CategoriesCreator.prototype.categories;

