goog.provide('API.Client.ArticleEmbargoUpdater');

/**
 * @record
 */
API.Client.ArticleEmbargoUpdater = function() {}

/**
 * Embargo status
 * @type {!boolean}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.isEmbargoed;

/**
 * Date when the embargo expires and the article gets published
 * @type {!string}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.embargoDate;

/**
 * Embargo can be enabled at the article or the file level. Possible values: article, file
 * @type {!string}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.embargoType;

/**
 * Reason for setting embargo
 * @type {!string}
 * @export
 */
API.Client.ArticleEmbargoUpdater.prototype.embargoReason;

/** @enum {string} */
API.Client.ArticleEmbargoUpdater.EmbargoTypeEnum = { 
  article: 'article',
  file: 'file',
}
