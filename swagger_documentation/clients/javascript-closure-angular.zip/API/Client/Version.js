goog.provide('API.Client.Version');

/**
 * @record
 */
API.Client.Version = function() {}

/**
 * Version number
 * @type {!number}
 * @export
 */
API.Client.Version.prototype.id;

/**
 * Api endpoint for the item version
 * @type {!string}
 * @export
 */
API.Client.Version.prototype.url;

