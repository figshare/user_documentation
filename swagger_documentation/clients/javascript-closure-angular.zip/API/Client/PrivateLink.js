goog.provide('API.Client.PrivateLink');

/**
 * @record
 */
API.Client.PrivateLink = function() {}

/**
 * Private link id
 * @type {!string}
 * @export
 */
API.Client.PrivateLink.prototype.id;

/**
 * True if private link is active
 * @type {!boolean}
 * @export
 */
API.Client.PrivateLink.prototype.isActive;

/**
 * Date when link will expire
 * @type {!string}
 * @export
 */
API.Client.PrivateLink.prototype.expiresDate;

/**
 * HTML url for private link
 * @type {!string}
 * @export
 */
API.Client.PrivateLink.prototype.htmlLocation;

