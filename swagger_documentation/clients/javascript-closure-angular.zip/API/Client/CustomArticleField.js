goog.provide('API.Client.CustomArticleField');

/**
 * @record
 */
API.Client.CustomArticleField = function() {}

/**
 * Custom  metadata name
 * @type {!string}
 * @export
 */
API.Client.CustomArticleField.prototype.name;

/**
 * Custom metadata value
 * @type {!string}
 * @export
 */
API.Client.CustomArticleField.prototype.value;

