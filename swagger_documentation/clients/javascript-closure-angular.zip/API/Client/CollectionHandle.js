goog.provide('API.Client.CollectionHandle');

/**
 * @record
 */
API.Client.CollectionHandle = function() {}

/**
 * Reserved Handle
 * @type {!string}
 * @export
 */
API.Client.CollectionHandle.prototype.handle;

