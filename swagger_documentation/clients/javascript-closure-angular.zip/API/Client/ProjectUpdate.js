goog.provide('API.Client.ProjectUpdate');

/**
 * @record
 */
API.Client.ProjectUpdate = function() {}

/**
 * The title for this project - mandatory. 3 - 500 characters.
 * @type {!string}
 * @export
 */
API.Client.ProjectUpdate.prototype.title;

/**
 * Project description
 * @type {!string}
 * @export
 */
API.Client.ProjectUpdate.prototype.description;

/**
 * Grant number or organization(s) that funded this project. Up to 2000 characters permitted.
 * @type {!string}
 * @export
 */
API.Client.ProjectUpdate.prototype.funding;

