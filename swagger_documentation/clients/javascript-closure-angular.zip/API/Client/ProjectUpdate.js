goog.provide('API.Client.ProjectUpdate');

/**
 * @record
 */
API.Client.ProjectUpdate = function() {}

/**
 * The title for this project - mandatory. 3 - 1000 characters.
 * @type {!string}
 * @export
 */
API.Client.ProjectUpdate.prototype.title;

/**
 * Project description
 * @type {!string}
 * @export
 */
API.Client.ProjectUpdate.prototype.description;

/**
 * Grant number or organization(s) that funded this project. Up to 2000 characters permitted.
 * @type {!string}
 * @export
 */
API.Client.ProjectUpdate.prototype.funding;

/**
 * Funding creation / update items
 * @type {!Array<!API.Client.FundingCreate>}
 * @export
 */
API.Client.ProjectUpdate.prototype.fundingList;

/**
 * List of key, values pairs to be associated with the project
 * @type {!API.Client.Object}
 * @export
 */
API.Client.ProjectUpdate.prototype.customFields;

/**
 * List of custom fields values, supersedes custom_fields parameter
 * @type {!Array<!API.Client.CustomArticleField>}
 * @export
 */
API.Client.ProjectUpdate.prototype.customFieldsList;

