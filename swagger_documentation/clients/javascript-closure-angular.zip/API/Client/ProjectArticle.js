goog.provide('API.Client.ProjectArticle');

/**
 * @record
 */
API.Client.ProjectArticle = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.doi;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPrivateApi;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.thumb;

/**
 * Integer which is mapped to item types as: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.definedType;

