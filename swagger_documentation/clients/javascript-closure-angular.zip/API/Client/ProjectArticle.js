goog.provide('API.Client.ProjectArticle');

/**
 * @record
 */
API.Client.ProjectArticle = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPrivateApi;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.ProjectArticle.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.definedTypeName;

