goog.provide('API.Client.ProjectArticle');

/**
 * @record
 */
API.Client.ProjectArticle = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPrivateApi;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.thumb;

/**
 * Type of article identificator
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.definedType;

/**
 * Name of the article type identificator
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.definedTypeName;

