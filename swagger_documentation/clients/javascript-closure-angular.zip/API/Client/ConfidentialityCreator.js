goog.provide('API.Client.ConfidentialityCreator');

/**
 * @record
 */
API.Client.ConfidentialityCreator = function() {}

/**
 * Reason for confidentiality
 * @type {!string}
 * @export
 */
API.Client.ConfidentialityCreator.prototype.reason;

