goog.provide('API.Client.Location');

/**
 * @record
 */
API.Client.Location = function() {}

/**
 * Url for item
 * @type {!string}
 * @export
 */
API.Client.Location.prototype.location;

