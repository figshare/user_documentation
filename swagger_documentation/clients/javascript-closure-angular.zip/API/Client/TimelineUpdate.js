goog.provide('API.Client.TimelineUpdate');

/**
 * @record
 */
API.Client.TimelineUpdate = function() {}

/**
 * Online posted date
 * @type {!string}
 * @export
 */
API.Client.TimelineUpdate.prototype.firstOnline;

/**
 * Publish date
 * @type {!string}
 * @export
 */
API.Client.TimelineUpdate.prototype.publisherPublication;

/**
 * Date when the item was accepted for publication
 * @type {!string}
 * @export
 */
API.Client.TimelineUpdate.prototype.publisherAcceptance;

