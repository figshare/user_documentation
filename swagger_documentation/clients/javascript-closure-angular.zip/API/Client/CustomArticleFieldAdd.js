goog.provide('API.Client.CustomArticleFieldAdd');

/**
 * @record
 */
API.Client.CustomArticleFieldAdd = function() {}

/**
 * Custom  metadata name
 * @type {!string}
 * @export
 */
API.Client.CustomArticleFieldAdd.prototype.name;

/**
 * Custom metadata value
 * @type {!API.Client.Object}
 * @export
 */
API.Client.CustomArticleFieldAdd.prototype.value;

