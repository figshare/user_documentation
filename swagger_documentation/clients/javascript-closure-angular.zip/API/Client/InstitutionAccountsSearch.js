goog.provide('API.Client.InstitutionAccountsSearch');

/**
 * @record
 */
API.Client.InstitutionAccountsSearch = function() {}

/**
 * Search term
 * @type {!string}
 * @export
 */
API.Client.InstitutionAccountsSearch.prototype.searchFor;

/**
 * Filter by active status
 * @type {!number}
 * @export
 */
API.Client.InstitutionAccountsSearch.prototype.isActive;

/**
 * Page number. Used for pagination with page_size
 * @type {!number}
 * @export
 */
API.Client.InstitutionAccountsSearch.prototype.page;

/**
 * The number of results included on a page. Used for pagination with page
 * @type {!number}
 * @export
 */
API.Client.InstitutionAccountsSearch.prototype.pageSize;

/**
 * Number of results included on a page. Used for pagination with query
 * @type {!number}
 * @export
 */
API.Client.InstitutionAccountsSearch.prototype.limit;

/**
 * Where to start the listing(the offset of the first result). Used for pagination with limit
 * @type {!number}
 * @export
 */
API.Client.InstitutionAccountsSearch.prototype.offset;

/**
 * filter by institution_user_id
 * @type {!string}
 * @export
 */
API.Client.InstitutionAccountsSearch.prototype.institutionUserId;

/**
 * filter by email
 * @type {!string}
 * @export
 */
API.Client.InstitutionAccountsSearch.prototype.email;

