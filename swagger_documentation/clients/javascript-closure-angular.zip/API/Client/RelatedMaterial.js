goog.provide('API.Client.RelatedMaterial');

/**
 * @record
 */
API.Client.RelatedMaterial = function() {}

/**
 * The ID of the related material; can be used to add existing materials of the same account to items.
 * @type {!number}
 * @export
 */
API.Client.RelatedMaterial.prototype.id;

/**
 * The related material identifier (e.g., DOI, Handle, ISBN)
 * @type {!string}
 * @export
 */
API.Client.RelatedMaterial.prototype.identifier;

/**
 * The related material title
 * @type {!string}
 * @export
 */
API.Client.RelatedMaterial.prototype.title;

/**
 * The relation between the item and the related material; defaults to 'References'
 * @type {!string}
 * @export
 */
API.Client.RelatedMaterial.prototype.relation;

/**
 * The type of the identifier of the related material; defaults to 'URL'
 * @type {!string}
 * @export
 */
API.Client.RelatedMaterial.prototype.identifierType;

/**
 * Flag for highlighting this related material in the call-out box
 * @type {!boolean}
 * @export
 */
API.Client.RelatedMaterial.prototype.isLinkout;

/**
 * The full hyperlink for the identifier
 * @type {!string}
 * @export
 */
API.Client.RelatedMaterial.prototype.link;

/** @enum {string} */
API.Client.RelatedMaterial.RelationEnum = { 
  IsCitedBy: 'IsCitedBy',
  Cites: 'Cites',
  IsSupplementTo: 'IsSupplementTo',
  IsSupplementedBy: 'IsSupplementedBy',
  IsContinuedBy: 'IsContinuedBy',
  Continues: 'Continues',
  Describes: 'Describes',
  IsDescribedBy: 'IsDescribedBy',
  HasMetadata: 'HasMetadata',
  IsMetadataFor: 'IsMetadataFor',
  HasVersion: 'HasVersion',
  IsVersionOf: 'IsVersionOf',
  IsNewVersionOf: 'IsNewVersionOf',
  IsPreviousVersionOf: 'IsPreviousVersionOf',
  IsPartOf: 'IsPartOf',
  HasPart: 'HasPart',
  IsPublishedIn: 'IsPublishedIn',
  IsReferencedBy: 'IsReferencedBy',
  References: 'References',
  IsDocumentedBy: 'IsDocumentedBy',
  Documents: 'Documents',
  IsCompiledBy: 'IsCompiledBy',
  Compiles: 'Compiles',
  IsVariantFormOf: 'IsVariantFormOf',
  IsOriginalFormOf: 'IsOriginalFormOf',
  IsIdenticalTo: 'IsIdenticalTo',
  IsReviewedBy: 'IsReviewedBy',
  Reviews: 'Reviews',
  IsDerivedFrom: 'IsDerivedFrom',
  IsSourceOf: 'IsSourceOf',
  IsRequiredBy: 'IsRequiredBy',
  Requires: 'Requires',
  IsObsoletedBy: 'IsObsoletedBy',
  Obsoletes: 'Obsoletes',
}
/** @enum {string} */
API.Client.RelatedMaterial.IdentifierTypeEnum = { 
  ARK: 'ARK',
  arXiv: 'arXiv',
  bibcode: 'bibcode',
  DOI: 'DOI',
  EAN13: 'EAN13',
  EISSN: 'EISSN',
  Handle: 'Handle',
  IGSN: 'IGSN',
  ISBN: 'ISBN',
  ISSN: 'ISSN',
  ISTC: 'ISTC',
  LISSN: 'LISSN',
  LSID: 'LSID',
  PMID: 'PMID',
  PURL: 'PURL',
  UPC: 'UPC',
  URL: 'URL',
  URN: 'URN',
  w3id: 'w3id',
}
