goog.provide('API.Client.Collaborator');

/**
 * @record
 */
API.Client.Collaborator = function() {}

/**
 * Collaborator role
 * @type {!string}
 * @export
 */
API.Client.Collaborator.prototype.roleName;

/**
 * Collaborator id
 * @type {!number}
 * @export
 */
API.Client.Collaborator.prototype.userId;

/**
 * Collaborator name
 * @type {!string}
 * @export
 */
API.Client.Collaborator.prototype.name;

