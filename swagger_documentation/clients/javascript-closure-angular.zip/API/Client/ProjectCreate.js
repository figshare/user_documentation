goog.provide('API.Client.ProjectCreate');

/**
 * @record
 */
API.Client.ProjectCreate = function() {}

/**
 * The title for this project - mandatory. 3 - 500 characters.
 * @type {!string}
 * @export
 */
API.Client.ProjectCreate.prototype.title;

/**
 * Project description
 * @type {!string}
 * @export
 */
API.Client.ProjectCreate.prototype.description;

/**
 * Grant number or organization(s) that funded this project. Up to 2000 characters permitted.
 * @type {!string}
 * @export
 */
API.Client.ProjectCreate.prototype.funding;

/**
 * Funding creation / update items
 * @type {!Array<!API.Client.FundingCreate>}
 * @export
 */
API.Client.ProjectCreate.prototype.fundingList;

/**
 * Only if project type is group.
 * @type {!number}
 * @export
 */
API.Client.ProjectCreate.prototype.groupId;

