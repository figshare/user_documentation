goog.provide('API.Client.ArticleMetadataReason');

/**
 * @record
 */
API.Client.ArticleMetadataReason = function() {}

/**
 * True if the article is metadata record
 * @type {!boolean}
 * @export
 */
API.Client.ArticleMetadataReason.prototype.isMetadataRecord;

