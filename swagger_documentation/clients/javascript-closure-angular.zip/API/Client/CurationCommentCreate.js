goog.provide('API.Client.CurationCommentCreate');

/**
 * @record
 */
API.Client.CurationCommentCreate = function() {}

/**
 * The contents/value of the comment
 * @type {!string}
 * @export
 */
API.Client.CurationCommentCreate.prototype.text;

