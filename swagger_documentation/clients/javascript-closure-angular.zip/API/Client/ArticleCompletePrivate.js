goog.provide('API.Client.ArticleCompletePrivate');

/**
 * @record
 */
API.Client.ArticleCompletePrivate = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.doi;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPrivateApi;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.thumb;

/**
 * Integer which is mapped to item types as: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code, 11 - Metadata, 12 - Preprint
 * @type {!number}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.definedType;

