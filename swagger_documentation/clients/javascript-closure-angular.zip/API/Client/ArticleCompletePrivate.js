goog.provide('API.Client.ArticleCompletePrivate');

/**
 * @record
 */
API.Client.ArticleCompletePrivate = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.urlPrivateApi;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.thumb;

/**
 * Type of article identificator
 * @type {!number}
 * @export
 */
API.Client.ArticleCompletePrivate.prototype.definedType;

