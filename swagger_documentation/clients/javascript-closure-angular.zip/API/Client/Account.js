goog.provide('API.Client.Account');

/**
 * @record
 */
API.Client.Account = function() {}

/**
 * Account id
 * @type {!number}
 * @export
 */
API.Client.Account.prototype.id;

/**
 * First Name
 * @type {!string}
 * @export
 */
API.Client.Account.prototype.firstName;

/**
 * Last Name
 * @type {!string}
 * @export
 */
API.Client.Account.prototype.lastName;

/**
 * Account used private quota
 * @type {!number}
 * @export
 */
API.Client.Account.prototype.usedQuotaPrivate;

/**
 * Date of last account modification
 * @type {!string}
 * @export
 */
API.Client.Account.prototype.modifiedDate;

/**
 * Account total used quota
 * @type {!number}
 * @export
 */
API.Client.Account.prototype.usedQuota;

/**
 * Date when account was created
 * @type {!string}
 * @export
 */
API.Client.Account.prototype.createdDate;

/**
 * Account quota
 * @type {!number}
 * @export
 */
API.Client.Account.prototype.quota;

/**
 * Account group id
 * @type {!number}
 * @export
 */
API.Client.Account.prototype.groupId;

/**
 * Account institution user id
 * @type {!string}
 * @export
 */
API.Client.Account.prototype.institutionUserId;

/**
 * Account institution
 * @type {!number}
 * @export
 */
API.Client.Account.prototype.institutionId;

/**
 * User email
 * @type {!string}
 * @export
 */
API.Client.Account.prototype.email;

/**
 * Account public used quota
 * @type {!number}
 * @export
 */
API.Client.Account.prototype.usedQuotaPublic;

/**
 * True if a quota request is pending
 * @type {!boolean}
 * @export
 */
API.Client.Account.prototype.pendingQuotaRequest;

/**
 * Account activity status
 * @type {!number}
 * @export
 */
API.Client.Account.prototype.active;

/**
 * Maximum upload size for account
 * @type {!number}
 * @export
 */
API.Client.Account.prototype.maximumFileSize;

