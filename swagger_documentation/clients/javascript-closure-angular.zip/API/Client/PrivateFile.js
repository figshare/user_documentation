goog.provide('API.Client.PrivateFile');

/**
 * @record
 */
API.Client.PrivateFile = function() {}

/**
 * File id
 * @type {!number}
 * @export
 */
API.Client.PrivateFile.prototype.id;

/**
 * File name
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.name;

/**
 * File size
 * @type {!number}
 * @export
 */
API.Client.PrivateFile.prototype.size;

/**
 * True if file is hosted somewhere else
 * @type {!boolean}
 * @export
 */
API.Client.PrivateFile.prototype.isLinkOnly;

/**
 * Url for file download
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.downloadUrl;

/**
 * File supplied md5
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.suppliedMd5;

/**
 * File computed md5
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.computedMd5;

/**
 * MIME Type of the file, it defaults to an empty string
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.mimetype;

/**
 * File viewer type
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.viewerType;

/**
 * File preview state
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.previewState;

/**
 * Upload url for file
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.uploadUrl;

/**
 * Token for file upload
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.uploadToken;

/**
 * True if the file is attached to a public item version
 * @type {!boolean}
 * @export
 */
API.Client.PrivateFile.prototype.isAttachedToPublicVersion;

