goog.provide('API.Client.PrivateFile');

/**
 * @record
 */
API.Client.PrivateFile = function() {}

/**
 * File id
 * @type {!number}
 * @export
 */
API.Client.PrivateFile.prototype.id;

/**
 * File name
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.name;

/**
 * File size
 * @type {!number}
 * @export
 */
API.Client.PrivateFile.prototype.size;

/**
 * True if file is hosted somewhere else
 * @type {!boolean}
 * @export
 */
API.Client.PrivateFile.prototype.isLinkOnly;

/**
 * Url for file download
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.downloadUrl;

/**
 * File supplied md5
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.suppliedMd5;

/**
 * File computed md5
 * @type {!string}
 * @export
 */
API.Client.PrivateFile.prototype.computedMd5;

