goog.provide('API.Client.ArticleUpdate');

/**
 * @record
 */
API.Client.ArticleUpdate = function() {}

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleUpdate.prototype.title;

/**
 * The article description. In a publisher case, usually this is the remote article description
 * @type {!string}
 * @export
 */
API.Client.ArticleUpdate.prototype.description;

/**
 * List of tags to be associated with the article. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleUpdate.prototype.tags;

/**
 * List of tags to be associated with the article. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleUpdate.prototype.keywords;

/**
 * List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleUpdate.prototype.references;

/**
 * List of category ids to be associated with the article(e.g [1, 23, 33, 66])
 * @type {!Array<!number>}
 * @export
 */
API.Client.ArticleUpdate.prototype.categories;

/**
 * List of category source ids to be associated with the article, supersedes the categories property
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleUpdate.prototype.categoriesBySourceId;

/**
 * List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. No more than 10 authors. For adding more authors use the specific authors endpoint.
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.ArticleUpdate.prototype.authors;

/**
 * List of key, values pairs to be associated with the article
 * @type {!API.Client.Object}
 * @export
 */
API.Client.ArticleUpdate.prototype.customFields;

/**
 * List of custom fields values, supersedes custom_fields parameter
 * @type {!Array<!API.Client.CustomArticleFieldAdd>}
 * @export
 */
API.Client.ArticleUpdate.prototype.customFieldsList;

/**
 * <b>One of:</b> <code>figure</code> <code>online resource</code> <code>preprint</code> <code>book</code> <code>conference contribution</code> <code>media</code> <code>dataset</code> <code>poster</code> <code>journal contribution</code> <code>presentation</code> <code>thesis</code> <code>software</code>
 * @type {!string}
 * @export
 */
API.Client.ArticleUpdate.prototype.definedType;

/**
 * Grant number or funding authority
 * @type {!string}
 * @export
 */
API.Client.ArticleUpdate.prototype.funding;

/**
 * Funding creation / update items
 * @type {!Array<!API.Client.FundingCreate>}
 * @export
 */
API.Client.ArticleUpdate.prototype.fundingList;

/**
 * License id for this article.
 * @type {!number}
 * @export
 */
API.Client.ArticleUpdate.prototype.license;

/**
 * Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
 * @type {!string}
 * @export
 */
API.Client.ArticleUpdate.prototype.doi;

/**
 * Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
 * @type {!string}
 * @export
 */
API.Client.ArticleUpdate.prototype.handle;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.ArticleUpdate.prototype.resourceDoi;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.ArticleUpdate.prototype.resourceTitle;

/**
 * Various timeline dates
 * @type {!API.Client.TimelineUpdate}
 * @export
 */
API.Client.ArticleUpdate.prototype.timeline;

/**
 * Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
 * @type {!number}
 * @export
 */
API.Client.ArticleUpdate.prototype.groupId;

