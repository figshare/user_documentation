goog.provide('API.Client.ArticleUnpublishData');

/**
 * @record
 */
API.Client.ArticleUnpublishData = function() {}

/**
 * Reason of article unpublishing
 * @type {!string}
 * @export
 */
API.Client.ArticleUnpublishData.prototype.reason;

