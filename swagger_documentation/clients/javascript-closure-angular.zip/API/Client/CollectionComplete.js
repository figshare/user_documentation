goog.provide('API.Client.CollectionComplete');

/**
 * @record
 */
API.Client.CollectionComplete = function() {}

/**
 * Collection id
 * @type {!number}
 * @export
 */
API.Client.CollectionComplete.prototype.id;

/**
 * Collection title
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.title;

/**
 * Collection DOI
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.doi;

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.url;

