goog.provide('API.Client.CollectionComplete');

/**
 * @record
 */
API.Client.CollectionComplete = function() {}

/**
 * Collection id
 * @type {!number}
 * @export
 */
API.Client.CollectionComplete.prototype.id;

/**
 * Collection title
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.title;

/**
 * Collection DOI
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.doi;

/**
 * Collection Handle
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.handle;

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.url;

