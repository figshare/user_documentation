goog.provide('API.Client.ProjectComplete');

/**
 * @record
 */
API.Client.ProjectComplete = function() {}

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.ProjectComplete.prototype.url;

/**
 * Project id
 * @type {!number}
 * @export
 */
API.Client.ProjectComplete.prototype.id;

/**
 * Project title
 * @type {!string}
 * @export
 */
API.Client.ProjectComplete.prototype.title;

