goog.provide('API.Client.License');

/**
 * @record
 */
API.Client.License = function() {}

/**
 * License value
 * @type {!number}
 * @export
 */
API.Client.License.prototype.value;

/**
 * License name
 * @type {!string}
 * @export
 */
API.Client.License.prototype.name;

/**
 * License url
 * @type {!string}
 * @export
 */
API.Client.License.prototype.url;

