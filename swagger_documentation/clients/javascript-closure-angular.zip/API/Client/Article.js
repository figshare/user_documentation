goog.provide('API.Client.Article');

/**
 * @record
 */
API.Client.Article = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.Article.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.doi;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPrivateApi;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.thumb;

/**
 * Type of article identificator
 * @type {!number}
 * @export
 */
API.Client.Article.prototype.definedType;

