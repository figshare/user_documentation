goog.provide('API.Client.Article');

/**
 * @record
 */
API.Client.Article = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.Article.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.doi;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPrivateApi;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.thumb;

/**
 * Integer which is mapped to item types as: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code
 * @type {!number}
 * @export
 */
API.Client.Article.prototype.definedType;

