goog.provide('API.Client.Article');

/**
 * @record
 */
API.Client.Article = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.Article.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.urlPrivateApi;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.thumb;

/**
 * Type of article identificator
 * @type {!number}
 * @export
 */
API.Client.Article.prototype.definedType;

/**
 * Name of the article type identificator
 * @type {!string}
 * @export
 */
API.Client.Article.prototype.definedTypeName;

/**
 * Various timeline dates
 * @type {!API.Client.TimelineUpdate}
 * @export
 */
API.Client.Article.prototype.timeline;

