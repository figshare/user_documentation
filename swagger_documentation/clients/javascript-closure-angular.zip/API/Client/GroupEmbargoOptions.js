goog.provide('API.Client.GroupEmbargoOptions');

/**
 * @record
 */
API.Client.GroupEmbargoOptions = function() {}

/**
 * Embargo option id
 * @type {!number}
 * @export
 */
API.Client.GroupEmbargoOptions.prototype.id;

/**
 * Embargo permission type
 * @type {!string}
 * @export
 */
API.Client.GroupEmbargoOptions.prototype.type;

/**
 * IP range name; value appears if type is ip_range
 * @type {!string}
 * @export
 */
API.Client.GroupEmbargoOptions.prototype.ipName;

/** @enum {string} */
API.Client.GroupEmbargoOptions.TypeEnum = { 
  logged_in: 'logged_in',
  ip_range: 'ip_range',
  administrator: 'administrator',
}
