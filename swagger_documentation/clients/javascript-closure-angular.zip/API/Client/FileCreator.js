goog.provide('API.Client.FileCreator');

/**
 * @record
 */
API.Client.FileCreator = function() {}

/**
 * Url for an existing file that will not be uploaded on figshare
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.link;

/**
 * MD5 sum pre computed on the client side
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.md5;

/**
 * File name including the extension
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.name;

/**
 * File size in bytes
 * @type {!number}
 * @export
 */
API.Client.FileCreator.prototype.size;

