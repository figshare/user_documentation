goog.provide('API.Client.FileCreator');

/**
 * @record
 */
API.Client.FileCreator = function() {}

/**
 * Url for an existing file that will not be uploaded on figshare
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.link;

/**
 * MD5 sum pre computed on the client side
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.md5;

/**
 * File name including the extension; can be omitted only for linked files.
 * @type {!string}
 * @export
 */
API.Client.FileCreator.prototype.name;

/**
 * File size in bytes; can be omitted only for linked files.
 * @type {!number}
 * @export
 */
API.Client.FileCreator.prototype.size;

