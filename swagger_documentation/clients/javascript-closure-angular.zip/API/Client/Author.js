goog.provide('API.Client.Author');

/**
 * @record
 */
API.Client.Author = function() {}

/**
 * Author id
 * @type {!number}
 * @export
 */
API.Client.Author.prototype.id;

/**
 * Author full name
 * @type {!string}
 * @export
 */
API.Client.Author.prototype.fullName;

/**
 * True if author has published items
 * @type {!boolean}
 * @export
 */
API.Client.Author.prototype.isActive;

/**
 * Author url name
 * @type {!string}
 * @export
 */
API.Client.Author.prototype.urlName;

/**
 * Author Orcid
 * @type {!string}
 * @export
 */
API.Client.Author.prototype.orcidId;

