goog.provide('API.Client.ShortAccount');

/**
 * @record
 */
API.Client.ShortAccount = function() {}

/**
 * Account id
 * @type {!number}
 * @export
 */
API.Client.ShortAccount.prototype.id;

/**
 * First Name
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.firstName;

/**
 * Last Name
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.lastName;

/**
 * Account institution
 * @type {!number}
 * @export
 */
API.Client.ShortAccount.prototype.institutionId;

/**
 * User email
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.email;

/**
 * Account activity status
 * @type {!number}
 * @export
 */
API.Client.ShortAccount.prototype.active;

/**
 * Account institution user id
 * @type {!string}
 * @export
 */
API.Client.ShortAccount.prototype.institutionUserId;

