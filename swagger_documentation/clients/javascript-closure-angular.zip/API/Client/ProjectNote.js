goog.provide('API.Client.ProjectNote');

/**
 * @record
 */
API.Client.ProjectNote = function() {}

/**
 * Project note id
 * @type {!number}
 * @export
 */
API.Client.ProjectNote.prototype.id;

/**
 * User who wrote the note
 * @type {!number}
 * @export
 */
API.Client.ProjectNote.prototype.userId;

/**
 * Note Abstract - short/truncated content
 * @type {!string}
 * @export
 */
API.Client.ProjectNote.prototype._abstract;

/**
 * Username of the one who wrote the note
 * @type {!string}
 * @export
 */
API.Client.ProjectNote.prototype.userName;

/**
 * Date when note was created
 * @type {!string}
 * @export
 */
API.Client.ProjectNote.prototype.createdDate;

/**
 * Date when note was last modified
 * @type {!string}
 * @export
 */
API.Client.ProjectNote.prototype.modifiedDate;

