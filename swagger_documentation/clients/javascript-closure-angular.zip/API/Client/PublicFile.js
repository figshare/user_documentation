goog.provide('API.Client.PublicFile');

/**
 * @record
 */
API.Client.PublicFile = function() {}

/**
 * File id
 * @type {!number}
 * @export
 */
API.Client.PublicFile.prototype.id;

/**
 * File name
 * @type {!string}
 * @export
 */
API.Client.PublicFile.prototype.name;

/**
 * File size
 * @type {!number}
 * @export
 */
API.Client.PublicFile.prototype.size;

/**
 * True if file is hosted somewhere else
 * @type {!boolean}
 * @export
 */
API.Client.PublicFile.prototype.isLinkOnly;

/**
 * Url for file download
 * @type {!string}
 * @export
 */
API.Client.PublicFile.prototype.downloadUrl;

