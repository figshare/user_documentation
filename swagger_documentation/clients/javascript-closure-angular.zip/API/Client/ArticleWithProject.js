goog.provide('API.Client.ArticleWithProject');

/**
 * @record
 */
API.Client.ArticleWithProject = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ArticleWithProject.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.urlPrivateApi;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.ArticleWithProject.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.ArticleWithProject.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.definedTypeName;

