goog.provide('API.Client.PrivateLinkResponse');

/**
 * @record
 */
API.Client.PrivateLinkResponse = function() {}

/**
 * Url for private link
 * @type {!string}
 * @export
 */
API.Client.PrivateLinkResponse.prototype.location;

/**
 * Token for private link
 * @type {!string}
 * @export
 */
API.Client.PrivateLinkResponse.prototype.token;

