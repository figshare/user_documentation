goog.provide('API.Client.FundingInformation');

/**
 * @record
 */
API.Client.FundingInformation = function() {}

/**
 * Funding id
 * @type {!number}
 * @export
 */
API.Client.FundingInformation.prototype.id;

/**
 * The funding name
 * @type {!string}
 * @export
 */
API.Client.FundingInformation.prototype.title;

/**
 * The grant code
 * @type {!string}
 * @export
 */
API.Client.FundingInformation.prototype.grantCode;

/**
 * Funder's name
 * @type {!string}
 * @export
 */
API.Client.FundingInformation.prototype.funderName;

/**
 * Return whether the grant has been introduced manually
 * @type {!boolean}
 * @export
 */
API.Client.FundingInformation.prototype.isUserDefined;

/**
 * The grant url
 * @type {!string}
 * @export
 */
API.Client.FundingInformation.prototype.url;

