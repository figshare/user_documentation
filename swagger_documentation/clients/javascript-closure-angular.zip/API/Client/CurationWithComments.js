goog.provide('API.Client.CurationWithComments');

/**
 * @record
 */
API.Client.CurationWithComments = function() {}

/**
 * The review id
 * @type {!number}
 * @export
 */
API.Client.CurationWithComments.prototype.id;

/**
 * The group in which the article is present.
 * @type {!number}
 * @export
 */
API.Client.CurationWithComments.prototype.groupId;

/**
 * The ID of the account of the owner of the article of this review.
 * @type {!number}
 * @export
 */
API.Client.CurationWithComments.prototype.accountId;

/**
 * The ID of the account to which this review is assigned.
 * @type {!number}
 * @export
 */
API.Client.CurationWithComments.prototype.assignedTo;

/**
 * The ID of the article of this review.
 * @type {!number}
 * @export
 */
API.Client.CurationWithComments.prototype.articleId;

/**
 * The Version number of the article in review.
 * @type {!number}
 * @export
 */
API.Client.CurationWithComments.prototype.version;

/**
 * The number of comments in the review.
 * @type {!number}
 * @export
 */
API.Client.CurationWithComments.prototype.commentsCount;

/**
 * The status of the review.
 * @type {!string}
 * @export
 */
API.Client.CurationWithComments.prototype.status;

/**
 * The creation date of the review.
 * @type {!string}
 * @export
 */
API.Client.CurationWithComments.prototype.createdDate;

/**
 * The date the review has been modified.
 * @type {!string}
 * @export
 */
API.Client.CurationWithComments.prototype.modifiedDate;

/** @enum {string} */
API.Client.CurationWithComments.StatusEnum = { 
  pending: 'pending',
  approved: 'approved',
  rejected: 'rejected',
  closed: 'closed',
}
