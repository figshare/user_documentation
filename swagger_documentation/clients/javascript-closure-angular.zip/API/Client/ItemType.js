goog.provide('API.Client.ItemType');

/**
 * @record
 */
API.Client.ItemType = function() {}

/**
 * The ID of the item type.
 * @type {!number}
 * @export
 */
API.Client.ItemType.prototype.id;

/**
 * The name of the item type
 * @type {!string}
 * @export
 */
API.Client.ItemType.prototype.name;

/**
 * The string identifier of the item type.
 * @type {!string}
 * @export
 */
API.Client.ItemType.prototype.stringId;

/**
 * The string identifying the icon of the item type.
 * @type {!string}
 * @export
 */
API.Client.ItemType.prototype.icon;

/**
 * The description of the item type.
 * @type {!string}
 * @export
 */
API.Client.ItemType.prototype.publicDescription;

/**
 * Filter by the selectable status
 * @type {!number}
 * @export
 */
API.Client.ItemType.prototype.isSelectable;

/**
 * The URL name of the item type.
 * @type {!string}
 * @export
 */
API.Client.ItemType.prototype.urlName;

