goog.provide('API.Client.ArticleHandle');

/**
 * @record
 */
API.Client.ArticleHandle = function() {}

/**
 * Reserved Handle
 * @type {!string}
 * @export
 */
API.Client.ArticleHandle.prototype.handle;

