goog.provide('API.Client.AccountGroupRolesCreate');

/**
 * @record
 */
API.Client.AccountGroupRolesCreate = function() {}

