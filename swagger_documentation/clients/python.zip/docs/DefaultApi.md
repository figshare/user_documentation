# swagger_client.DefaultApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**account_article_report_generate**](DefaultApi.md#account_article_report_generate) | **POST** /account/articles/export | Initiate a new Report


# **account_article_report_generate**
> AccountReport account_article_report_generate()

Initiate a new Report

Initiate a new Article Report for this Account

### Example 
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DefaultApi()

try: 
    # Initiate a new Report
    api_response = api_instance.account_article_report_generate()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->account_article_report_generate: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

