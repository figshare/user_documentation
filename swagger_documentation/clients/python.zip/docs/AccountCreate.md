# AccountCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** | Email of account | 
**first_name** | **str** | First Name | [default to '']
**last_name** | **str** | Last Name | [default to '']
**group_id** | **int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | 
**institution_user_id** | **str** | Institution user id | [default to '']
**symplectic_user_id** | **str** | Symplectic user id | [default to '']
**quota** | **int** | Account quota | 
**is_active** | **bool** | Is account active | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


