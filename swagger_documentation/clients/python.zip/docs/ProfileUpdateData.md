# ProfileUpdateData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | **str** | First name | [optional] 
**last_name** | **str** | Last Name | [optional] 
**orcid** | **str** | User ORCID | [optional] 
**job_title** | **str** | User job title | [optional] 
**fields_of_interest** | **list[int]** | User fields of interest (category ids) | [optional] 
**fields_of_interest_by_source_id** | **list[str]** | User fields of interest (category source IDs), supersedes the fields_of_interest property | [optional] 
**location** | **str** | User location | [optional] 
**facebook** | **str** | User facebook URL | [optional] 
**x** | **str** | User X (twitter) URL | [optional] 
**linkedin** | **str** | User linkedin URL | [optional] 
**bio** | **str** | User biographical information | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


