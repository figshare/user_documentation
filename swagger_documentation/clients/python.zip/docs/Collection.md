# Collection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Collection id | [optional] 
**title** | **str** | Collection title | [optional] 
**doi** | **str** | Collection DOI | [optional] 
**url** | **str** | Api endpoint | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


