# FileCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **str** | Url for an existing file that will not be uploaded on figshare | [optional] 
**md5** | **str** | MD5 sum pre computed on the client side | [optional] 
**name** | **str** | File name including the extension | 
**size** | **int** | File size in bytes | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


