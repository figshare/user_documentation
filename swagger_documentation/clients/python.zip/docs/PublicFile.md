# PublicFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | File id | [optional] 
**name** | **str** | File name | [optional] 
**size** | **int** | File size | [optional] 
**is_link_only** | **bool** | True if file is hosted somewhere else | [optional] 
**download_url** | **str** | Url for file download | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


