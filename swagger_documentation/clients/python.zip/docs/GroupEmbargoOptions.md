# GroupEmbargoOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Embargo option id | [optional] 
**type** | **str** | Embargo permission type | [optional] 
**ip_name** | **str** | IP range name; value appears if type is ip_range | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


