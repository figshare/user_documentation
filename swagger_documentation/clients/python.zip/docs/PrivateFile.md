# PrivateFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | File id | 
**name** | **str** | File name | 
**size** | **int** | File size | 
**is_link_only** | **bool** | True if file is hosted somewhere else | 
**download_url** | **str** | Url for file download | 
**supplied_md5** | **str** | File supplied md5 | 
**computed_md5** | **str** | File computed md5 | 
**mimetype** | **str** | MIME Type of the file, it defaults to an empty string | [optional] 
**viewer_type** | **str** | File viewer type | 
**preview_state** | **str** | File preview state | 
**upload_url** | **str** | Upload url for file | 
**upload_token** | **str** | Token for file upload | 
**is_attached_to_public_version** | **bool** | True if the file is attached to a public item version | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


