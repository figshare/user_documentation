# ArticleComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique identifier for article | [optional] 
**title** | **str** | Title of article | [optional] 
**doi** | **str** | DOI | [optional] 
**handle** | **str** | Handle | [optional] 
**url** | **str** | Api endpoint for article | [optional] 
**url_public_html** | **str** | Public site endpoint for article | [optional] 
**url_public_api** | **str** | Public Api endpoint for article | [optional] 
**url_private_html** | **str** | Private site endpoint for article | [optional] 
**url_private_api** | **str** | Private Api endpoint for article | [optional] 
**thumb** | **str** | Thumbnail image | [optional] 
**defined_type** | **int** | Type of article identificator | [optional] 
**defined_type_name** | **str** | Name of the article type identificator | [optional] 
**timeline** | [**TimelineUpdate**](TimelineUpdate.md) | Various timeline dates | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


