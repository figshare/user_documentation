# PrivateLinkResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **str** | Url for private link | 
**html_location** | **str** | HTML url for private link | 
**token** | **str** | Token for private link | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


