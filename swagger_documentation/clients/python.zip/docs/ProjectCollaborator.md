# ProjectCollaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** | Status of collaborator invitation | 
**role_name** | **str** | Collaborator role | 
**user_id** | **int** | Collaborator id | 
**name** | **str** | Collaborator name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


