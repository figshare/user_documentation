# PrivateLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Private link id | [optional] 
**is_active** | **bool** | True if private link is active | [optional] 
**expires_date** | **str** | Date when link will expire | [optional] 
**html_location** | **str** | HTML url for private link | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


