# swagger_client.InstitutionsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**institution_articles**](InstitutionsApi.md#institution_articles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Licenses
[**institution_hrfeed_upload**](InstitutionsApi.md#institution_hrfeed_upload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload
[**private_categories_list**](InstitutionsApi.md#private_categories_list) | **GET** /account/categories | Private Account Categories
[**private_institution_accounts_list**](InstitutionsApi.md#private_institution_accounts_list) | **GET** /account/institution/accounts | Private Account Institution Accounts
[**private_institution_accounts_search**](InstitutionsApi.md#private_institution_accounts_search) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search
[**private_institution_articles**](InstitutionsApi.md#private_institution_articles) | **GET** /account/institution/articles | Private Institution Articles
[**private_institution_details**](InstitutionsApi.md#private_institution_details) | **GET** /account/institution | Private Account Institutions
[**private_institution_groups_list**](InstitutionsApi.md#private_institution_groups_list) | **GET** /account/institution/groups | Private Account Institution Groups


# **institution_articles**
> list[Article] institution_articles(institution_string_id, resource_id, filename)

Public Licenses

Returns a list of articles belonging to the institution

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.InstitutionsApi()
institution_string_id = 'institution_string_id_example' # str | 
resource_id = 'resource_id_example' # str | 
filename = 'filename_example' # str | 

try: 
    # Public Licenses
    api_response = api_instance.institution_articles(institution_string_id, resource_id, filename)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InstitutionsApi->institution_articles: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **institution_string_id** | **str**|  | 
 **resource_id** | **str**|  | 
 **filename** | **str**|  | 

### Return type

[**list[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **institution_hrfeed_upload**
> ResponseMessage institution_hrfeed_upload(hrfeed=hrfeed)

Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.InstitutionsApi()
hrfeed = '/path/to/file.txt' # file | You can find an example in the Hr Feed section (optional)

try: 
    # Private Institution HRfeed Upload
    api_response = api_instance.institution_hrfeed_upload(hrfeed=hrfeed)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InstitutionsApi->institution_hrfeed_upload: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hrfeed** | **file**| You can find an example in the Hr Feed section | [optional] 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_categories_list**
> list[Category] private_categories_list()

Private Account Categories

List institution categories (including parent Categories)

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.InstitutionsApi()

try: 
    # Private Account Categories
    api_response = api_instance.private_categories_list()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InstitutionsApi->private_categories_list: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**list[Category]**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_list**
> list[ShortAccount] private_institution_accounts_list(page=page, page_size=page_size, limit=limit, offset=offset, is_active=is_active)

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.InstitutionsApi()
page = 789 # int | Page number. Used for pagination with page_size (optional)
page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
limit = 789 # int | Number of results included on a page. Used for pagination with query (optional)
offset = 789 # int | Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
is_active = 789 # int | Filter by active status (optional)

try: 
    # Private Account Institution Accounts
    api_response = api_instance.private_institution_accounts_list(page=page, page_size=page_size, limit=limit, offset=offset, is_active=is_active)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InstitutionsApi->private_institution_accounts_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **is_active** | **int**| Filter by active status | [optional] 

### Return type

[**list[ShortAccount]**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_search**
> list[ShortAccount] private_institution_accounts_search(search)

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.InstitutionsApi()
search = swagger_client.InstitutionAccountsSearch() # InstitutionAccountsSearch | Search Parameters

try: 
    # Private Account Institution Accounts Search
    api_response = api_instance.private_institution_accounts_search(search)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InstitutionsApi->private_institution_accounts_search: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**InstitutionAccountsSearch**](InstitutionAccountsSearch.md)| Search Parameters | 

### Return type

[**list[ShortAccount]**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_articles**
> list[Article] private_institution_articles(page=page, page_size=page_size, limit=limit, offset=offset, order=order, order_direction=order_direction, published_since=published_since, modified_since=modified_since, status=status, resource_doi=resource_doi, item_type=item_type)

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.InstitutionsApi()
page = 789 # int | Page number. Used for pagination with page_size (optional)
page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
limit = 789 # int | Number of results included on a page. Used for pagination with query (optional)
offset = 789 # int | Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
order = 'published_date' # str | The field by which to order. Default varies by endpoint/resource. (optional) (default to published_date)
order_direction = 'desc' # str |  (optional) (default to desc)
published_since = 'published_since_example' # str | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
modified_since = 'modified_since_example' # str | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
status = 789 # int | only return collections with this status (optional)
resource_doi = 'resource_doi_example' # str | only return collections with this resource_doi (optional)
item_type = 789 # int | Only return collections with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code, 12 - Preprint (optional)

try: 
    # Private Institution Articles
    api_response = api_instance.private_institution_articles(page=page, page_size=page_size, limit=limit, offset=offset, order=order, order_direction=order_direction, published_since=published_since, modified_since=modified_since, status=status, resource_doi=resource_doi, item_type=item_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InstitutionsApi->private_institution_articles: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **str**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **str**|  | [optional] [default to desc]
 **published_since** | **str**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **modified_since** | **str**| Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **status** | **int**| only return collections with this status | [optional] 
 **resource_doi** | **str**| only return collections with this resource_doi | [optional] 
 **item_type** | **int**| Only return collections with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code, 12 - Preprint | [optional] 

### Return type

[**list[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_details**
> Institution private_institution_details()

Private Account Institutions

Account institution details

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.InstitutionsApi()

try: 
    # Private Account Institutions
    api_response = api_instance.private_institution_details()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InstitutionsApi->private_institution_details: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Institution**](Institution.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_groups_list**
> list[Group] private_institution_groups_list()

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
swagger_client.configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.InstitutionsApi()

try: 
    # Private Account Institution Groups
    api_response = api_instance.private_institution_groups_list()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling InstitutionsApi->private_institution_groups_list: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**list[Group]**](Group.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

