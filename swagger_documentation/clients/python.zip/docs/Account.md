# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id | [optional] 
**first_name** | **str** | First Name | [optional] 
**last_name** | **str** | Last Name | [optional] 
**used_quota_private** | **int** | Account used private quota | [optional] 
**modified_date** | **str** | Date of last account modification | [optional] 
**used_quota** | **int** | Account total used quota | [optional] 
**created_date** | **str** | Date when account was created | [optional] 
**quota** | **int** | Account quota | [optional] 
**institution_user_id** | **str** | Account institution user id | [optional] 
**institution_id** | **int** | Account institution | [optional] 
**email** | **str** | User email | [optional] 
**used_quota_public** | **int** | Account public used quota | [optional] 
**pending_quota_request** | **bool** | True if a quota request is pending | [optional] 
**active** | **int** | Account activity status | [optional] 
**maximum_file_size** | **int** | Maximum upload size for account | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


