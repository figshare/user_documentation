# ArticleUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** | Title of article | [optional] 
**description** | **str** | The article description. In a publisher case, usually this is the remote article description | [optional] [default to '']
**tags** | **list[str]** | List of tags to be associated with the article. Keywords can be used instead | [optional] 
**keywords** | **list[str]** | List of tags to be associated with the article. Tags can be used instead | [optional] 
**references** | **list[str]** | List of links to be associated with the article (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) | [optional] 
**categories** | **list[int]** | List of category ids to be associated with the article(e.g [1, 23, 33, 66]) | [optional] 
**authors** | **list[object]** | List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. No more than 10 authors. For adding more authors use the specific authors endpoint. | [optional] 
**custom_fields** | **object** | List of key, values pairs to be associated with the article | [optional] 
**defined_type** | **str** | Article type | [optional] 
**funding** | **str** | Grant number or funding authority | [optional] [default to '']
**funding_list** | [**list[FundingCreate]**](FundingCreate.md) | Funding creation / update items | [optional] 
**license** | **int** | License id for this article. | [optional] [default to 0]
**doi** | **str** | Not appliable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional] [default to '']
**resource_doi** | **str** | Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [optional] [default to '']
**resource_title** | **str** | Not applicable to regular users. In a publisher case, this is the publisher article title. | [optional] [default to '']
**group_id** | **int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


