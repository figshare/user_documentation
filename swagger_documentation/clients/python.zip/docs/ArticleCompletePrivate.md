# ArticleCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique identifier for article | [optional] 
**title** | **str** | Title of article | [optional] 
**doi** | **str** | DOI | [optional] 
**url** | **str** | Api endpoint for article | [optional] 
**url_public_html** | **str** | Public site endpoint for article | [optional] 
**url_public_api** | **str** | Public Api endpoint for article | [optional] 
**url_private_html** | **str** | Private site endpoint for article | [optional] 
**url_private_api** | **str** | Private Api endpoint for article | [optional] 
**thumb** | **str** | Thumbnail image | [optional] 
**defined_type** | **int** | Integer which is mapped to item types as: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


