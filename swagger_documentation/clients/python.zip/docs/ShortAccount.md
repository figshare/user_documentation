# ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id | [optional] 
**first_name** | **str** | First Name | [optional] 
**last_name** | **str** | Last Name | [optional] 
**institution_id** | **int** | Account institution | [optional] 
**email** | **str** | User email | [optional] 
**active** | **int** | Account activity status | [optional] 
**institution_user_id** | **str** | Account institution user id | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


