# ProjectCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** | The title for this project - mandatory. 3 - 500 characters. | 
**description** | **str** | Project description | [optional] 
**funding** | **str** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 
**group_id** | **int** | Only if project type is group. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


