# ArticleEmbargoUpdater

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_embargoed** | **bool** | Confidentiality status | [optional] 
**embargo_date** | **str** | Date when the embargo expires and the article gets published | [optional] 
**embargo_type** | **str** | Embargo can be enabled at the article or the file level. Possible values: article, file | [optional] 
**embargo_reason** | **str** | Reason for setting embargo | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


