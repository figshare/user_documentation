# Group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Group id | [optional] 
**name** | **str** | Group name | [optional] 
**resource_id** | **str** | Group resource id | [optional] 
**parent_id** | **int** | Parent group if any | [optional] 
**association_criteria** | **str** | HR code associated with group, if code exists | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


