# swagger_client.ProfilesApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**update_user_profile**](ProfilesApi.md#update_user_profile) | **PUT** /account/profile | Update public profile
[**update_user_profile_picture**](ProfilesApi.md#update_user_profile_picture) | **POST** /account/profile/{user_id}/picture | Update public profile picture


# **update_user_profile**
> object update_user_profile(user_profile_data, user_id=user_id, institution_user_id=institution_user_id)

Update public profile

Updates the fields of the user's public profile.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProfilesApi(swagger_client.ApiClient(configuration))
user_profile_data = swagger_client.ProfileUpdateData() # ProfileUpdateData | 
user_id = 789 # int | User ID (optional)
institution_user_id = 'institution_user_id_example' # str | Institutional user ID (optional)

try:
    # Update public profile
    api_response = api_instance.update_user_profile(user_profile_data, user_id=user_id, institution_user_id=institution_user_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProfilesApi->update_user_profile: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_profile_data** | [**ProfileUpdateData**](ProfileUpdateData.md)|  | 
 **user_id** | **int**| User ID | [optional] 
 **institution_user_id** | **str**| Institutional user ID | [optional] 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_user_profile_picture**
> object update_user_profile_picture(user_id, profile_picture)

Update public profile picture

Updates the profile picture of the user's public profile.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProfilesApi(swagger_client.ApiClient(configuration))
user_id = 789 # int | User ID
profile_picture = '/path/to/file.txt' # file | User profile picture

try:
    # Update public profile picture
    api_response = api_instance.update_user_profile_picture(user_id, profile_picture)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProfilesApi->update_user_profile_picture: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| User ID | 
 **profile_picture** | **file**| User profile picture | 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

