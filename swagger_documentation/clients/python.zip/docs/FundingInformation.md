# FundingInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Funding id | [optional] 
**title** | **str** | The funding name | [optional] 
**grant_code** | **str** | The grant code | [optional] 
**funder_name** | **str** | Funder&#39;s name | [optional] 
**is_user_defined** | **bool** | Return whether the grant has been introduced manually | [optional] 
**url** | **str** | The grant url | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


