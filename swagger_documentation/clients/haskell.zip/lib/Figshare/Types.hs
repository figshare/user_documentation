{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# OPTIONS_GHC -fno-warn-unused-binds -fno-warn-unused-imports #-}

module Figshare.Types (
  Account (..),
  AccountCreate (..),
  AccountGroupRoles (..),
  AccountGroupRolesCreate (..),
  AccountReport (..),
  AccountUpdate (..),
  Article (..),
  ArticleConfidentiality (..),
  ArticleCreate (..),
  ArticleDOI (..),
  ArticleEmbargo (..),
  ArticleEmbargoUpdater (..),
  ArticleHandle (..),
  ArticleUpdate (..),
  ArticleVersions (..),
  ArticlesCreator (..),
  Author (..),
  AuthorsCreator (..),
  CategoriesCreator (..),
  Category (..),
  Collaborator (..),
  Collection (..),
  CollectionCreate (..),
  CollectionDOI (..),
  CollectionHandle (..),
  CollectionPrivateLinkCreator (..),
  CollectionUpdate (..),
  CollectionVersions (..),
  CommonSearch (..),
  ConfidentialityCreator (..),
  Curation (..),
  CurationComment (..),
  CurationCommentCreate (..),
  CustomArticleField (..),
  ErrorMessage (..),
  FileCreator (..),
  FundingCreate (..),
  FundingInformation (..),
  FundingSearch (..),
  Group (..),
  GroupEmbargoOptions (..),
  Institution (..),
  InstitutionAccountsSearch (..),
  License (..),
  Location (..),
  PrivateAuthorsSearch (..),
  PrivateLink (..),
  PrivateLinkCreator (..),
  Project (..),
  ProjectCollaborator (..),
  ProjectCollaboratorInvite (..),
  ProjectCreate (..),
  ProjectNote (..),
  ProjectNoteCreate (..),
  ProjectUpdate (..),
  PublicFile (..),
  ResponseMessage (..),
  Role (..),
  ShortAccount (..),
  TimelineUpdate (..),
  UploadFilePart (..),
  UploadInfo (..),
  User (..),
  ArticleSearch (..),
  AuthorComplete (..),
  CollectionComplete (..),
  CollectionSearch (..),
  CurationDetail (..),
  PrivateFile (..),
  ProjectArticle (..),
  ProjectComplete (..),
  ProjectNotePrivate (..),
  ProjectPrivate (..),
  ProjectsSearch (..),
  Timeline (..),
  ArticleComplete (..),
  PrivateArticleSearch (..),
  PrivateCollectionSearch (..),
  ProjectCompletePrivate (..),
  ArticleCompletePrivate (..),
  ) where

import Data.List (stripPrefix)
import Data.Maybe (fromMaybe)
import Data.Aeson (Value, FromJSON(..), ToJSON(..), genericToJSON, genericParseJSON)
import Data.Aeson.Types (Options(..), defaultOptions)
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Map as Map
import GHC.Generics (Generic)
import Data.Function ((&))


-- | 
data Account = Account
  { accountId :: Integer -- ^ Account id
  , accountFirst'Underscorename :: Text -- ^ First Name
  , accountLast'Underscorename :: Text -- ^ Last Name
  , accountUsed'Underscorequota'Underscoreprivate :: Integer -- ^ Account used private quota
  , accountModified'Underscoredate :: Text -- ^ Date of last account modification
  , accountUsed'Underscorequota :: Integer -- ^ Account total used quota
  , accountCreated'Underscoredate :: Text -- ^ Date when account was created
  , accountQuota :: Integer -- ^ Account quota
  , accountGroup'Underscoreid :: Integer -- ^ Account group id
  , accountInstitution'Underscoreuser'Underscoreid :: Text -- ^ Account institution user id
  , accountInstitution'Underscoreid :: Integer -- ^ Account institution
  , accountEmail :: Text -- ^ User email
  , accountUsed'Underscorequota'Underscorepublic :: Integer -- ^ Account public used quota
  , accountPending'Underscorequota'Underscorerequest :: Bool -- ^ True if a quota request is pending
  , accountActive :: Integer -- ^ Account activity status
  , accountMaximum'Underscorefile'Underscoresize :: Integer -- ^ Maximum upload size for account
  } deriving (Show, Eq, Generic)

instance FromJSON Account where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "account")
instance ToJSON Account where
  toJSON = genericToJSON (removeFieldLabelPrefix False "account")

-- | 
data AccountCreate = AccountCreate
  { accountCreateEmail :: Text -- ^ Email of account
  , accountCreateFirst'Underscorename :: Text -- ^ First Name
  , accountCreateLast'Underscorename :: Text -- ^ Last Name
  , accountCreateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  , accountCreateInstitution'Underscoreuser'Underscoreid :: Text -- ^ Institution user id
  , accountCreateSymplectic'Underscoreuser'Underscoreid :: Text -- ^ Symplectic user id
  , accountCreateQuota :: Integer -- ^ Account quota
  , accountCreateIs'Underscoreactive :: Bool -- ^ Is account active
  } deriving (Show, Eq, Generic)

instance FromJSON AccountCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountCreate")
instance ToJSON AccountCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountCreate")

-- | 
data AccountGroupRoles = AccountGroupRoles
  { 
  } deriving (Show, Eq, Generic)

instance FromJSON AccountGroupRoles where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountGroupRoles")
instance ToJSON AccountGroupRoles where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountGroupRoles")

-- | 
data AccountGroupRolesCreate = AccountGroupRolesCreate
  { 
  } deriving (Show, Eq, Generic)

instance FromJSON AccountGroupRolesCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountGroupRolesCreate")
instance ToJSON AccountGroupRolesCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountGroupRolesCreate")

-- | 
data AccountReport = AccountReport
  { accountReportId :: Integer -- ^ A unique ID for the AccountRecord
  , accountReportAccount'Underscoreid :: Integer -- ^ The ID of the account which generated this report.
  , accountReportCreated'Underscoredate :: Text -- ^ Date when the AccountReport was requested
  , accountReportStatus :: Text -- ^ Status of the report
  , accountReportDownload'Underscoreurl :: Text -- ^ The download link for the generated XLSX
  , accountReportGroup'Underscoreid :: Integer -- ^ The group ID that was used to filter the report, if any.
  } deriving (Show, Eq, Generic)

instance FromJSON AccountReport where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountReport")
instance ToJSON AccountReport where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountReport")

-- | 
data AccountUpdate = AccountUpdate
  { accountUpdateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  , accountUpdateIs'Underscoreactive :: Bool -- ^ Is account active
  } deriving (Show, Eq, Generic)

instance FromJSON AccountUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountUpdate")
instance ToJSON AccountUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountUpdate")

-- | 
data Article = Article
  { articleId :: Integer -- ^ Unique identifier for article
  , articleTitle :: Text -- ^ Title of article
  , articleDoi :: Text -- ^ DOI
  , articleHandle :: Text -- ^ Handle
  , articleUrl :: Text -- ^ Api endpoint for article
  , articleUrl'Underscorepublic'Underscorehtml :: Text -- ^ Public site endpoint for article
  , articleUrl'Underscorepublic'Underscoreapi :: Text -- ^ Public Api endpoint for article
  , articleUrl'Underscoreprivate'Underscorehtml :: Text -- ^ Private site endpoint for article
  , articleUrl'Underscoreprivate'Underscoreapi :: Text -- ^ Private Api endpoint for article
  , articleTimeline :: Timeline -- ^ Various timeline dates
  , articleThumb :: Text -- ^ Thumbnail image
  , articleDefined'Underscoretype :: Integer -- ^ Type of article identificator
  , articleDefined'Underscoretype'Underscorename :: Text -- ^ Name of the article type identificator
  } deriving (Show, Eq, Generic)

instance FromJSON Article where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "article")
instance ToJSON Article where
  toJSON = genericToJSON (removeFieldLabelPrefix False "article")

-- | 
data ArticleConfidentiality = ArticleConfidentiality
  { articleConfidentialityIs'Underscoreconfidential :: Bool -- ^ True if article is confidential
  , articleConfidentialityReason :: Text -- ^ Reason for confidentiality
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleConfidentiality where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleConfidentiality")
instance ToJSON ArticleConfidentiality where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleConfidentiality")

-- | 
data ArticleCreate = ArticleCreate
  { articleCreateTitle :: Text -- ^ Title of article
  , articleCreateDescription :: Text -- ^ The article description. In a publisher case, usually this is the remote article description
  , articleCreateTags :: [Text] -- ^ List of tags to be associated with the article. Keywords can be used instead
  , articleCreateKeywords :: [Text] -- ^ List of tags to be associated with the article. Tags can be used instead
  , articleCreateReferences :: [Text] -- ^ List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
  , articleCreateCategories :: [Integer] -- ^ List of category ids to be associated with the article(e.g [1, 23, 33, 66])
  , articleCreateAuthors :: [Value] -- ^ List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. No more than 10 authors. For adding more authors use the specific authors endpoint.
  , articleCreateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the article
  , articleCreateDefined'Underscoretype :: Text -- ^ <b>One of:</b> <code>figure</code> <code>online resource</code> <code>preprint</code> <code>book</code> <code>conference contribution</code> <code>media</code> <code>dataset</code> <code>poster</code> <code>journal contribution</code> <code>presentation</code> <code>thesis</code> <code>software</code>
  , articleCreateFunding :: Text -- ^ Grant number or funding authority
  , articleCreateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , articleCreateLicense :: Integer -- ^ License id for this article.
  , articleCreateDoi :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleCreateHandle :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleCreateResource'Underscoredoi :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article DOI.
  , articleCreateResource'Underscoretitle :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article title.
  , articleCreateTimeline :: TimelineUpdate -- ^ Various timeline dates
  , articleCreateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleCreate")
instance ToJSON ArticleCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleCreate")

-- | 
data ArticleDOI = ArticleDOI
  { articleDOIDoi :: Text -- ^ Reserved DOI
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleDOI where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleDOI")
instance ToJSON ArticleDOI where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleDOI")

-- | 
data ArticleEmbargo = ArticleEmbargo
  { articleEmbargoIs'Underscoreembargoed :: Bool -- ^ True if embargoed
  , articleEmbargoEmbargo'Underscoretitle :: Text -- ^ Title for embargo
  , articleEmbargoEmbargo'Underscorereason :: Text -- ^ Reason for embargo
  , articleEmbargoEmbargo'Underscoreoptions :: [Value] -- ^ List of embargo permissions that are associated with the article. If the type is logged_in and the group_ids list is empty, then the whole institution can see the article; if there are multiple group_ids, then only users that are under those groups can see the article.
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleEmbargo where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleEmbargo")
instance ToJSON ArticleEmbargo where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleEmbargo")

-- | 
data ArticleEmbargoUpdater = ArticleEmbargoUpdater
  { articleEmbargoUpdaterIs'Underscoreembargoed :: Bool -- ^ Embargo status
  , articleEmbargoUpdaterEmbargo'Underscoredate :: Text -- ^ Date when the embargo expires and the article gets published, '0' value will set up permanent embargo
  , articleEmbargoUpdaterEmbargo'Underscoretype :: Text -- ^ Embargo can be enabled at the article or the file level. Possible values: article, file
  , articleEmbargoUpdaterEmbargo'Underscoretitle :: Text -- ^ Title for embargo
  , articleEmbargoUpdaterEmbargo'Underscorereason :: Text -- ^ Reason for setting embargo
  , articleEmbargoUpdaterEmbargo'Underscoreoptions :: [Value] -- ^ List of embargo permissions to be associated with the article. The list must contain `id` and can also contain `group_ids`(a field that only applies to 'logged_in' permissions). The new list replaces old options in the database, and an empty list removes all permissions for this article. Administration permission has to be set up alone but logged in and IP range permissions can be set up together.
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleEmbargoUpdater where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleEmbargoUpdater")
instance ToJSON ArticleEmbargoUpdater where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleEmbargoUpdater")

-- | 
data ArticleHandle = ArticleHandle
  { articleHandleHandle :: Text -- ^ Reserved Handle
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleHandle where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleHandle")
instance ToJSON ArticleHandle where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleHandle")

-- | 
data ArticleUpdate = ArticleUpdate
  { articleUpdateTitle :: Text -- ^ Title of article
  , articleUpdateDescription :: Text -- ^ The article description. In a publisher case, usually this is the remote article description
  , articleUpdateTags :: [Text] -- ^ List of tags to be associated with the article. Keywords can be used instead
  , articleUpdateKeywords :: [Text] -- ^ List of tags to be associated with the article. Tags can be used instead
  , articleUpdateReferences :: [Text] -- ^ List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
  , articleUpdateCategories :: [Integer] -- ^ List of category ids to be associated with the article(e.g [1, 23, 33, 66])
  , articleUpdateAuthors :: [Value] -- ^ List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. No more than 10 authors. For adding more authors use the specific authors endpoint.
  , articleUpdateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the article
  , articleUpdateDefined'Underscoretype :: Text -- ^ <b>One of:</b> <code>figure</code> <code>online resource</code> <code>preprint</code> <code>book</code> <code>conference contribution</code> <code>media</code> <code>dataset</code> <code>poster</code> <code>journal contribution</code> <code>presentation</code> <code>thesis</code> <code>software</code>
  , articleUpdateFunding :: Text -- ^ Grant number or funding authority
  , articleUpdateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , articleUpdateLicense :: Integer -- ^ License id for this article.
  , articleUpdateDoi :: Text -- ^ Not appliable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleUpdateHandle :: Text -- ^ Not appliable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleUpdateResource'Underscoredoi :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article DOI.
  , articleUpdateResource'Underscoretitle :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article title.
  , articleUpdateTimeline :: TimelineUpdate -- ^ Various timeline dates
  , articleUpdateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleUpdate")
instance ToJSON ArticleUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleUpdate")

-- | 
data ArticleVersions = ArticleVersions
  { articleVersionsVersion :: Integer -- ^ Version number
  , articleVersionsUrl :: Text -- ^ Api endpoint for the item version
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleVersions where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleVersions")
instance ToJSON ArticleVersions where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleVersions")

-- | 
data ArticlesCreator = ArticlesCreator
  { articlesCreatorArticles :: [Integer] -- ^ List of article ids
  } deriving (Show, Eq, Generic)

instance FromJSON ArticlesCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articlesCreator")
instance ToJSON ArticlesCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articlesCreator")

-- | 
data Author = Author
  { authorId :: Integer -- ^ Author id
  , authorFull'Underscorename :: Text -- ^ Author full name
  , authorIs'Underscoreactive :: Bool -- ^ True if author has published items
  , authorUrl'Underscorename :: Text -- ^ Author url name
  , authorOrcid'Underscoreid :: Text -- ^ Author Orcid
  } deriving (Show, Eq, Generic)

instance FromJSON Author where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "author")
instance ToJSON Author where
  toJSON = genericToJSON (removeFieldLabelPrefix False "author")

-- | 
data AuthorsCreator = AuthorsCreator
  { authorsCreatorAuthors :: [Value] -- ^ List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. No more than 10 authors. For adding more authors use the specific authors endpoint.
  } deriving (Show, Eq, Generic)

instance FromJSON AuthorsCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "authorsCreator")
instance ToJSON AuthorsCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "authorsCreator")

-- | 
data CategoriesCreator = CategoriesCreator
  { categoriesCreatorCategories :: [Integer] -- ^ List of category ids
  } deriving (Show, Eq, Generic)

instance FromJSON CategoriesCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "categoriesCreator")
instance ToJSON CategoriesCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "categoriesCreator")

-- | 
data Category = Category
  { categoryParent'Underscoreid :: Integer -- ^ Parent category
  , categoryId :: Integer -- ^ Category id
  , categoryTitle :: Text -- ^ Category title
  } deriving (Show, Eq, Generic)

instance FromJSON Category where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "category")
instance ToJSON Category where
  toJSON = genericToJSON (removeFieldLabelPrefix False "category")

-- | 
data Collaborator = Collaborator
  { collaboratorRole'Underscorename :: Text -- ^ Collaborator role
  , collaboratorUser'Underscoreid :: Int -- ^ Collaborator id
  , collaboratorName :: Text -- ^ Collaborator name
  } deriving (Show, Eq, Generic)

instance FromJSON Collaborator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collaborator")
instance ToJSON Collaborator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collaborator")

-- | 
data Collection = Collection
  { collectionId :: Integer -- ^ Collection id
  , collectionTitle :: Text -- ^ Collection title
  , collectionDoi :: Text -- ^ Collection DOI
  , collectionHandle :: Text -- ^ Collection Handle
  , collectionUrl :: Text -- ^ Api endpoint
  } deriving (Show, Eq, Generic)

instance FromJSON Collection where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collection")
instance ToJSON Collection where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collection")

-- | 
data CollectionCreate = CollectionCreate
  { collectionCreateFunding :: Text -- ^ Grant number or funding authority
  , collectionCreateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , collectionCreateTitle :: Text -- ^ Title of article
  , collectionCreateDescription :: Text -- ^ The article description. In a publisher case, usually this is the remote article description
  , collectionCreateArticles :: [Int] -- ^ List of articles to be associated with the collection
  , collectionCreateAuthors :: [Value] -- ^ List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. No more than 10 authors. For adding more authors use the specific authors endpoint.
  , collectionCreateCategories :: [Integer] -- ^ List of category ids to be associated with the article(e.g [1, 23, 33, 66])
  , collectionCreateTags :: [Text] -- ^ List of tags to be associated with the article. Keywords can be used instead
  , collectionCreateKeywords :: [Text] -- ^ List of tags to be associated with the article. Tags can be used instead
  , collectionCreateReferences :: [Text] -- ^ List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
  , collectionCreateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the article
  , collectionCreateDoi :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , collectionCreateHandle :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , collectionCreateResource'Underscoreid :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article id
  , collectionCreateResource'Underscoredoi :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article DOI.
  , collectionCreateResource'Underscorelink :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article link
  , collectionCreateResource'Underscoretitle :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article title.
  , collectionCreateResource'Underscoreversion :: Int -- ^ Not applicable to regular users. In a publisher case, this is the publisher article version
  , collectionCreateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  , collectionCreateTimeline :: TimelineUpdate -- ^ Various timeline dates
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionCreate")
instance ToJSON CollectionCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionCreate")

-- | 
data CollectionDOI = CollectionDOI
  { collectionDOIDoi :: Text -- ^ Reserved DOI
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionDOI where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionDOI")
instance ToJSON CollectionDOI where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionDOI")

-- | 
data CollectionHandle = CollectionHandle
  { collectionHandleHandle :: Text -- ^ Reserved Handle
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionHandle where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionHandle")
instance ToJSON CollectionHandle where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionHandle")

-- | 
data CollectionPrivateLinkCreator = CollectionPrivateLinkCreator
  { collectionPrivateLinkCreatorExpires'Underscoredate :: Text -- ^ Date when this private link should expire - optional. By default private links expire in 365 days.
  , collectionPrivateLinkCreatorRead'Underscoreonly :: Bool -- ^ Optional, default true. Set to false to give private link users editing rights for this collection.
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionPrivateLinkCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionPrivateLinkCreator")
instance ToJSON CollectionPrivateLinkCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionPrivateLinkCreator")

-- | 
data CollectionUpdate = CollectionUpdate
  { collectionUpdateFunding :: Text -- ^ Grant number or funding authority
  , collectionUpdateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , collectionUpdateTitle :: Text -- ^ Title of article
  , collectionUpdateDescription :: Text -- ^ The article description. In a publisher case, usually this is the remote article description
  , collectionUpdateArticles :: [Int] -- ^ List of articles to be associated with the collection
  , collectionUpdateAuthors :: [Value] -- ^ List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. No more than 10 authors. For adding more authors use the specific authors endpoint.
  , collectionUpdateCategories :: [Integer] -- ^ List of category ids to be associated with the article(e.g [1, 23, 33, 66])
  , collectionUpdateTags :: [Text] -- ^ List of tags to be associated with the article. Keywords can be used instead
  , collectionUpdateKeywords :: [Text] -- ^ List of tags to be associated with the article. Tags can be used instead
  , collectionUpdateReferences :: [Text] -- ^ List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
  , collectionUpdateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the article
  , collectionUpdateDoi :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , collectionUpdateHandle :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , collectionUpdateResource'Underscoreid :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article id
  , collectionUpdateResource'Underscoredoi :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article DOI.
  , collectionUpdateResource'Underscorelink :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article link
  , collectionUpdateResource'Underscoretitle :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article title.
  , collectionUpdateResource'Underscoreversion :: Int -- ^ Not applicable to regular users. In a publisher case, this is the publisher article version
  , collectionUpdateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  , collectionUpdateTimeline :: TimelineUpdate -- ^ Various timeline dates
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionUpdate")
instance ToJSON CollectionUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionUpdate")

-- | 
data CollectionVersions = CollectionVersions
  { collectionVersionsId :: Integer -- ^ Version number
  , collectionVersionsUrl :: Text -- ^ Api endpoint for the collection version
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionVersions where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionVersions")
instance ToJSON CollectionVersions where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionVersions")

-- | 
data CommonSearch = CommonSearch
  { commonSearchSearch'Underscorefor :: Text -- ^ Search term
  , commonSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , commonSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , commonSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , commonSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , commonSearchOrder'Underscoredirection :: Text -- ^ Direction of ordering
  , commonSearchInstitution :: Integer -- ^ only return collections from this institution
  , commonSearchPublished'Underscoresince :: Text -- ^ Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , commonSearchModified'Underscoresince :: Text -- ^ Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , commonSearchGroup :: Integer -- ^ only return collections from this group
  } deriving (Show, Eq, Generic)

instance FromJSON CommonSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "commonSearch")
instance ToJSON CommonSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "commonSearch")

-- | 
data ConfidentialityCreator = ConfidentialityCreator
  { confidentialityCreatorReason :: Text -- ^ Reason for confidentiality
  } deriving (Show, Eq, Generic)

instance FromJSON ConfidentialityCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "confidentialityCreator")
instance ToJSON ConfidentialityCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "confidentialityCreator")

-- | 
data Curation = Curation
  { curationId :: Integer -- ^ The review id
  , curationGroup'Underscoreid :: Integer -- ^ The group in which the article is present.
  , curationAccount'Underscoreid :: Integer -- ^ The ID of the account of the owner of the article of this review.
  , curationAssigned'Underscoreto :: Integer -- ^ The ID of the account to which this review is assigned.
  , curationArticle'Underscoreid :: Integer -- ^ The ID of the article of this review.
  , curationVersion :: Integer -- ^ The Version number of the article in review.
  , curationComments'Underscorecount :: Integer -- ^ The number of comments in the review.
  , curationStatus :: Text -- ^ The status of the review.
  , curationCreated'Underscoredate :: Text -- ^ The creation date of the review.
  , curationModified'Underscoredate :: Text -- ^ The date the review has been modified.
  } deriving (Show, Eq, Generic)

instance FromJSON Curation where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "curation")
instance ToJSON Curation where
  toJSON = genericToJSON (removeFieldLabelPrefix False "curation")

-- | 
data CurationComment = CurationComment
  { curationCommentId :: Integer -- ^ The ID of the comment.
  , curationCommentAccount'Underscoreid :: Integer -- ^ The ID of the account which generated this comment.
  , curationCommentType :: Text -- ^ The ID of the account which generated this comment.
  , curationCommentText :: Text -- ^ The value/content of the comment.
  } deriving (Show, Eq, Generic)

instance FromJSON CurationComment where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "curationComment")
instance ToJSON CurationComment where
  toJSON = genericToJSON (removeFieldLabelPrefix False "curationComment")

-- | 
data CurationCommentCreate = CurationCommentCreate
  { curationCommentCreateText :: Text -- ^ The contents/value of the comment
  } deriving (Show, Eq, Generic)

instance FromJSON CurationCommentCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "curationCommentCreate")
instance ToJSON CurationCommentCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "curationCommentCreate")

-- | 
data CustomArticleField = CustomArticleField
  { customArticleFieldName :: Text -- ^ Custom  metadata name
  , customArticleFieldValue :: Text -- ^ Custom metadata value
  } deriving (Show, Eq, Generic)

instance FromJSON CustomArticleField where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "customArticleField")
instance ToJSON CustomArticleField where
  toJSON = genericToJSON (removeFieldLabelPrefix False "customArticleField")

-- | 
data ErrorMessage = ErrorMessage
  { errorMessageCode :: Integer -- ^ A machine friendly error code, used by the dev team to identify the error.
  , errorMessageMessage :: Text -- ^ A human friendly message explaining the error.
  } deriving (Show, Eq, Generic)

instance FromJSON ErrorMessage where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "errorMessage")
instance ToJSON ErrorMessage where
  toJSON = genericToJSON (removeFieldLabelPrefix False "errorMessage")

-- | 
data FileCreator = FileCreator
  { fileCreatorLink :: Text -- ^ Url for an existing file that will not be uploaded on figshare
  , fileCreatorMd5 :: Text -- ^ MD5 sum pre computed on the client side
  , fileCreatorName :: Text -- ^ File name including the extension
  , fileCreatorSize :: Integer -- ^ File size in bytes
  } deriving (Show, Eq, Generic)

instance FromJSON FileCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "fileCreator")
instance ToJSON FileCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "fileCreator")

-- | 
data FundingCreate = FundingCreate
  { fundingCreateId :: Integer -- ^ A funding ID as returned by the Funding Search endpoint
  , fundingCreateTitle :: Text -- ^ The title of the new user created funding
  } deriving (Show, Eq, Generic)

instance FromJSON FundingCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "fundingCreate")
instance ToJSON FundingCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "fundingCreate")

-- | 
data FundingInformation = FundingInformation
  { fundingInformationId :: Integer -- ^ Funding id
  , fundingInformationTitle :: Text -- ^ The funding name
  , fundingInformationGrant'Underscorecode :: Text -- ^ The grant code
  , fundingInformationFunder'Underscorename :: Text -- ^ Funder's name
  , fundingInformationIs'Underscoreuser'Underscoredefined :: Bool -- ^ Return whether the grant has been introduced manually
  , fundingInformationUrl :: Text -- ^ The grant url
  } deriving (Show, Eq, Generic)

instance FromJSON FundingInformation where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "fundingInformation")
instance ToJSON FundingInformation where
  toJSON = genericToJSON (removeFieldLabelPrefix False "fundingInformation")

-- | 
data FundingSearch = FundingSearch
  { fundingSearchSearch'Underscorefor :: Text -- ^ Search term
  } deriving (Show, Eq, Generic)

instance FromJSON FundingSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "fundingSearch")
instance ToJSON FundingSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "fundingSearch")

-- | 
data Group = Group
  { groupId :: Integer -- ^ Group id
  , groupName :: Text -- ^ Group name
  , groupResource'Underscoreid :: Text -- ^ Group resource id
  , groupParent'Underscoreid :: Integer -- ^ Parent group if any
  , groupAssociation'Underscorecriteria :: Text -- ^ HR code associated with group, if code exists
  } deriving (Show, Eq, Generic)

instance FromJSON Group where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "group")
instance ToJSON Group where
  toJSON = genericToJSON (removeFieldLabelPrefix False "group")

-- | 
data GroupEmbargoOptions = GroupEmbargoOptions
  { groupEmbargoOptionsId :: Integer -- ^ Embargo option id
  , groupEmbargoOptionsType :: Text -- ^ Embargo permission type
  , groupEmbargoOptionsIp'Underscorename :: Text -- ^ IP range name; value appears if type is ip_range
  } deriving (Show, Eq, Generic)

instance FromJSON GroupEmbargoOptions where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "groupEmbargoOptions")
instance ToJSON GroupEmbargoOptions where
  toJSON = genericToJSON (removeFieldLabelPrefix False "groupEmbargoOptions")

-- | 
data Institution = Institution
  { institutionId :: Integer -- ^ Institution id
  , institutionName :: Text -- ^ Institution name
  } deriving (Show, Eq, Generic)

instance FromJSON Institution where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "institution")
instance ToJSON Institution where
  toJSON = genericToJSON (removeFieldLabelPrefix False "institution")

-- | 
data InstitutionAccountsSearch = InstitutionAccountsSearch
  { institutionAccountsSearchSearch'Underscorefor :: Text -- ^ Search term
  , institutionAccountsSearchIs'Underscoreactive :: Integer -- ^ Filter by active status
  , institutionAccountsSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , institutionAccountsSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , institutionAccountsSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , institutionAccountsSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , institutionAccountsSearchInstitution'Underscoreuser'Underscoreid :: Text -- ^ filter by institution_user_id
  , institutionAccountsSearchEmail :: Text -- ^ filter by email
  } deriving (Show, Eq, Generic)

instance FromJSON InstitutionAccountsSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "institutionAccountsSearch")
instance ToJSON InstitutionAccountsSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "institutionAccountsSearch")

-- | 
data License = License
  { licenseValue :: Integer -- ^ License value
  , licenseName :: Text -- ^ License name
  , licenseUrl :: Text -- ^ License url
  } deriving (Show, Eq, Generic)

instance FromJSON License where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "license")
instance ToJSON License where
  toJSON = genericToJSON (removeFieldLabelPrefix False "license")

-- | 
data Location = Location
  { locationLocation :: Text -- ^ Url for item
  } deriving (Show, Eq, Generic)

instance FromJSON Location where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "location")
instance ToJSON Location where
  toJSON = genericToJSON (removeFieldLabelPrefix False "location")

-- | 
data PrivateAuthorsSearch = PrivateAuthorsSearch
  { privateAuthorsSearchSearch'Underscorefor :: Text -- ^ Search term
  , privateAuthorsSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , privateAuthorsSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , privateAuthorsSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , privateAuthorsSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , privateAuthorsSearchOrder :: Text -- ^ The field by which to order. Default varies by endpoint/resource.
  , privateAuthorsSearchOrder'Underscoredirection :: Text -- ^ Direction of ordering
  , privateAuthorsSearchInstitution'Underscoreid :: Integer -- ^ Return only authors associated to this institution
  , privateAuthorsSearchOrcid :: Text -- ^ Orcid of author
  , privateAuthorsSearchGroup'Underscoreid :: Integer -- ^ Return only authors in this group or subgroups of the group
  , privateAuthorsSearchIs'Underscoreactive :: Bool -- ^ Return only active authors if True
  , privateAuthorsSearchIs'Underscorepublic :: Bool -- ^ Return only authors that have published items if True
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateAuthorsSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "privateAuthorsSearch")
instance ToJSON PrivateAuthorsSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "privateAuthorsSearch")

-- | 
data PrivateLink = PrivateLink
  { privateLinkId :: Text -- ^ Private link id
  , privateLinkIs'Underscoreactive :: Bool -- ^ True if private link is active
  , privateLinkExpires'Underscoredate :: Text -- ^ Date when link will expire
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateLink where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "privateLink")
instance ToJSON PrivateLink where
  toJSON = genericToJSON (removeFieldLabelPrefix False "privateLink")

-- | 
data PrivateLinkCreator = PrivateLinkCreator
  { privateLinkCreatorExpires'Underscoredate :: Text -- ^ Date when this private link should expire - optional. By default private links expire in 365 days.
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateLinkCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "privateLinkCreator")
instance ToJSON PrivateLinkCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "privateLinkCreator")

-- | 
data Project = Project
  { projectUrl :: Text -- ^ Api endpoint
  , projectId :: Integer -- ^ Project id
  , projectTitle :: Text -- ^ Project title
  } deriving (Show, Eq, Generic)

instance FromJSON Project where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "project")
instance ToJSON Project where
  toJSON = genericToJSON (removeFieldLabelPrefix False "project")

-- | 
data ProjectCollaborator = ProjectCollaborator
  { projectCollaboratorStatus :: Text -- ^ Status of collaborator invitation
  , projectCollaboratorRole'Underscorename :: Text -- ^ Collaborator role
  , projectCollaboratorUser'Underscoreid :: Int -- ^ Collaborator id
  , projectCollaboratorName :: Text -- ^ Collaborator name
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectCollaborator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectCollaborator")
instance ToJSON ProjectCollaborator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectCollaborator")

-- | 
data ProjectCollaboratorInvite = ProjectCollaboratorInvite
  { projectCollaboratorInviteRole'Underscorename :: Text -- ^ Role of the the collaborator inside the project
  , projectCollaboratorInviteUser'Underscoreid :: Integer -- ^ User id of the collaborator
  , projectCollaboratorInviteEmail :: Text -- ^ Collaborator email
  , projectCollaboratorInviteComment :: Text -- ^ Text sent when inviting the user to the project
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectCollaboratorInvite where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectCollaboratorInvite")
instance ToJSON ProjectCollaboratorInvite where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectCollaboratorInvite")

-- | 
data ProjectCreate = ProjectCreate
  { projectCreateTitle :: Text -- ^ The title for this project - mandatory. 3 - 1000 characters.
  , projectCreateDescription :: Text -- ^ Project description
  , projectCreateFunding :: Text -- ^ Grant number or organization(s) that funded this project. Up to 2000 characters permitted.
  , projectCreateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , projectCreateGroup'Underscoreid :: Integer -- ^ Only if project type is group.
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectCreate")
instance ToJSON ProjectCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectCreate")

-- | 
data ProjectNote = ProjectNote
  { projectNoteId :: Integer -- ^ Project note id
  , projectNoteUser'Underscoreid :: Integer -- ^ User who wrote the note
  , projectNoteAbstract :: Text -- ^ Note Abstract - short/truncated content
  , projectNoteUser'Underscorename :: Text -- ^ Username of the one who wrote the note
  , projectNoteCreated'Underscoredate :: Text -- ^ Date when note was created
  , projectNoteModified'Underscoredate :: Text -- ^ Date when note was last modified
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectNote where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectNote")
instance ToJSON ProjectNote where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectNote")

-- | 
data ProjectNoteCreate = ProjectNoteCreate
  { projectNoteCreateText :: Text -- ^ Text of the note
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectNoteCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectNoteCreate")
instance ToJSON ProjectNoteCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectNoteCreate")

-- | 
data ProjectUpdate = ProjectUpdate
  { projectUpdateTitle :: Text -- ^ The title for this project - mandatory. 3 - 1000 characters.
  , projectUpdateDescription :: Text -- ^ Project description
  , projectUpdateFunding :: Text -- ^ Grant number or organization(s) that funded this project. Up to 2000 characters permitted.
  , projectUpdateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectUpdate")
instance ToJSON ProjectUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectUpdate")

-- | 
data PublicFile = PublicFile
  { publicFileId :: Integer -- ^ File id
  , publicFileName :: Text -- ^ File name
  , publicFileSize :: Integer -- ^ File size
  , publicFileIs'Underscorelink'Underscoreonly :: Bool -- ^ True if file is hosted somewhere else
  , publicFileDownload'Underscoreurl :: Text -- ^ Url for file download
  , publicFileSupplied'Underscoremd5 :: Text -- ^ File supplied md5
  , publicFileComputed'Underscoremd5 :: Text -- ^ File computed md5
  } deriving (Show, Eq, Generic)

instance FromJSON PublicFile where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "publicFile")
instance ToJSON PublicFile where
  toJSON = genericToJSON (removeFieldLabelPrefix False "publicFile")

-- | 
data ResponseMessage = ResponseMessage
  { responseMessageMessage :: Text -- ^ Response message text
  } deriving (Show, Eq, Generic)

instance FromJSON ResponseMessage where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "responseMessage")
instance ToJSON ResponseMessage where
  toJSON = genericToJSON (removeFieldLabelPrefix False "responseMessage")

-- | 
data Role = Role
  { roleId :: Integer -- ^ Role id
  , roleName :: Text -- ^ Role name
  , roleCategory :: Text -- ^ Role category
  , roleDescription :: Text -- ^ Role description
  } deriving (Show, Eq, Generic)

instance FromJSON Role where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "role")
instance ToJSON Role where
  toJSON = genericToJSON (removeFieldLabelPrefix False "role")

-- | 
data ShortAccount = ShortAccount
  { shortAccountId :: Integer -- ^ Account id
  , shortAccountFirst'Underscorename :: Text -- ^ First Name
  , shortAccountLast'Underscorename :: Text -- ^ Last Name
  , shortAccountInstitution'Underscoreid :: Integer -- ^ Account institution
  , shortAccountEmail :: Text -- ^ User email
  , shortAccountActive :: Integer -- ^ Account activity status
  , shortAccountInstitution'Underscoreuser'Underscoreid :: Text -- ^ Account institution user id
  } deriving (Show, Eq, Generic)

instance FromJSON ShortAccount where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "shortAccount")
instance ToJSON ShortAccount where
  toJSON = genericToJSON (removeFieldLabelPrefix False "shortAccount")

-- | 
data TimelineUpdate = TimelineUpdate
  { timelineUpdateFirstOnline :: Text -- ^ Online posted date
  , timelineUpdatePublisherPublication :: Text -- ^ Publish date
  , timelineUpdatePublisherAcceptance :: Text -- ^ Date when the item was accepted for publication
  } deriving (Show, Eq, Generic)

instance FromJSON TimelineUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "timelineUpdate")
instance ToJSON TimelineUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "timelineUpdate")

-- | 
data UploadFilePart = UploadFilePart
  { uploadFilePartPartNo :: Integer -- ^ File part id
  , uploadFilePartStartOffset :: Integer -- ^ Indexes on byte range. zero-based and inclusive
  , uploadFilePartEndOffset :: Integer -- ^ Indexes on byte range. zero-based and inclusive
  , uploadFilePartStatus :: Text -- ^ part status
  , uploadFilePartLocked :: Bool -- ^ When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests.
  } deriving (Show, Eq, Generic)

instance FromJSON UploadFilePart where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "uploadFilePart")
instance ToJSON UploadFilePart where
  toJSON = genericToJSON (removeFieldLabelPrefix False "uploadFilePart")

-- | 
data UploadInfo = UploadInfo
  { uploadInfoToken :: Text -- ^ token received after initializing a file upload
  , uploadInfoMd5 :: Text -- ^ md5 provided on upload initialization
  , uploadInfoSize :: Integer -- ^ size of file in bytes
  , uploadInfoName :: Text -- ^ name of file on upload server
  , uploadInfoStatus :: Text -- ^ Upload status
  , uploadInfoParts :: [UploadFilePart] -- ^ Uploads parts
  } deriving (Show, Eq, Generic)

instance FromJSON UploadInfo where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "uploadInfo")
instance ToJSON UploadInfo where
  toJSON = genericToJSON (removeFieldLabelPrefix False "uploadInfo")

-- | 
data User = User
  { userId :: Integer -- ^ User id
  , userFirst'Underscorename :: Text -- ^ First Name
  , userLast'Underscorename :: Text -- ^ Last Name
  , userName :: Text -- ^ Full Name
  , userIs'Underscoreactive :: Bool -- ^ Account activity status
  , userUrl'Underscorename :: Text -- ^ Name that appears in website url
  , userIs'Underscorepublic :: Bool -- ^ Account public status
  , userJob'Underscoretitle :: Text -- ^ User Job title
  , userOrcid'Underscoreid :: Text -- ^ Orcid associated to this User
  } deriving (Show, Eq, Generic)

instance FromJSON User where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "user")
instance ToJSON User where
  toJSON = genericToJSON (removeFieldLabelPrefix False "user")

-- | 
 ArticleSearch = ArticleSearch
  { articleSearchSearch'Underscorefor :: Text -- ^ Search term
  , articleSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , articleSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , articleSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , articleSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , articleSearchOrder'Underscoredirection :: Text -- ^ Direction of ordering
  , articleSearchInstitution :: Integer -- ^ only return collections from this institution
  , articleSearchPublished'Underscoresince :: Text -- ^ Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , articleSearchModified'Underscoresince :: Text -- ^ Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , articleSearchGroup :: Integer -- ^ only return collections from this group
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON ArticleSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 AuthorComplete = AuthorComplete
  { authorCompleteId :: Integer -- ^ Author id
  , authorCompleteFull'Underscorename :: Text -- ^ Author full name
  , authorCompleteIs'Underscoreactive :: Bool -- ^ True if author has published items
  , authorCompleteUrl'Underscorename :: Text -- ^ Author url name
  , authorCompleteOrcid'Underscoreid :: Text -- ^ Author Orcid
  } deriving (Show, Eq, Generic)

instance FromJSON AuthorComplete where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON AuthorComplete where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 CollectionComplete = CollectionComplete
  { collectionCompleteId :: Integer -- ^ Collection id
  , collectionCompleteTitle :: Text -- ^ Collection title
  , collectionCompleteDoi :: Text -- ^ Collection DOI
  , collectionCompleteHandle :: Text -- ^ Collection Handle
  , collectionCompleteUrl :: Text -- ^ Api endpoint
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionComplete where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON CollectionComplete where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 CollectionSearch = CollectionSearch
  { collectionSearchSearch'Underscorefor :: Text -- ^ Search term
  , collectionSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , collectionSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , collectionSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , collectionSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , collectionSearchOrder'Underscoredirection :: Text -- ^ Direction of ordering
  , collectionSearchInstitution :: Integer -- ^ only return collections from this institution
  , collectionSearchPublished'Underscoresince :: Text -- ^ Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , collectionSearchModified'Underscoresince :: Text -- ^ Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , collectionSearchGroup :: Integer -- ^ only return collections from this group
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON CollectionSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 CurationDetail = CurationDetail
  { curationDetailId :: Integer -- ^ The review id
  , curationDetailGroup'Underscoreid :: Integer -- ^ The group in which the article is present.
  , curationDetailAccount'Underscoreid :: Integer -- ^ The ID of the account of the owner of the article of this review.
  , curationDetailAssigned'Underscoreto :: Integer -- ^ The ID of the account to which this review is assigned.
  , curationDetailArticle'Underscoreid :: Integer -- ^ The ID of the article of this review.
  , curationDetailVersion :: Integer -- ^ The Version number of the article in review.
  , curationDetailComments'Underscorecount :: Integer -- ^ The number of comments in the review.
  , curationDetailStatus :: Text -- ^ The status of the review.
  , curationDetailCreated'Underscoredate :: Text -- ^ The creation date of the review.
  , curationDetailModified'Underscoredate :: Text -- ^ The date the review has been modified.
  } deriving (Show, Eq, Generic)

instance FromJSON CurationDetail where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON CurationDetail where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 PrivateFile = PrivateFile
  { privateFileId :: Integer -- ^ File id
  , privateFileName :: Text -- ^ File name
  , privateFileSize :: Integer -- ^ File size
  , privateFileIs'Underscorelink'Underscoreonly :: Bool -- ^ True if file is hosted somewhere else
  , privateFileDownload'Underscoreurl :: Text -- ^ Url for file download
  , privateFileSupplied'Underscoremd5 :: Text -- ^ File supplied md5
  , privateFileComputed'Underscoremd5 :: Text -- ^ File computed md5
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateFile where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON PrivateFile where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 ProjectArticle = ProjectArticle
  { projectArticleId :: Integer -- ^ Unique identifier for article
  , projectArticleTitle :: Text -- ^ Title of article
  , projectArticleDoi :: Text -- ^ DOI
  , projectArticleHandle :: Text -- ^ Handle
  , projectArticleUrl :: Text -- ^ Api endpoint for article
  , projectArticleUrl'Underscorepublic'Underscorehtml :: Text -- ^ Public site endpoint for article
  , projectArticleUrl'Underscorepublic'Underscoreapi :: Text -- ^ Public Api endpoint for article
  , projectArticleUrl'Underscoreprivate'Underscorehtml :: Text -- ^ Private site endpoint for article
  , projectArticleUrl'Underscoreprivate'Underscoreapi :: Text -- ^ Private Api endpoint for article
  , projectArticleTimeline :: Timeline -- ^ Various timeline dates
  , projectArticleThumb :: Text -- ^ Thumbnail image
  , projectArticleDefined'Underscoretype :: Integer -- ^ Type of article identificator
  , projectArticleDefined'Underscoretype'Underscorename :: Text -- ^ Name of the article type identificator
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectArticle where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON ProjectArticle where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 ProjectComplete = ProjectComplete
  { projectCompleteUrl :: Text -- ^ Api endpoint
  , projectCompleteId :: Integer -- ^ Project id
  , projectCompleteTitle :: Text -- ^ Project title
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectComplete where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON ProjectComplete where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 ProjectNotePrivate = ProjectNotePrivate
  { projectNotePrivateId :: Integer -- ^ Project note id
  , projectNotePrivateUser'Underscoreid :: Integer -- ^ User who wrote the note
  , projectNotePrivateAbstract :: Text -- ^ Note Abstract - short/truncated content
  , projectNotePrivateUser'Underscorename :: Text -- ^ Username of the one who wrote the note
  , projectNotePrivateCreated'Underscoredate :: Text -- ^ Date when note was created
  , projectNotePrivateModified'Underscoredate :: Text -- ^ Date when note was last modified
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectNotePrivate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON ProjectNotePrivate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 ProjectPrivate = ProjectPrivate
  { projectPrivateUrl :: Text -- ^ Api endpoint
  , projectPrivateId :: Integer -- ^ Project id
  , projectPrivateTitle :: Text -- ^ Project title
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectPrivate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON ProjectPrivate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 ProjectsSearch = ProjectsSearch
  { projectsSearchSearch'Underscorefor :: Text -- ^ Search term
  , projectsSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , projectsSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , projectsSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , projectsSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , projectsSearchOrder'Underscoredirection :: Text -- ^ Direction of ordering
  , projectsSearchInstitution :: Integer -- ^ only return collections from this institution
  , projectsSearchPublished'Underscoresince :: Text -- ^ Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , projectsSearchModified'Underscoresince :: Text -- ^ Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , projectsSearchGroup :: Integer -- ^ only return collections from this group
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectsSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON ProjectsSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 Timeline = Timeline
  { timelineFirstOnline :: Text -- ^ Online posted date
  , timelinePublisherPublication :: Text -- ^ Publish date
  , timelinePublisherAcceptance :: Text -- ^ Date when the item was accepted for publication
  } deriving (Show, Eq, Generic)

instance FromJSON Timeline where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON Timeline where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 ArticleComplete = ArticleComplete
  { articleCompleteId :: Integer -- ^ Unique identifier for article
  , articleCompleteTitle :: Text -- ^ Title of article
  , articleCompleteDoi :: Text -- ^ DOI
  , articleCompleteHandle :: Text -- ^ Handle
  , articleCompleteUrl :: Text -- ^ Api endpoint for article
  , articleCompleteUrl'Underscorepublic'Underscorehtml :: Text -- ^ Public site endpoint for article
  , articleCompleteUrl'Underscorepublic'Underscoreapi :: Text -- ^ Public Api endpoint for article
  , articleCompleteUrl'Underscoreprivate'Underscorehtml :: Text -- ^ Private site endpoint for article
  , articleCompleteUrl'Underscoreprivate'Underscoreapi :: Text -- ^ Private Api endpoint for article
  , articleCompleteTimeline :: Timeline -- ^ Various timeline dates
  , articleCompleteThumb :: Text -- ^ Thumbnail image
  , articleCompleteDefined'Underscoretype :: Integer -- ^ Type of article identificator
  , articleCompleteDefined'Underscoretype'Underscorename :: Text -- ^ Name of the article type identificator
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleComplete where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON ArticleComplete where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 PrivateArticleSearch = PrivateArticleSearch
  { privateArticleSearchSearch'Underscorefor :: Text -- ^ Search term
  , privateArticleSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , privateArticleSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , privateArticleSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , privateArticleSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , privateArticleSearchOrder'Underscoredirection :: Text -- ^ Direction of ordering
  , privateArticleSearchInstitution :: Integer -- ^ only return collections from this institution
  , privateArticleSearchPublished'Underscoresince :: Text -- ^ Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , privateArticleSearchModified'Underscoresince :: Text -- ^ Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , privateArticleSearchGroup :: Integer -- ^ only return collections from this group
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateArticleSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON PrivateArticleSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 PrivateCollectionSearch = PrivateCollectionSearch
  { privateCollectionSearchSearch'Underscorefor :: Text -- ^ Search term
  , privateCollectionSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , privateCollectionSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , privateCollectionSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , privateCollectionSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , privateCollectionSearchOrder'Underscoredirection :: Text -- ^ Direction of ordering
  , privateCollectionSearchInstitution :: Integer -- ^ only return collections from this institution
  , privateCollectionSearchPublished'Underscoresince :: Text -- ^ Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , privateCollectionSearchModified'Underscoresince :: Text -- ^ Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , privateCollectionSearchGroup :: Integer -- ^ only return collections from this group
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateCollectionSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON PrivateCollectionSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 ProjectCompletePrivate = ProjectCompletePrivate
  { projectCompletePrivateUrl :: Text -- ^ Api endpoint
  , projectCompletePrivateId :: Integer -- ^ Project id
  , projectCompletePrivateTitle :: Text -- ^ Project title
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectCompletePrivate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON ProjectCompletePrivate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- | 
 ArticleCompletePrivate = ArticleCompletePrivate
  { articleCompletePrivateId :: Integer -- ^ Unique identifier for article
  , articleCompletePrivateTitle :: Text -- ^ Title of article
  , articleCompletePrivateDoi :: Text -- ^ DOI
  , articleCompletePrivateHandle :: Text -- ^ Handle
  , articleCompletePrivateUrl :: Text -- ^ Api endpoint for article
  , articleCompletePrivateUrl'Underscorepublic'Underscorehtml :: Text -- ^ Public site endpoint for article
  , articleCompletePrivateUrl'Underscorepublic'Underscoreapi :: Text -- ^ Public Api endpoint for article
  , articleCompletePrivateUrl'Underscoreprivate'Underscorehtml :: Text -- ^ Private site endpoint for article
  , articleCompletePrivateUrl'Underscoreprivate'Underscoreapi :: Text -- ^ Private Api endpoint for article
  , articleCompletePrivateTimeline :: Timeline -- ^ Various timeline dates
  , articleCompletePrivateThumb :: Text -- ^ Thumbnail image
  , articleCompletePrivateDefined'Underscoretype :: Integer -- ^ Type of article identificator
  , articleCompletePrivateDefined'Underscoretype'Underscorename :: Text -- ^ Name of the article type identificator
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleCompletePrivate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "")
instance ToJSON ArticleCompletePrivate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "")

-- Remove a field label prefix during JSON parsing.
-- Also perform any replacements for special characters.
removeFieldLabelPrefix :: Bool -> String -> Options
removeFieldLabelPrefix forParsing prefix =
  defaultOptions
  {fieldLabelModifier = fromMaybe (error ("did not find prefix " ++ prefix)) . stripPrefix prefix . replaceSpecialChars}
  where
    replaceSpecialChars field = foldl (&) field (map mkCharReplacement specialChars)
    specialChars =
      [ ("@", "'At")
      , ("\\", "'Back_Slash")
      , ("<=", "'Less_Than_Or_Equal_To")
      , ("\"", "'Double_Quote")
      , ("[", "'Left_Square_Bracket")
      , ("]", "'Right_Square_Bracket")
      , ("^", "'Caret")
      , ("_", "'Underscore")
      , ("`", "'Backtick")
      , ("!", "'Exclamation")
      , ("#", "'Hash")
      , ("$", "'Dollar")
      , ("%", "'Percent")
      , ("&", "'Ampersand")
      , ("'", "'Quote")
      , ("(", "'Left_Parenthesis")
      , (")", "'Right_Parenthesis")
      , ("*", "'Star")
      , ("+", "'Plus")
      , (",", "'Comma")
      , ("-", "'Dash")
      , (".", "'Period")
      , ("/", "'Slash")
      , (":", "'Colon")
      , ("{", "'Left_Curly_Bracket")
      , ("|", "'Pipe")
      , ("<", "'LessThan")
      , ("!=", "'Not_Equal")
      , ("=", "'Equal")
      , ("}", "'Right_Curly_Bracket")
      , (">", "'GreaterThan")
      , ("~", "'Tilde")
      , ("?", "'Question_Mark")
      , (">=", "'Greater_Than_Or_Equal_To")
      ]
    mkCharReplacement (replaceStr, searchStr) = T.unpack . replacer (T.pack searchStr) (T.pack replaceStr) . T.pack
    replacer =
      if forParsing
        then flip T.replace
        else T.replace
