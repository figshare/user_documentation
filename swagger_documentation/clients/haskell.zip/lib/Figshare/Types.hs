{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# OPTIONS_GHC -fno-warn-unused-binds -fno-warn-unused-imports #-}

module Figshare.Types (
  Account (..),
  AccountCreate (..),
  AccountGroupRoles (..),
  AccountGroupRolesCreate (..),
  AccountReport (..),
  AccountUpdate (..),
  Article (..),
  ArticleComplete (..),
  ArticleCompletePrivate (..),
  ArticleConfidentiality (..),
  ArticleCreate (..),
  ArticleDOI (..),
  ArticleEmbargo (..),
  ArticleEmbargoUpdater (..),
  ArticleHandle (..),
  ArticleProjectCreate (..),
  ArticleSearch (..),
  ArticleUpdate (..),
  ArticleVersions (..),
  ArticleWithProject (..),
  ArticlesCreator (..),
  Author (..),
  AuthorComplete (..),
  AuthorsCreator (..),
  CategoriesCreator (..),
  Category (..),
  Collaborator (..),
  Collection (..),
  CollectionComplete (..),
  CollectionCompletePrivate (..),
  CollectionCreate (..),
  CollectionDOI (..),
  CollectionHandle (..),
  CollectionPrivateLinkCreator (..),
  CollectionSearch (..),
  CollectionUpdate (..),
  CollectionVersions (..),
  CommonSearch (..),
  ConfidentialityCreator (..),
  CreateProjectResponse (..),
  Curation (..),
  CurationComment (..),
  CurationCommentCreate (..),
  CurationDetail (..),
  CustomArticleField (..),
  CustomArticleFieldAdd (..),
  ErrorMessage (..),
  FileCreator (..),
  FileId (..),
  FundingCreate (..),
  FundingInformation (..),
  FundingSearch (..),
  Group (..),
  GroupEmbargoOptions (..),
  Institution (..),
  InstitutionAccountsSearch (..),
  ItemType (..),
  License (..),
  Location (..),
  LocationWarnings (..),
  LocationWarningsUpdate (..),
  PrivateArticleSearch (..),
  PrivateAuthorsSearch (..),
  PrivateCollectionSearch (..),
  PrivateFile (..),
  PrivateLink (..),
  PrivateLinkCreator (..),
  PrivateLinkResponse (..),
  Project (..),
  ProjectArticle (..),
  ProjectCollaborator (..),
  ProjectCollaboratorInvite (..),
  ProjectComplete (..),
  ProjectCompletePrivate (..),
  ProjectCreate (..),
  ProjectNote (..),
  ProjectNoteCreate (..),
  ProjectNotePrivate (..),
  ProjectPrivate (..),
  ProjectUpdate (..),
  ProjectsSearch (..),
  PublicFile (..),
  RelatedMaterial (..),
  Resource (..),
  ResponseMessage (..),
  Role (..),
  ShortAccount (..),
  ShortCustomField (..),
  Timeline (..),
  TimelineUpdate (..),
  UploadFilePart (..),
  UploadInfo (..),
  User (..),
  ) where

import Data.List (stripPrefix)
import Data.Maybe (fromMaybe)
import Data.Aeson (Value, FromJSON(..), ToJSON(..), genericToJSON, genericParseJSON)
import Data.Aeson.Types (Options(..), defaultOptions)
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Map as Map
import GHC.Generics (Generic)
import Data.Function ((&))


-- | 
data Account = Account
  { accountId :: Integer -- ^ Account id
  , accountFirst'Underscorename :: Text -- ^ First Name
  , accountLast'Underscorename :: Text -- ^ Last Name
  , accountUsed'Underscorequota'Underscoreprivate :: Integer -- ^ Account used private quota
  , accountModified'Underscoredate :: Text -- ^ Date of last account modification
  , accountUsed'Underscorequota :: Integer -- ^ Account total used quota
  , accountCreated'Underscoredate :: Text -- ^ Date when account was created
  , accountQuota :: Integer -- ^ Account quota
  , accountGroup'Underscoreid :: Integer -- ^ Account group id
  , accountInstitution'Underscoreuser'Underscoreid :: Text -- ^ Account institution user id
  , accountInstitution'Underscoreid :: Integer -- ^ Account institution
  , accountEmail :: Text -- ^ User email
  , accountUsed'Underscorequota'Underscorepublic :: Integer -- ^ Account public used quota
  , accountPending'Underscorequota'Underscorerequest :: Bool -- ^ True if a quota request is pending
  , accountActive :: Integer -- ^ Account activity status
  , accountMaximum'Underscorefile'Underscoresize :: Integer -- ^ Maximum upload size for account
  } deriving (Show, Eq, Generic)

instance FromJSON Account where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "account")
instance ToJSON Account where
  toJSON = genericToJSON (removeFieldLabelPrefix False "account")

-- | 
data AccountCreate = AccountCreate
  { accountCreateEmail :: Text -- ^ Email of account
  , accountCreateFirst'Underscorename :: Text -- ^ First Name
  , accountCreateLast'Underscorename :: Text -- ^ Last Name
  , accountCreateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  , accountCreateInstitution'Underscoreuser'Underscoreid :: Text -- ^ Institution user id
  , accountCreateSymplectic'Underscoreuser'Underscoreid :: Text -- ^ Symplectic user id
  , accountCreateQuota :: Integer -- ^ Account quota
  , accountCreateIs'Underscoreactive :: Bool -- ^ Is account active
  } deriving (Show, Eq, Generic)

instance FromJSON AccountCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountCreate")
instance ToJSON AccountCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountCreate")

-- | 
data AccountGroupRoles = AccountGroupRoles
  { 
  } deriving (Show, Eq, Generic)

instance FromJSON AccountGroupRoles where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountGroupRoles")
instance ToJSON AccountGroupRoles where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountGroupRoles")

-- | 
data AccountGroupRolesCreate = AccountGroupRolesCreate
  { 
  } deriving (Show, Eq, Generic)

instance FromJSON AccountGroupRolesCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountGroupRolesCreate")
instance ToJSON AccountGroupRolesCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountGroupRolesCreate")

-- | 
data AccountReport = AccountReport
  { accountReportId :: Integer -- ^ A unique ID for the AccountRecord
  , accountReportAccount'Underscoreid :: Integer -- ^ The ID of the account which generated this report.
  , accountReportCreated'Underscoredate :: Text -- ^ Date when the AccountReport was requested
  , accountReportStatus :: Text -- ^ Status of the report
  , accountReportDownload'Underscoreurl :: Text -- ^ The download link for the generated XLSX
  , accountReportGroup'Underscoreid :: Integer -- ^ The group ID that was used to filter the report, if any.
  } deriving (Show, Eq, Generic)

instance FromJSON AccountReport where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountReport")
instance ToJSON AccountReport where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountReport")

-- | 
data AccountUpdate = AccountUpdate
  { accountUpdateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  , accountUpdateIs'Underscoreactive :: Bool -- ^ Is account active
  } deriving (Show, Eq, Generic)

instance FromJSON AccountUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "accountUpdate")
instance ToJSON AccountUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "accountUpdate")

-- | 
data Article = Article
  { articleId :: Integer -- ^ Unique identifier for article
  , articleTitle :: Text -- ^ Title of article
  , articleDoi :: Text -- ^ DOI
  , articleHandle :: Text -- ^ Handle
  , articleUrl :: Text -- ^ Api endpoint for article
  , articleUrl'Underscorepublic'Underscorehtml :: Text -- ^ Public site endpoint for article
  , articleUrl'Underscorepublic'Underscoreapi :: Text -- ^ Public Api endpoint for article
  , articleUrl'Underscoreprivate'Underscorehtml :: Text -- ^ Private site endpoint for article
  , articleUrl'Underscoreprivate'Underscoreapi :: Text -- ^ Private Api endpoint for article
  , articleTimeline :: Timeline -- ^ Various timeline dates
  , articleThumb :: Text -- ^ Thumbnail image
  , articleDefined'Underscoretype :: Integer -- ^ Type of article identifier
  , articleDefined'Underscoretype'Underscorename :: Text -- ^ Name of the article type identifier
  } deriving (Show, Eq, Generic)

instance FromJSON Article where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "article")
instance ToJSON Article where
  toJSON = genericToJSON (removeFieldLabelPrefix False "article")

-- | 
newtype ArticleComplete = ArticleComplete { unArticleComplete :: ProjectArticle }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
newtype ArticleCompletePrivate = ArticleCompletePrivate { unArticleCompletePrivate :: ArticleComplete }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data ArticleConfidentiality = ArticleConfidentiality
  { articleConfidentialityIs'Underscoreconfidential :: Bool -- ^ True if article is confidential
  , articleConfidentialityReason :: Text -- ^ Reason for confidentiality
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleConfidentiality where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleConfidentiality")
instance ToJSON ArticleConfidentiality where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleConfidentiality")

-- | 
data ArticleCreate = ArticleCreate
  { articleCreateTitle :: Text -- ^ Title of article
  , articleCreateDescription :: Text -- ^ The article description. In a publisher case, usually this is the remote article description
  , articleCreateIs'Underscoremetadata'Underscorerecord :: Bool -- ^ True if article has no files
  , articleCreateMetadata'Underscorereason :: Text -- ^ Article metadata reason
  , articleCreateTags :: [Text] -- ^ List of tags to be associated with the article. Keywords can be used instead
  , articleCreateKeywords :: [Text] -- ^ List of tags to be associated with the article. Tags can be used instead
  , articleCreateReferences :: [Text] -- ^ List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
  , articleCreateRelated'Underscorematerials :: [Value] -- ^ List of related materials; supersedes references.
  , articleCreateCategories :: [Integer] -- ^ List of category ids to be associated with the article(e.g [1, 23, 33, 66])
  , articleCreateCategories'Underscoreby'Underscoresource'Underscoreid :: [Text] -- ^ List of category source ids to be associated with the article, supersedes the categories property
  , articleCreateAuthors :: [Value] -- ^ List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint.
  , articleCreateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the article
  , articleCreateCustom'Underscorefields'Underscorelist :: [CustomArticleFieldAdd] -- ^ List of custom fields values, supersedes custom_fields parameter
  , articleCreateDefined'Underscoretype :: Text -- ^ <b>One of:</b> <code>figure</code> <code>online resource</code> <code>preprint</code> <code>book</code> <code>conference contribution</code> <code>media</code> <code>dataset</code> <code>poster</code> <code>journal contribution</code> <code>presentation</code> <code>thesis</code> <code>software</code>
  , articleCreateFunding :: Text -- ^ Grant number or funding authority
  , articleCreateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , articleCreateLicense :: Integer -- ^ License id for this article.
  , articleCreateDoi :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleCreateHandle :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleCreateResource'Underscoredoi :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article DOI.
  , articleCreateResource'Underscoretitle :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article title.
  , articleCreateTimeline :: TimelineUpdate -- ^ Various timeline dates
  , articleCreateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleCreate")
instance ToJSON ArticleCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleCreate")

-- | 
data ArticleDOI = ArticleDOI
  { articleDOIDoi :: Text -- ^ Reserved DOI
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleDOI where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleDOI")
instance ToJSON ArticleDOI where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleDOI")

-- | 
data ArticleEmbargo = ArticleEmbargo
  { articleEmbargoIs'Underscoreembargoed :: Bool -- ^ True if embargoed
  , articleEmbargoEmbargo'Underscoretitle :: Text -- ^ Title for embargo
  , articleEmbargoEmbargo'Underscorereason :: Text -- ^ Reason for embargo
  , articleEmbargoEmbargo'Underscoreoptions :: [Value] -- ^ List of embargo permissions that are associated with the article. If the type is logged_in and the group_ids list is empty, then the whole institution can see the article; if there are multiple group_ids, then only users that are under those groups can see the article.
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleEmbargo where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleEmbargo")
instance ToJSON ArticleEmbargo where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleEmbargo")

-- | 
data ArticleEmbargoUpdater = ArticleEmbargoUpdater
  { articleEmbargoUpdaterIs'Underscoreembargoed :: Bool -- ^ Embargo status
  , articleEmbargoUpdaterEmbargo'Underscoredate :: Text -- ^ Date when the embargo expires and the article gets published, '0' value will set up permanent embargo
  , articleEmbargoUpdaterEmbargo'Underscoretype :: Text -- ^ Embargo can be enabled at the article or the file level. Possible values: article, file
  , articleEmbargoUpdaterEmbargo'Underscoretitle :: Text -- ^ Title for embargo
  , articleEmbargoUpdaterEmbargo'Underscorereason :: Text -- ^ Reason for setting embargo
  , articleEmbargoUpdaterEmbargo'Underscoreoptions :: [Value] -- ^ List of embargo permissions to be associated with the article. The list must contain `id` and can also contain `group_ids`(a field that only applies to 'logged_in' permissions). The new list replaces old options in the database, and an empty list removes all permissions for this article. Administration permission has to be set up alone but logged in and IP range permissions can be set up together.
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleEmbargoUpdater where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleEmbargoUpdater")
instance ToJSON ArticleEmbargoUpdater where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleEmbargoUpdater")

-- | 
data ArticleHandle = ArticleHandle
  { articleHandleHandle :: Text -- ^ Reserved Handle
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleHandle where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleHandle")
instance ToJSON ArticleHandle where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleHandle")

-- | 
data ArticleProjectCreate = ArticleProjectCreate
  { articleProjectCreateTitle :: Text -- ^ Title of article
  , articleProjectCreateDescription :: Text -- ^ The article description. In a publisher case, usually this is the remote article description
  , articleProjectCreateTags :: [Text] -- ^ List of tags to be associated with the article. Keywords can be used instead
  , articleProjectCreateKeywords :: [Text] -- ^ List of tags to be associated with the article. Tags can be used instead
  , articleProjectCreateReferences :: [Text] -- ^ List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
  , articleProjectCreateRelated'Underscorematerials :: [Value] -- ^ List of related materials; supersedes references.
  , articleProjectCreateCategories :: [Integer] -- ^ List of category ids to be associated with the article(e.g [1, 23, 33, 66])
  , articleProjectCreateCategories'Underscoreby'Underscoresource'Underscoreid :: [Text] -- ^ List of category source ids to be associated with the article, supersedes the categories property
  , articleProjectCreateAuthors :: [Value] -- ^ List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint.
  , articleProjectCreateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the article
  , articleProjectCreateCustom'Underscorefields'Underscorelist :: [CustomArticleFieldAdd] -- ^ List of custom fields values, supersedes custom_fields parameter
  , articleProjectCreateDefined'Underscoretype :: Text -- ^ <b>One of:</b> <code>figure</code> <code>online resource</code> <code>preprint</code> <code>book</code> <code>conference contribution</code> <code>media</code> <code>dataset</code> <code>poster</code> <code>journal contribution</code> <code>presentation</code> <code>thesis</code> <code>software</code>
  , articleProjectCreateFunding :: Text -- ^ Grant number or funding authority
  , articleProjectCreateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , articleProjectCreateLicense :: Integer -- ^ License id for this article.
  , articleProjectCreateDoi :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleProjectCreateHandle :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleProjectCreateResource'Underscoredoi :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article DOI.
  , articleProjectCreateResource'Underscoretitle :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article title.
  , articleProjectCreateTimeline :: TimelineUpdate -- ^ Various timeline dates
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleProjectCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleProjectCreate")
instance ToJSON ArticleProjectCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleProjectCreate")

-- | 
newtype ArticleSearch = ArticleSearch { unArticleSearch :: CommonSearch }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data ArticleUpdate = ArticleUpdate
  { articleUpdateTitle :: Text -- ^ Title of article
  , articleUpdateDescription :: Text -- ^ The article description. In a publisher case, usually this is the remote article description
  , articleUpdateIs'Underscoremetadata'Underscorerecord :: Bool -- ^ True if article has no files
  , articleUpdateMetadata'Underscorereason :: Text -- ^ Article metadata reason
  , articleUpdateTags :: [Text] -- ^ List of tags to be associated with the article. Keywords can be used instead
  , articleUpdateKeywords :: [Text] -- ^ List of tags to be associated with the article. Tags can be used instead
  , articleUpdateReferences :: [Text] -- ^ List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
  , articleUpdateRelated'Underscorematerials :: [Value] -- ^ List of related materials; supersedes references.
  , articleUpdateCategories :: [Integer] -- ^ List of category ids to be associated with the article(e.g [1, 23, 33, 66])
  , articleUpdateCategories'Underscoreby'Underscoresource'Underscoreid :: [Text] -- ^ List of category source ids to be associated with the article, supersedes the categories property
  , articleUpdateAuthors :: [Value] -- ^ List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint.
  , articleUpdateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the article
  , articleUpdateCustom'Underscorefields'Underscorelist :: [CustomArticleFieldAdd] -- ^ List of custom fields values, supersedes custom_fields parameter
  , articleUpdateDefined'Underscoretype :: Text -- ^ <b>One of:</b> <code>figure</code> <code>online resource</code> <code>preprint</code> <code>book</code> <code>conference contribution</code> <code>media</code> <code>dataset</code> <code>poster</code> <code>journal contribution</code> <code>presentation</code> <code>thesis</code> <code>software</code>
  , articleUpdateFunding :: Text -- ^ Grant number or funding authority
  , articleUpdateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , articleUpdateLicense :: Integer -- ^ License id for this article.
  , articleUpdateDoi :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleUpdateHandle :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , articleUpdateResource'Underscoredoi :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article DOI.
  , articleUpdateResource'Underscoretitle :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article title.
  , articleUpdateTimeline :: TimelineUpdate -- ^ Various timeline dates
  , articleUpdateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleUpdate")
instance ToJSON ArticleUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleUpdate")

-- | 
data ArticleVersions = ArticleVersions
  { articleVersionsVersion :: Integer -- ^ Version number
  , articleVersionsUrl :: Text -- ^ Api endpoint for the item version
  } deriving (Show, Eq, Generic)

instance FromJSON ArticleVersions where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articleVersions")
instance ToJSON ArticleVersions where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articleVersions")

-- | 
newtype ArticleWithProject = ArticleWithProject { unArticleWithProject :: Article }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data ArticlesCreator = ArticlesCreator
  { articlesCreatorArticles :: [Integer] -- ^ List of article ids
  } deriving (Show, Eq, Generic)

instance FromJSON ArticlesCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "articlesCreator")
instance ToJSON ArticlesCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "articlesCreator")

-- | 
data Author = Author
  { authorId :: Integer -- ^ Author id
  , authorFull'Underscorename :: Text -- ^ Author full name
  , authorIs'Underscoreactive :: Bool -- ^ True if author has published items
  , authorUrl'Underscorename :: Text -- ^ Author url name
  , authorOrcid'Underscoreid :: Text -- ^ Author Orcid
  } deriving (Show, Eq, Generic)

instance FromJSON Author where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "author")
instance ToJSON Author where
  toJSON = genericToJSON (removeFieldLabelPrefix False "author")

-- | 
newtype AuthorComplete = AuthorComplete { unAuthorComplete :: Author }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data AuthorsCreator = AuthorsCreator
  { authorsCreatorAuthors :: [Value] -- ^ List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint.
  } deriving (Show, Eq, Generic)

instance FromJSON AuthorsCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "authorsCreator")
instance ToJSON AuthorsCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "authorsCreator")

-- | 
data CategoriesCreator = CategoriesCreator
  { categoriesCreatorCategories :: [Integer] -- ^ List of category ids
  } deriving (Show, Eq, Generic)

instance FromJSON CategoriesCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "categoriesCreator")
instance ToJSON CategoriesCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "categoriesCreator")

-- | 
data Category = Category
  { categoryParent'Underscoreid :: Integer -- ^ Parent category
  , categoryId :: Integer -- ^ Category id
  , categoryTitle :: Text -- ^ Category title
  , categoryPath :: Text -- ^ Path to all ancestor ids
  , categorySource'Underscoreid :: Text -- ^ ID in original standard taxonomy
  , categoryTaxonomy'Underscoreid :: Integer -- ^ Internal id of taxonomy the category is part of
  } deriving (Show, Eq, Generic)

instance FromJSON Category where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "category")
instance ToJSON Category where
  toJSON = genericToJSON (removeFieldLabelPrefix False "category")

-- | 
data Collaborator = Collaborator
  { collaboratorRole'Underscorename :: Text -- ^ Collaborator role
  , collaboratorUser'Underscoreid :: Int -- ^ Collaborator id
  , collaboratorName :: Text -- ^ Collaborator name
  } deriving (Show, Eq, Generic)

instance FromJSON Collaborator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collaborator")
instance ToJSON Collaborator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collaborator")

-- | 
data Collection = Collection
  { collectionId :: Integer -- ^ Collection id
  , collectionTitle :: Text -- ^ Collection title
  , collectionDoi :: Text -- ^ Collection DOI
  , collectionHandle :: Text -- ^ Collection Handle
  , collectionUrl :: Text -- ^ Api endpoint
  , collectionTimeline :: Timeline -- ^ Various timeline dates
  } deriving (Show, Eq, Generic)

instance FromJSON Collection where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collection")
instance ToJSON Collection where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collection")

-- | 
newtype CollectionComplete = CollectionComplete { unCollectionComplete :: Collection }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
newtype CollectionCompletePrivate = CollectionCompletePrivate { unCollectionCompletePrivate :: Collection }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data CollectionCreate = CollectionCreate
  { collectionCreateFunding :: Text -- ^ Grant number or funding authority
  , collectionCreateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , collectionCreateTitle :: Text -- ^ Title of collection
  , collectionCreateDescription :: Text -- ^ The collection description. In a publisher case, usually this is the remote collection description
  , collectionCreateArticles :: [Int] -- ^ List of articles to be associated with the collection
  , collectionCreateAuthors :: [Value] -- ^ List of authors to be associated with the collection. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint.
  , collectionCreateCategories :: [Integer] -- ^ List of category ids to be associated with the collection(e.g [1, 23, 33, 66])
  , collectionCreateCategories'Underscoreby'Underscoresource'Underscoreid :: [Text] -- ^ List of category source ids to be associated with the collection, supersedes the categories property
  , collectionCreateTags :: [Text] -- ^ List of tags to be associated with the collection. Keywords can be used instead
  , collectionCreateKeywords :: [Text] -- ^ List of tags to be associated with the collection. Tags can be used instead
  , collectionCreateReferences :: [Text] -- ^ List of links to be associated with the collection (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
  , collectionCreateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the collection
  , collectionCreateCustom'Underscorefields'Underscorelist :: [CustomArticleFieldAdd] -- ^ List of custom fields values, supersedes custom_fields parameter
  , collectionCreateDoi :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , collectionCreateHandle :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , collectionCreateResource'Underscoreid :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article id
  , collectionCreateResource'Underscoredoi :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article DOI.
  , collectionCreateResource'Underscorelink :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article link
  , collectionCreateResource'Underscoretitle :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article title.
  , collectionCreateResource'Underscoreversion :: Int -- ^ Not applicable to regular users. In a publisher case, this is the publisher article version
  , collectionCreateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  , collectionCreateTimeline :: TimelineUpdate -- ^ Various timeline dates
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionCreate")
instance ToJSON CollectionCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionCreate")

-- | 
data CollectionDOI = CollectionDOI
  { collectionDOIDoi :: Text -- ^ Reserved DOI
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionDOI where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionDOI")
instance ToJSON CollectionDOI where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionDOI")

-- | 
data CollectionHandle = CollectionHandle
  { collectionHandleHandle :: Text -- ^ Reserved Handle
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionHandle where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionHandle")
instance ToJSON CollectionHandle where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionHandle")

-- | 
data CollectionPrivateLinkCreator = CollectionPrivateLinkCreator
  { collectionPrivateLinkCreatorExpires'Underscoredate :: Text -- ^ Date when this private link should expire - optional. By default private links expire in 365 days.
  , collectionPrivateLinkCreatorRead'Underscoreonly :: Bool -- ^ Optional, default true. Set to false to give private link users editing rights for this collection.
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionPrivateLinkCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionPrivateLinkCreator")
instance ToJSON CollectionPrivateLinkCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionPrivateLinkCreator")

-- | 
newtype CollectionSearch = CollectionSearch { unCollectionSearch :: CommonSearch }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data CollectionUpdate = CollectionUpdate
  { collectionUpdateFunding :: Text -- ^ Grant number or funding authority
  , collectionUpdateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , collectionUpdateTitle :: Text -- ^ Title of collection
  , collectionUpdateDescription :: Text -- ^ The collection description. In a publisher case, usually this is the remote collection description
  , collectionUpdateArticles :: [Int] -- ^ List of articles to be associated with the collection
  , collectionUpdateAuthors :: [Value] -- ^ List of authors to be associated with the collection. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint.
  , collectionUpdateCategories :: [Integer] -- ^ List of category ids to be associated with the collection (e.g [1, 23, 33, 66])
  , collectionUpdateCategories'Underscoreby'Underscoresource'Underscoreid :: [Text] -- ^ List of category source ids to be associated with the article, supersedes the categories property
  , collectionUpdateTags :: [Text] -- ^ List of tags to be associated with the collection. Keywords can be used instead
  , collectionUpdateKeywords :: [Text] -- ^ List of tags to be associated with the collection. Tags can be used instead
  , collectionUpdateReferences :: [Text] -- ^ List of links to be associated with the collection (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
  , collectionUpdateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the collection
  , collectionUpdateCustom'Underscorefields'Underscorelist :: [CustomArticleFieldAdd] -- ^ List of custom fields values, supersedes custom_fields parameter
  , collectionUpdateDoi :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , collectionUpdateHandle :: Text -- ^ Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
  , collectionUpdateResource'Underscoreid :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article id
  , collectionUpdateResource'Underscoredoi :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article DOI.
  , collectionUpdateResource'Underscorelink :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article link
  , collectionUpdateResource'Underscoretitle :: Text -- ^ Not applicable to regular users. In a publisher case, this is the publisher article title.
  , collectionUpdateResource'Underscoreversion :: Int -- ^ Not applicable to regular users. In a publisher case, this is the publisher article version
  , collectionUpdateGroup'Underscoreid :: Integer -- ^ Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
  , collectionUpdateTimeline :: TimelineUpdate -- ^ Various timeline dates
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionUpdate")
instance ToJSON CollectionUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionUpdate")

-- | 
data CollectionVersions = CollectionVersions
  { collectionVersionsId :: Integer -- ^ Version number
  , collectionVersionsUrl :: Text -- ^ Api endpoint for the collection version
  } deriving (Show, Eq, Generic)

instance FromJSON CollectionVersions where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "collectionVersions")
instance ToJSON CollectionVersions where
  toJSON = genericToJSON (removeFieldLabelPrefix False "collectionVersions")

-- | 
data CommonSearch = CommonSearch
  { commonSearchSearch'Underscorefor :: Text -- ^ Search term
  , commonSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , commonSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , commonSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , commonSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , commonSearchOrder'Underscoredirection :: Text -- ^ Direction of ordering
  , commonSearchInstitution :: Int -- ^ only return collections from this institution
  , commonSearchPublished'Underscoresince :: Text -- ^ Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , commonSearchModified'Underscoresince :: Text -- ^ Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  , commonSearchGroup :: Int -- ^ only return collections from this group
  } deriving (Show, Eq, Generic)

instance FromJSON CommonSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "commonSearch")
instance ToJSON CommonSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "commonSearch")

-- | 
data ConfidentialityCreator = ConfidentialityCreator
  { confidentialityCreatorReason :: Text -- ^ Reason for confidentiality
  } deriving (Show, Eq, Generic)

instance FromJSON ConfidentialityCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "confidentialityCreator")
instance ToJSON ConfidentialityCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "confidentialityCreator")

-- | 
data CreateProjectResponse = CreateProjectResponse
  { createProjectResponseEntity'Underscoreid :: Integer -- ^ Figshare ID of the entity
  , createProjectResponseLocation :: Text -- ^ Url for entity
  } deriving (Show, Eq, Generic)

instance FromJSON CreateProjectResponse where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "createProjectResponse")
instance ToJSON CreateProjectResponse where
  toJSON = genericToJSON (removeFieldLabelPrefix False "createProjectResponse")

-- | 
data Curation = Curation
  { curationId :: Integer -- ^ The review id
  , curationGroup'Underscoreid :: Integer -- ^ The group in which the article is present.
  , curationAccount'Underscoreid :: Integer -- ^ The ID of the account of the owner of the article of this review.
  , curationAssigned'Underscoreto :: Integer -- ^ The ID of the account to which this review is assigned.
  , curationArticle'Underscoreid :: Integer -- ^ The ID of the article of this review.
  , curationVersion :: Integer -- ^ The Version number of the article in review.
  , curationComments'Underscorecount :: Integer -- ^ The number of comments in the review.
  , curationStatus :: Text -- ^ The status of the review.
  , curationCreated'Underscoredate :: Text -- ^ The creation date of the review.
  , curationModified'Underscoredate :: Text -- ^ The date the review has been modified.
  } deriving (Show, Eq, Generic)

instance FromJSON Curation where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "curation")
instance ToJSON Curation where
  toJSON = genericToJSON (removeFieldLabelPrefix False "curation")

-- | 
data CurationComment = CurationComment
  { curationCommentId :: Integer -- ^ The ID of the comment.
  , curationCommentAccount'Underscoreid :: Integer -- ^ The ID of the account which generated this comment.
  , curationCommentType :: Text -- ^ The ID of the account which generated this comment.
  , curationCommentText :: Text -- ^ The value/content of the comment.
  } deriving (Show, Eq, Generic)

instance FromJSON CurationComment where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "curationComment")
instance ToJSON CurationComment where
  toJSON = genericToJSON (removeFieldLabelPrefix False "curationComment")

-- | 
data CurationCommentCreate = CurationCommentCreate
  { curationCommentCreateText :: Text -- ^ The contents/value of the comment
  } deriving (Show, Eq, Generic)

instance FromJSON CurationCommentCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "curationCommentCreate")
instance ToJSON CurationCommentCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "curationCommentCreate")

-- | 
newtype CurationDetail = CurationDetail { unCurationDetail :: Curation }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data CustomArticleField = CustomArticleField
  { customArticleFieldName :: Text -- ^ Custom  metadata name
  , customArticleFieldValue :: Text -- ^ Custom metadata value
  } deriving (Show, Eq, Generic)

instance FromJSON CustomArticleField where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "customArticleField")
instance ToJSON CustomArticleField where
  toJSON = genericToJSON (removeFieldLabelPrefix False "customArticleField")

-- | 
data CustomArticleFieldAdd = CustomArticleFieldAdd
  { customArticleFieldAddName :: Text -- ^ Custom  metadata name
  , customArticleFieldAddValue :: Value -- ^ Custom metadata value
  } deriving (Show, Eq, Generic)

instance FromJSON CustomArticleFieldAdd where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "customArticleFieldAdd")
instance ToJSON CustomArticleFieldAdd where
  toJSON = genericToJSON (removeFieldLabelPrefix False "customArticleFieldAdd")

-- | 
data ErrorMessage = ErrorMessage
  { errorMessageCode :: Integer -- ^ A machine friendly error code, used by the dev team to identify the error.
  , errorMessageMessage :: Text -- ^ A human friendly message explaining the error.
  } deriving (Show, Eq, Generic)

instance FromJSON ErrorMessage where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "errorMessage")
instance ToJSON ErrorMessage where
  toJSON = genericToJSON (removeFieldLabelPrefix False "errorMessage")

-- | 
data FileCreator = FileCreator
  { fileCreatorLink :: Text -- ^ Url for an existing file that will not be uploaded to Figshare
  , fileCreatorMd5 :: Text -- ^ MD5 sum pre-computed on client side.
  , fileCreatorName :: Text -- ^ File name including the extension; can be omitted only for linked files.
  , fileCreatorSize :: Integer -- ^ File size in bytes; can be omitted only for linked files.
  } deriving (Show, Eq, Generic)

instance FromJSON FileCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "fileCreator")
instance ToJSON FileCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "fileCreator")

-- | 
data FileId = FileId
  { fileIdFile'Underscoreid :: Integer -- ^ File ID
  } deriving (Show, Eq, Generic)

instance FromJSON FileId where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "fileId")
instance ToJSON FileId where
  toJSON = genericToJSON (removeFieldLabelPrefix False "fileId")

-- | 
data FundingCreate = FundingCreate
  { fundingCreateId :: Integer -- ^ A funding ID as returned by the Funding Search endpoint
  , fundingCreateTitle :: Text -- ^ The title of the new user created funding
  } deriving (Show, Eq, Generic)

instance FromJSON FundingCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "fundingCreate")
instance ToJSON FundingCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "fundingCreate")

-- | 
data FundingInformation = FundingInformation
  { fundingInformationId :: Integer -- ^ Funding id
  , fundingInformationTitle :: Text -- ^ The funding name
  , fundingInformationGrant'Underscorecode :: Text -- ^ The grant code
  , fundingInformationFunder'Underscorename :: Text -- ^ Funder's name
  , fundingInformationIs'Underscoreuser'Underscoredefined :: Bool -- ^ Return whether the grant has been introduced manually
  , fundingInformationUrl :: Text -- ^ The grant url
  } deriving (Show, Eq, Generic)

instance FromJSON FundingInformation where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "fundingInformation")
instance ToJSON FundingInformation where
  toJSON = genericToJSON (removeFieldLabelPrefix False "fundingInformation")

-- | 
data FundingSearch = FundingSearch
  { fundingSearchSearch'Underscorefor :: Text -- ^ Search term
  } deriving (Show, Eq, Generic)

instance FromJSON FundingSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "fundingSearch")
instance ToJSON FundingSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "fundingSearch")

-- | 
data Group = Group
  { groupId :: Integer -- ^ Group id
  , groupName :: Text -- ^ Group name
  , groupResource'Underscoreid :: Text -- ^ Group resource id
  , groupParent'Underscoreid :: Integer -- ^ Parent group if any
  , groupAssociation'Underscorecriteria :: Text -- ^ HR code associated with group, if code exists
  } deriving (Show, Eq, Generic)

instance FromJSON Group where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "group")
instance ToJSON Group where
  toJSON = genericToJSON (removeFieldLabelPrefix False "group")

-- | 
data GroupEmbargoOptions = GroupEmbargoOptions
  { groupEmbargoOptionsId :: Integer -- ^ Embargo option id
  , groupEmbargoOptionsType :: Text -- ^ Embargo permission type
  , groupEmbargoOptionsIp'Underscorename :: Text -- ^ IP range name; value appears if type is ip_range
  } deriving (Show, Eq, Generic)

instance FromJSON GroupEmbargoOptions where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "groupEmbargoOptions")
instance ToJSON GroupEmbargoOptions where
  toJSON = genericToJSON (removeFieldLabelPrefix False "groupEmbargoOptions")

-- | 
data Institution = Institution
  { institutionId :: Integer -- ^ Institution id
  , institutionName :: Text -- ^ Institution name
  } deriving (Show, Eq, Generic)

instance FromJSON Institution where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "institution")
instance ToJSON Institution where
  toJSON = genericToJSON (removeFieldLabelPrefix False "institution")

-- | 
data InstitutionAccountsSearch = InstitutionAccountsSearch
  { institutionAccountsSearchSearch'Underscorefor :: Text -- ^ Search term
  , institutionAccountsSearchIs'Underscoreactive :: Integer -- ^ Filter by active status
  , institutionAccountsSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , institutionAccountsSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , institutionAccountsSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , institutionAccountsSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , institutionAccountsSearchInstitution'Underscoreuser'Underscoreid :: Text -- ^ filter by institution_user_id
  , institutionAccountsSearchEmail :: Text -- ^ filter by email
  } deriving (Show, Eq, Generic)

instance FromJSON InstitutionAccountsSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "institutionAccountsSearch")
instance ToJSON InstitutionAccountsSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "institutionAccountsSearch")

-- | 
data ItemType = ItemType
  { itemTypeId :: Integer -- ^ The ID of the item type.
  , itemTypeName :: Text -- ^ The name of the item type
  , itemTypeString'Underscoreid :: Text -- ^ The string identifier of the item type.
  , itemTypeIcon :: Text -- ^ The string identifying the icon of the item type.
  , itemTypePublic'Underscoredescription :: Text -- ^ The description of the item type.
  , itemTypeIs'Underscoreselectable :: Bool -- ^ The selectable status
  , itemTypeUrl'Underscorename :: Text -- ^ The URL name of the item type.
  } deriving (Show, Eq, Generic)

instance FromJSON ItemType where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "itemType")
instance ToJSON ItemType where
  toJSON = genericToJSON (removeFieldLabelPrefix False "itemType")

-- | 
data License = License
  { licenseValue :: Integer -- ^ License value
  , licenseName :: Text -- ^ License name
  , licenseUrl :: Text -- ^ License url
  } deriving (Show, Eq, Generic)

instance FromJSON License where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "license")
instance ToJSON License where
  toJSON = genericToJSON (removeFieldLabelPrefix False "license")

-- | 
data Location = Location
  { locationLocation :: Text -- ^ Url for item
  } deriving (Show, Eq, Generic)

instance FromJSON Location where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "location")
instance ToJSON Location where
  toJSON = genericToJSON (removeFieldLabelPrefix False "location")

-- | 
data LocationWarnings = LocationWarnings
  { locationWarningsEntity'Underscoreid :: Integer -- ^ Figshare ID of the entity
  , locationWarningsLocation :: Text -- ^ Url for entity
  , locationWarningsWarnings :: [Text] -- ^ Issues encountered during the operation
  } deriving (Show, Eq, Generic)

instance FromJSON LocationWarnings where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "locationWarnings")
instance ToJSON LocationWarnings where
  toJSON = genericToJSON (removeFieldLabelPrefix False "locationWarnings")

-- | 
data LocationWarningsUpdate = LocationWarningsUpdate
  { locationWarningsUpdateLocation :: Text -- ^ Url for entity
  , locationWarningsUpdateWarnings :: [Text] -- ^ Issues encountered during the operation
  } deriving (Show, Eq, Generic)

instance FromJSON LocationWarningsUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "locationWarningsUpdate")
instance ToJSON LocationWarningsUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "locationWarningsUpdate")

-- | 
newtype PrivateArticleSearch = PrivateArticleSearch { unPrivateArticleSearch :: ArticleSearch }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data PrivateAuthorsSearch = PrivateAuthorsSearch
  { privateAuthorsSearchSearch'Underscorefor :: Text -- ^ Search term
  , privateAuthorsSearchPage :: Integer -- ^ Page number. Used for pagination with page_size
  , privateAuthorsSearchPage'Underscoresize :: Integer -- ^ The number of results included on a page. Used for pagination with page
  , privateAuthorsSearchLimit :: Integer -- ^ Number of results included on a page. Used for pagination with query
  , privateAuthorsSearchOffset :: Integer -- ^ Where to start the listing(the offset of the first result). Used for pagination with limit
  , privateAuthorsSearchOrder :: Text -- ^ The field by which to order. Default varies by endpoint/resource.
  , privateAuthorsSearchOrder'Underscoredirection :: Text -- ^ Direction of ordering
  , privateAuthorsSearchInstitution'Underscoreid :: Integer -- ^ Return only authors associated to this institution
  , privateAuthorsSearchOrcid :: Text -- ^ Orcid of author
  , privateAuthorsSearchGroup'Underscoreid :: Integer -- ^ Return only authors in this group or subgroups of the group
  , privateAuthorsSearchIs'Underscoreactive :: Bool -- ^ Return only active authors if True
  , privateAuthorsSearchIs'Underscorepublic :: Bool -- ^ Return only authors that have published items if True
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateAuthorsSearch where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "privateAuthorsSearch")
instance ToJSON PrivateAuthorsSearch where
  toJSON = genericToJSON (removeFieldLabelPrefix False "privateAuthorsSearch")

-- | 
newtype PrivateCollectionSearch = PrivateCollectionSearch { unPrivateCollectionSearch :: CollectionSearch }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
newtype PrivateFile = PrivateFile { unPrivateFile :: PublicFile }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data PrivateLink = PrivateLink
  { privateLinkId :: Text -- ^ Private link id
  , privateLinkIs'Underscoreactive :: Bool -- ^ True if private link is active
  , privateLinkExpires'Underscoredate :: Text -- ^ Date when link will expire
  , privateLinkHtml'Underscorelocation :: Text -- ^ HTML url for private link
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateLink where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "privateLink")
instance ToJSON PrivateLink where
  toJSON = genericToJSON (removeFieldLabelPrefix False "privateLink")

-- | 
data PrivateLinkCreator = PrivateLinkCreator
  { privateLinkCreatorExpires'Underscoredate :: Text -- ^ Date when this private link should expire - optional. By default private links expire in 365 days.
  , privateLinkCreatorRead'Underscoreonly :: Bool -- ^ Optional, default true. Set to false to give private link users editing rights for this collection.
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateLinkCreator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "privateLinkCreator")
instance ToJSON PrivateLinkCreator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "privateLinkCreator")

-- | 
data PrivateLinkResponse = PrivateLinkResponse
  { privateLinkResponseLocation :: Text -- ^ Url for private link
  , privateLinkResponseHtml'Underscorelocation :: Text -- ^ HTML url for private link
  , privateLinkResponseToken :: Text -- ^ Token for private link
  } deriving (Show, Eq, Generic)

instance FromJSON PrivateLinkResponse where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "privateLinkResponse")
instance ToJSON PrivateLinkResponse where
  toJSON = genericToJSON (removeFieldLabelPrefix False "privateLinkResponse")

-- | 
data Project = Project
  { projectUrl :: Text -- ^ Api endpoint
  , projectId :: Integer -- ^ Project id
  , projectTitle :: Text -- ^ Project title
  } deriving (Show, Eq, Generic)

instance FromJSON Project where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "project")
instance ToJSON Project where
  toJSON = genericToJSON (removeFieldLabelPrefix False "project")

-- | 
newtype ProjectArticle = ProjectArticle { unProjectArticle :: Article }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data ProjectCollaborator = ProjectCollaborator
  { projectCollaboratorStatus :: Text -- ^ Status of collaborator invitation
  , projectCollaboratorRole'Underscorename :: Text -- ^ Collaborator role
  , projectCollaboratorUser'Underscoreid :: Int -- ^ Collaborator id
  , projectCollaboratorName :: Text -- ^ Collaborator name
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectCollaborator where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectCollaborator")
instance ToJSON ProjectCollaborator where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectCollaborator")

-- | 
data ProjectCollaboratorInvite = ProjectCollaboratorInvite
  { projectCollaboratorInviteRole'Underscorename :: Text -- ^ Role of the the collaborator inside the project
  , projectCollaboratorInviteUser'Underscoreid :: Integer -- ^ User id of the collaborator
  , projectCollaboratorInviteEmail :: Text -- ^ Collaborator email
  , projectCollaboratorInviteComment :: Text -- ^ Text sent when inviting the user to the project
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectCollaboratorInvite where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectCollaboratorInvite")
instance ToJSON ProjectCollaboratorInvite where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectCollaboratorInvite")

-- | 
newtype ProjectComplete = ProjectComplete { unProjectComplete :: Project }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
newtype ProjectCompletePrivate = ProjectCompletePrivate { unProjectCompletePrivate :: ProjectPrivate }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data ProjectCreate = ProjectCreate
  { projectCreateTitle :: Text -- ^ The title for this project - mandatory. 3 - 1000 characters.
  , projectCreateDescription :: Text -- ^ Project description
  , projectCreateFunding :: Text -- ^ Grant number or organization(s) that funded this project. Up to 2000 characters permitted.
  , projectCreateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , projectCreateGroup'Underscoreid :: Integer -- ^ Only if project type is group.
  , projectCreateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the project
  , projectCreateCustom'Underscorefields'Underscorelist :: [CustomArticleFieldAdd] -- ^ List of custom fields values, supersedes custom_fields parameter
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectCreate")
instance ToJSON ProjectCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectCreate")

-- | 
data ProjectNote = ProjectNote
  { projectNoteId :: Integer -- ^ Project note id
  , projectNoteUser'Underscoreid :: Integer -- ^ User who wrote the note
  , projectNoteAbstract :: Text -- ^ Note Abstract - short/truncated content
  , projectNoteUser'Underscorename :: Text -- ^ Username of the one who wrote the note
  , projectNoteCreated'Underscoredate :: Text -- ^ Date when note was created
  , projectNoteModified'Underscoredate :: Text -- ^ Date when note was last modified
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectNote where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectNote")
instance ToJSON ProjectNote where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectNote")

-- | 
data ProjectNoteCreate = ProjectNoteCreate
  { projectNoteCreateText :: Text -- ^ Text of the note
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectNoteCreate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectNoteCreate")
instance ToJSON ProjectNoteCreate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectNoteCreate")

-- | 
newtype ProjectNotePrivate = ProjectNotePrivate { unProjectNotePrivate :: ProjectNote }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
newtype ProjectPrivate = ProjectPrivate { unProjectPrivate :: Project }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data ProjectUpdate = ProjectUpdate
  { projectUpdateTitle :: Text -- ^ The title for this project - mandatory. 3 - 1000 characters.
  , projectUpdateDescription :: Text -- ^ Project description
  , projectUpdateFunding :: Text -- ^ Grant number or organization(s) that funded this project. Up to 2000 characters permitted.
  , projectUpdateFunding'Underscorelist :: [FundingCreate] -- ^ Funding creation / update items
  , projectUpdateCustom'Underscorefields :: Value -- ^ List of key, values pairs to be associated with the project
  , projectUpdateCustom'Underscorefields'Underscorelist :: [CustomArticleFieldAdd] -- ^ List of custom fields values, supersedes custom_fields parameter
  } deriving (Show, Eq, Generic)

instance FromJSON ProjectUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "projectUpdate")
instance ToJSON ProjectUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "projectUpdate")

-- | 
newtype ProjectsSearch = ProjectsSearch { unProjectsSearch :: CommonSearch }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data PublicFile = PublicFile
  { publicFileId :: Integer -- ^ File id
  , publicFileName :: Text -- ^ File name
  , publicFileSize :: Integer -- ^ File size
  , publicFileIs'Underscorelink'Underscoreonly :: Bool -- ^ True if file is hosted somewhere else
  , publicFileDownload'Underscoreurl :: Text -- ^ Url for file download
  , publicFileSupplied'Underscoremd5 :: Text -- ^ File supplied md5
  , publicFileComputed'Underscoremd5 :: Text -- ^ File computed md5
  } deriving (Show, Eq, Generic)

instance FromJSON PublicFile where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "publicFile")
instance ToJSON PublicFile where
  toJSON = genericToJSON (removeFieldLabelPrefix False "publicFile")

-- | 
data RelatedMaterial = RelatedMaterial
  { relatedMaterialId :: Integer -- ^ The ID of the related material; can be used to add existing materials of the same account to items.
  , relatedMaterialIdentifier :: Text -- ^ The related material identifier (e.g., DOI, Handle, ISBN)
  , relatedMaterialTitle :: Text -- ^ The related material title
  , relatedMaterialRelation :: Text -- ^ The relation between the item and the related material; defaults to 'References'
  , relatedMaterialIdentifier'Underscoretype :: Text -- ^ The type of the identifier of the related material; defaults to 'URL'
  , relatedMaterialIs'Underscorelinkout :: Bool -- ^ Flag for highlighting this related material in the call-out box
  , relatedMaterialLink :: Text -- ^ The full hyperlink for the identifier
  } deriving (Show, Eq, Generic)

instance FromJSON RelatedMaterial where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "relatedMaterial")
instance ToJSON RelatedMaterial where
  toJSON = genericToJSON (removeFieldLabelPrefix False "relatedMaterial")

-- | 
data Resource = Resource
  { resourceId :: Text -- ^ ID of resource item
  , resourceTitle :: Text -- ^ Title of resource item
  , resourceDoi :: Text -- ^ DOI of resource item
  , resourceLink :: Text -- ^ Link of resource item
  , resourceStatus :: Text -- ^ Status of resource item
  , resourceVersion :: Integer -- ^ Version of resource item
  } deriving (Show, Eq, Generic)

instance FromJSON Resource where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "resource")
instance ToJSON Resource where
  toJSON = genericToJSON (removeFieldLabelPrefix False "resource")

-- | 
data ResponseMessage = ResponseMessage
  { responseMessageMessage :: Text -- ^ Response message text
  } deriving (Show, Eq, Generic)

instance FromJSON ResponseMessage where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "responseMessage")
instance ToJSON ResponseMessage where
  toJSON = genericToJSON (removeFieldLabelPrefix False "responseMessage")

-- | 
data Role = Role
  { roleId :: Integer -- ^ Role id
  , roleName :: Text -- ^ Role name
  , roleCategory :: Text -- ^ Role category
  , roleDescription :: Text -- ^ Role description
  } deriving (Show, Eq, Generic)

instance FromJSON Role where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "role")
instance ToJSON Role where
  toJSON = genericToJSON (removeFieldLabelPrefix False "role")

-- | 
data ShortAccount = ShortAccount
  { shortAccountId :: Integer -- ^ Account id
  , shortAccountFirst'Underscorename :: Text -- ^ First Name
  , shortAccountLast'Underscorename :: Text -- ^ Last Name
  , shortAccountInstitution'Underscoreid :: Integer -- ^ Account institution
  , shortAccountEmail :: Text -- ^ User email
  , shortAccountActive :: Integer -- ^ Account activity status
  , shortAccountInstitution'Underscoreuser'Underscoreid :: Text -- ^ Account institution user id
  , shortAccountQuota :: Integer -- ^ Total storage available to account, in bytes
  , shortAccountUsed'Underscorequota :: Integer -- ^ Storage used by the account, in bytes
  , shortAccountUser'Underscoreid :: Integer -- ^ User id associated with account, useful for example for adding the account as an author to an item
  , shortAccountOrcid'Underscoreid :: Text -- ^ ORCID iD associated to account
  } deriving (Show, Eq, Generic)

instance FromJSON ShortAccount where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "shortAccount")
instance ToJSON ShortAccount where
  toJSON = genericToJSON (removeFieldLabelPrefix False "shortAccount")

-- | 
data ShortCustomField = ShortCustomField
  { shortCustomFieldId :: Integer -- ^ Custom field id
  , shortCustomFieldName :: Text -- ^ Custom field name
  , shortCustomFieldField'Underscoretype :: Text -- ^ Custom field type
  } deriving (Show, Eq, Generic)

instance FromJSON ShortCustomField where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "shortCustomField")
instance ToJSON ShortCustomField where
  toJSON = genericToJSON (removeFieldLabelPrefix False "shortCustomField")

-- | 
newtype Timeline = Timeline { unTimeline :: TimelineUpdate }
  deriving (Show, Eq, FromJSON, ToJSON, Generic)

-- | 
data TimelineUpdate = TimelineUpdate
  { timelineUpdateFirstOnline :: Text -- ^ Online posted date
  , timelineUpdatePublisherPublication :: Text -- ^ Publish date
  , timelineUpdatePublisherAcceptance :: Text -- ^ Date when the item was accepted for publication
  } deriving (Show, Eq, Generic)

instance FromJSON TimelineUpdate where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "timelineUpdate")
instance ToJSON TimelineUpdate where
  toJSON = genericToJSON (removeFieldLabelPrefix False "timelineUpdate")

-- | 
data UploadFilePart = UploadFilePart
  { uploadFilePartPartNo :: Integer -- ^ File part id
  , uploadFilePartStartOffset :: Integer -- ^ Indexes on byte range. zero-based and inclusive
  , uploadFilePartEndOffset :: Integer -- ^ Indexes on byte range. zero-based and inclusive
  , uploadFilePartStatus :: Text -- ^ part status
  , uploadFilePartLocked :: Bool -- ^ When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests.
  } deriving (Show, Eq, Generic)

instance FromJSON UploadFilePart where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "uploadFilePart")
instance ToJSON UploadFilePart where
  toJSON = genericToJSON (removeFieldLabelPrefix False "uploadFilePart")

-- | 
data UploadInfo = UploadInfo
  { uploadInfoToken :: Text -- ^ token received after initializing a file upload
  , uploadInfoMd5 :: Text -- ^ md5 provided on upload initialization
  , uploadInfoSize :: Integer -- ^ size of file in bytes
  , uploadInfoName :: Text -- ^ name of file on upload server
  , uploadInfoStatus :: Text -- ^ Upload status
  , uploadInfoParts :: [UploadFilePart] -- ^ Uploads parts
  } deriving (Show, Eq, Generic)

instance FromJSON UploadInfo where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "uploadInfo")
instance ToJSON UploadInfo where
  toJSON = genericToJSON (removeFieldLabelPrefix False "uploadInfo")

-- | 
data User = User
  { userId :: Integer -- ^ User id
  , userFirst'Underscorename :: Text -- ^ First Name
  , userLast'Underscorename :: Text -- ^ Last Name
  , userName :: Text -- ^ Full Name
  , userIs'Underscoreactive :: Bool -- ^ Account activity status
  , userUrl'Underscorename :: Text -- ^ Name that appears in website url
  , userIs'Underscorepublic :: Bool -- ^ Account public status
  , userJob'Underscoretitle :: Text -- ^ User Job title
  , userOrcid'Underscoreid :: Text -- ^ Orcid associated to this User
  } deriving (Show, Eq, Generic)

instance FromJSON User where
  parseJSON = genericParseJSON (removeFieldLabelPrefix True "user")
instance ToJSON User where
  toJSON = genericToJSON (removeFieldLabelPrefix False "user")

-- Remove a field label prefix during JSON parsing.
-- Also perform any replacements for special characters.
removeFieldLabelPrefix :: Bool -> String -> Options
removeFieldLabelPrefix forParsing prefix =
  defaultOptions
  {fieldLabelModifier = fromMaybe (error ("did not find prefix " ++ prefix)) . stripPrefix prefix . replaceSpecialChars}
  where
    replaceSpecialChars field = foldl (&) field (map mkCharReplacement specialChars)
    specialChars =
      [ ("@", "'At")
      , ("\\", "'Back_Slash")
      , ("<=", "'Less_Than_Or_Equal_To")
      , ("\"", "'Double_Quote")
      , ("[", "'Left_Square_Bracket")
      , ("]", "'Right_Square_Bracket")
      , ("^", "'Caret")
      , ("_", "'Underscore")
      , ("`", "'Backtick")
      , ("!", "'Exclamation")
      , ("#", "'Hash")
      , ("$", "'Dollar")
      , ("%", "'Percent")
      , ("&", "'Ampersand")
      , ("'", "'Quote")
      , ("(", "'Left_Parenthesis")
      , (")", "'Right_Parenthesis")
      , ("*", "'Star")
      , ("+", "'Plus")
      , (",", "'Comma")
      , ("-", "'Dash")
      , (".", "'Period")
      , ("/", "'Slash")
      , (":", "'Colon")
      , ("{", "'Left_Curly_Bracket")
      , ("|", "'Pipe")
      , ("<", "'LessThan")
      , ("!=", "'Not_Equal")
      , ("=", "'Equal")
      , ("}", "'Right_Curly_Bracket")
      , (">", "'GreaterThan")
      , ("~", "'Tilde")
      , ("?", "'Question_Mark")
      , (">=", "'Greater_Than_Or_Equal_To")
      ]
    mkCharReplacement (replaceStr, searchStr) = T.unpack . replacer (T.pack searchStr) (T.pack replaceStr) . T.pack
    replacer =
      if forParsing
        then flip T.replace
        else T.replace
