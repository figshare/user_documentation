{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveTraversable #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecordWildCards #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE ViewPatterns #-}
{-# OPTIONS_GHC
-fno-warn-unused-binds -fno-warn-unused-imports -fcontext-stack=328 #-}

module Figshare.API
  -- * Client and Server
  ( ServerConfig(..)
  , FigshareBackend
  , createFigshareClient
  , runFigshareServer
  , runFigshareClient
  , runFigshareClientWithManager
  , FigshareClient
  -- ** Servant
  , FigshareAPI
  ) where

import Figshare.Types

import Control.Monad.Except (ExceptT)
import Control.Monad.IO.Class
import Data.Aeson (Value)
import Data.Coerce (coerce)
import Data.Function ((&))
import qualified Data.Map as Map
import Data.Monoid ((<>))
import Data.Proxy (Proxy(..))
import Data.Text (Text)
import qualified Data.Text as T
import GHC.Exts (IsString(..))
import GHC.Generics (Generic)
import Network.HTTP.Client (Manager, defaultManagerSettings, newManager)
import Network.HTTP.Types.Method (methodOptions)
import qualified Network.Wai.Handler.Warp as Warp
import Servant (ServantErr, serve)
import Servant.API
import Servant.API.Verbs (StdMethod(..), Verb)
import Servant.Client (Scheme(Http), ServantError, client)
import Servant.Common.BaseUrl (BaseUrl(..))
import Web.HttpApiData



data FormInstitutionHrfeedUpload = FormInstitutionHrfeedUpload
  { institutionHrfeedUploadHrfeed :: FilePath
  } deriving (Show, Eq, Generic)

instance FromFormUrlEncoded FormInstitutionHrfeedUpload where
  fromFormUrlEncoded inputs = FormInstitutionHrfeedUpload <$> lookupEither "hrfeed" inputs

instance ToFormUrlEncoded FormInstitutionHrfeedUpload where
  toFormUrlEncoded value =
    [ ("hrfeed", toQueryParam $ institutionHrfeedUploadHrfeed value)
    ]

-- For the form data code generation.
lookupEither :: FromHttpApiData b => Text -> [(Text, Text)] -> Either String b
lookupEither key assocs =
  case lookup key assocs of
    Nothing -> Left $ "Could not find parameter " <> (T.unpack key) <> " in form data"
    Just value ->
      case parseQueryParam value of
        Left result -> Left $ T.unpack result
        Right result -> Right $ result

-- | Servant type-level API, generated from the Swagger spec for Figshare.
type FigshareAPI
    =    "account" :> "articles" :> "export" :> QueryParam "group_id" Integer :> Verb 'GET 200 '[JSON] [AccountReport] -- 'accountArticleReport' route
    :<|> "account" :> "articles" :> "export" :> Verb 'POST 200 '[JSON] AccountReport -- 'accountArticleReportGenerate' route
    :<|> "articles" :> Capture "article_id" Integer :> Verb 'GET 200 '[JSON] ArticleComplete -- 'articleDetails' route
    :<|> "articles" :> Capture "article_id" Integer :> "files" :> Capture "file_id" Integer :> Verb 'GET 200 '[JSON] PublicFile -- 'articleFileDetails' route
    :<|> "articles" :> Capture "article_id" Integer :> "files" :> Verb 'GET 200 '[JSON] [PublicFile] -- 'articleFiles' route
    :<|> "articles" :> Capture "article_id" Integer :> "versions" :> Capture "v_number" Integer :> "confidentiality" :> Verb 'GET 200 '[JSON] ArticleConfidentiality -- 'articleVersionConfidentiality' route
    :<|> "articles" :> Capture "article_id" Integer :> "versions" :> Capture "v_number" Integer :> Verb 'GET 200 '[JSON] ArticleComplete -- 'articleVersionDetails' route
    :<|> "articles" :> Capture "article_id" Integer :> "versions" :> Capture "v_number" Integer :> "embargo" :> Verb 'GET 200 '[JSON] ArticleEmbargo -- 'articleVersionEmbargo' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "versions" :> Capture "version_id" Integer :> "update_thumb" :> ReqBody '[JSON] FileId :> Verb 'PUT 200 '[JSON] () -- 'articleVersionUpdateThumb' route
    :<|> "articles" :> Capture "article_id" Integer :> "versions" :> Verb 'GET 200 '[JSON] [ArticleVersions] -- 'articleVersions' route
    :<|> "articles" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> QueryParam "order" Text :> QueryParam "order_direction" Text :> QueryParam "institution" Integer :> QueryParam "published_since" Text :> QueryParam "modified_since" Text :> QueryParam "group" Integer :> QueryParam "resource_doi" Text :> QueryParam "item_type" Integer :> QueryParam "doi" Text :> QueryParam "handle" Text :> Verb 'GET 200 '[JSON] [Article] -- 'articlesList' route
    :<|> "articles" :> "search" :> ReqBody '[JSON] ArticleSearch :> Verb 'POST 200 '[JSON] [Article] -- 'articlesSearch' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "authors" :> Capture "author_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateArticleAuthorDelete' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "authors" :> ReqBody '[JSON] AuthorsCreator :> Verb 'POST 200 '[JSON] () -- 'privateArticleAuthorsAdd' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "authors" :> Verb 'GET 200 '[JSON] [Author] -- 'privateArticleAuthorsList' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "authors" :> ReqBody '[JSON] AuthorsCreator :> Verb 'PUT 200 '[JSON] () -- 'privateArticleAuthorsReplace' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "categories" :> ReqBody '[JSON] CategoriesCreator :> Verb 'POST 200 '[JSON] () -- 'privateArticleCategoriesAdd' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "categories" :> Verb 'GET 200 '[JSON] [Category] -- 'privateArticleCategoriesList' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "categories" :> ReqBody '[JSON] CategoriesCreator :> Verb 'PUT 200 '[JSON] () -- 'privateArticleCategoriesReplace' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "categories" :> Capture "category_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateArticleCategoryDelete' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "confidentiality" :> Verb 'DELETE 200 '[JSON] () -- 'privateArticleConfidentialityDelete' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "confidentiality" :> Verb 'GET 200 '[JSON] ArticleConfidentiality -- 'privateArticleConfidentialityDetails' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "confidentiality" :> ReqBody '[JSON] ConfidentialityCreator :> Verb 'PUT 200 '[JSON] () -- 'privateArticleConfidentialityUpdate' route
    :<|> "account" :> "articles" :> ReqBody '[JSON] ArticleCreate :> Verb 'POST 200 '[JSON] Location -- 'privateArticleCreate' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateArticleDelete' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> Verb 'GET 200 '[JSON] ArticleCompletePrivate -- 'privateArticleDetails' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "embargo" :> Verb 'DELETE 200 '[JSON] () -- 'privateArticleEmbargoDelete' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "embargo" :> Verb 'GET 200 '[JSON] ArticleEmbargo -- 'privateArticleEmbargoDetails' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "embargo" :> ReqBody '[JSON] ArticleEmbargoUpdater :> Verb 'PUT 200 '[JSON] () -- 'privateArticleEmbargoUpdate' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "files" :> Capture "file_id" Integer :> Verb 'GET 200 '[JSON] PrivateFile -- 'privateArticleFile' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "files" :> Capture "file_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateArticleFileDelete' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "files" :> Verb 'GET 200 '[JSON] [PrivateFile] -- 'privateArticleFilesList' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "private_links" :> Verb 'GET 200 '[JSON] [PrivateLink] -- 'privateArticlePrivateLink' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "private_links" :> ReqBody '[JSON] PrivateLinkCreator :> Verb 'POST 200 '[JSON] Location -- 'privateArticlePrivateLinkCreate' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "private_links" :> Capture "link_id" Text :> Verb 'DELETE 200 '[JSON] () -- 'privateArticlePrivateLinkDelete' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "private_links" :> Capture "link_id" Text :> ReqBody '[JSON] PrivateLinkCreator :> Verb 'PUT 200 '[JSON] () -- 'privateArticlePrivateLinkUpdate' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "publish" :> Verb 'POST 200 '[JSON] Location -- 'privateArticlePublish' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "reserve_doi" :> Verb 'POST 200 '[JSON] ArticleDOI -- 'privateArticleReserveDoi' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "reserve_handle" :> Verb 'POST 200 '[JSON] ArticleHandle -- 'privateArticleReserveHandle' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> ReqBody '[JSON] ArticleUpdate :> Verb 'PUT 200 '[JSON] () -- 'privateArticleUpdate' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "files" :> Capture "file_id" Integer :> Verb 'POST 200 '[JSON] () -- 'privateArticleUploadComplete' route
    :<|> "account" :> "articles" :> Capture "article_id" Integer :> "files" :> ReqBody '[JSON] FileCreator :> Verb 'POST 200 '[JSON] Location -- 'privateArticleUploadInitiate' route
    :<|> "account" :> "articles" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> Verb 'GET 200 '[JSON] [Article] -- 'privateArticlesList' route
    :<|> "account" :> "articles" :> "search" :> ReqBody '[JSON] PrivateArticleSearch :> Verb 'POST 200 '[JSON] [Article] -- 'privateArticlesSearch' route
    :<|> "account" :> "authors" :> Capture "author_id" Integer :> Verb 'GET 200 '[JSON] AuthorComplete -- 'privateAuthorDetails' route
    :<|> "account" :> "authors" :> "search" :> ReqBody '[JSON] PrivateAuthorsSearch :> Verb 'POST 200 '[JSON] [Author] -- 'privateAuthorsSearch' route
    :<|> "collections" :> Capture "collection_id" Integer :> "articles" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> Verb 'GET 200 '[JSON] [Article] -- 'collectionArticles' route
    :<|> "collections" :> Capture "collection_id" Integer :> Verb 'GET 200 '[JSON] CollectionComplete -- 'collectionDetails' route
    :<|> "collections" :> Capture "collection_id" Integer :> "versions" :> Capture "version_id" Integer :> Verb 'GET 200 '[JSON] CollectionComplete -- 'collectionVersionDetails' route
    :<|> "collections" :> Capture "collection_id" Integer :> "versions" :> Verb 'GET 200 '[JSON] [CollectionVersions] -- 'collectionVersions' route
    :<|> "collections" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> QueryParam "order" Text :> QueryParam "order_direction" Text :> QueryParam "institution" Integer :> QueryParam "published_since" Text :> QueryParam "modified_since" Text :> QueryParam "group" Integer :> QueryParam "resource_doi" Text :> QueryParam "doi" Text :> QueryParam "handle" Text :> Verb 'GET 200 '[JSON] [Collection] -- 'collectionsList' route
    :<|> "collections" :> "search" :> ReqBody '[JSON] CollectionSearch :> Verb 'POST 200 '[JSON] [Collection] -- 'collectionsSearch' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "articles" :> Capture "article_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateCollectionArticleDelete' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "articles" :> ReqBody '[JSON] ArticlesCreator :> Verb 'POST 200 '[JSON] Location -- 'privateCollectionArticlesAdd' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "articles" :> Verb 'GET 200 '[JSON] [Article] -- 'privateCollectionArticlesList' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "articles" :> ReqBody '[JSON] ArticlesCreator :> Verb 'PUT 200 '[JSON] () -- 'privateCollectionArticlesReplace' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "authors" :> Capture "author_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateCollectionAuthorDelete' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "authors" :> ReqBody '[JSON] AuthorsCreator :> Verb 'POST 200 '[JSON] Location -- 'privateCollectionAuthorsAdd' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "authors" :> Verb 'GET 200 '[JSON] [Author] -- 'privateCollectionAuthorsList' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "authors" :> ReqBody '[JSON] AuthorsCreator :> Verb 'PUT 200 '[JSON] () -- 'privateCollectionAuthorsReplace' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "categories" :> ReqBody '[JSON] CategoriesCreator :> Verb 'POST 200 '[JSON] Location -- 'privateCollectionCategoriesAdd' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "categories" :> Verb 'GET 200 '[JSON] [Category] -- 'privateCollectionCategoriesList' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "categories" :> ReqBody '[JSON] CategoriesCreator :> Verb 'PUT 200 '[JSON] () -- 'privateCollectionCategoriesReplace' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "categories" :> Capture "category_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateCollectionCategoryDelete' route
    :<|> "account" :> "collections" :> ReqBody '[JSON] CollectionCreate :> Verb 'POST 200 '[JSON] CollectionComplete -- 'privateCollectionCreate' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateCollectionDelete' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> Verb 'GET 200 '[JSON] CollectionComplete -- 'privateCollectionDetails' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "private_links" :> ReqBody '[JSON] CollectionPrivateLinkCreator :> Verb 'POST 200 '[JSON] Location -- 'privateCollectionPrivateLinkCreate' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "private_links" :> Capture "link_id" Text :> Verb 'DELETE 200 '[JSON] () -- 'privateCollectionPrivateLinkDelete' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "private_links" :> Capture "link_id" Text :> ReqBody '[JSON] CollectionPrivateLinkCreator :> Verb 'PUT 200 '[JSON] () -- 'privateCollectionPrivateLinkUpdate' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "private_links" :> Verb 'GET 200 '[JSON] [PrivateLink] -- 'privateCollectionPrivateLinksList' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "publish" :> Verb 'POST 200 '[JSON] Location -- 'privateCollectionPublish' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "reserve_doi" :> Verb 'POST 200 '[JSON] CollectionDOI -- 'privateCollectionReserveDoi' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> "reserve_handle" :> Verb 'POST 200 '[JSON] CollectionHandle -- 'privateCollectionReserveHandle' route
    :<|> "account" :> "collections" :> Capture "collection_id" Integer :> ReqBody '[JSON] CollectionUpdate :> Verb 'PUT 200 '[JSON] () -- 'privateCollectionUpdate' route
    :<|> "account" :> "collections" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> QueryParam "order" Text :> QueryParam "order_direction" Text :> Verb 'GET 200 '[JSON] [Collection] -- 'privateCollectionsList' route
    :<|> "account" :> "collections" :> "search" :> ReqBody '[JSON] PrivateCollectionSearch :> Verb 'POST 200 '[JSON] [Collection] -- 'privateCollectionsSearch' route
    :<|> "account" :> "institution" :> "review" :> Capture "curation_id" Integer :> Verb 'GET 200 '[JSON] CurationDetail -- 'accountInstitutionCuration' route
    :<|> "account" :> "institution" :> "review" :> Capture "curation_id" Integer :> "comments" :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> Verb 'GET 200 '[JSON] CurationComment -- 'accountInstitutionCurationComments' route
    :<|> "account" :> "institution" :> "review" :> Capture "curation_id" Integer :> "comments" :> ReqBody '[JSON] CurationCommentCreate :> Verb 'POST 200 '[JSON] () -- 'accountInstitutionCurationComments_0' route
    :<|> "account" :> "institution" :> "reviews" :> QueryParam "group_id" Integer :> QueryParam "article_id" Integer :> QueryParam "status" Text :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> Verb 'GET 200 '[JSON] Curation -- 'accountInstitutionCurations' route
    :<|> "institutions" :> Capture "institution_string_id" Text :> "articles" :> "filter-by" :> QueryParam "resource_id" Text :> QueryParam "filename" Text :> Verb 'GET 200 '[JSON] [Article] -- 'institutionArticles' route
    :<|> "institution" :> "hrfeed" :> "upload" :> ReqBody '[FormUrlEncoded] FormInstitutionHrfeedUpload :> Verb 'POST 200 '[JSON] ResponseMessage -- 'institutionHrfeedUpload' route
    :<|> "account" :> "institution" :> "users" :> Capture "account_id" Integer :> Verb 'GET 200 '[JSON] User -- 'privateAccountInstitutionUser' route
    :<|> "account" :> "categories" :> Verb 'GET 200 '[JSON] [Category] -- 'privateCategoriesList' route
    :<|> "account" :> "institution" :> "groups" :> Capture "group_id" Integer :> "embargo_options" :> Verb 'GET 200 '[JSON] [GroupEmbargoOptions] -- 'privateGroupEmbargoOptionsDetails' route
    :<|> "account" :> "institution" :> "roles" :> Capture "account_id" Integer :> Capture "group_id" Integer :> Capture "role_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateInstitutionAccountGroupRoleDelete' route
    :<|> "account" :> "institution" :> "roles" :> Capture "account_id" Integer :> Verb 'GET 200 '[JSON] AccountGroupRoles -- 'privateInstitutionAccountGroupRoles' route
    :<|> "account" :> "institution" :> "roles" :> Capture "account_id" Integer :> ReqBody '[JSON] AccountGroupRolesCreate :> Verb 'POST 200 '[JSON] () -- 'privateInstitutionAccountGroupRolesCreate' route
    :<|> "account" :> "institution" :> "accounts" :> ReqBody '[JSON] AccountCreate :> Verb 'POST 200 '[JSON] () -- 'privateInstitutionAccountsCreate' route
    :<|> "account" :> "institution" :> "accounts" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> QueryParam "is_active" Integer :> QueryParam "institution_user_id" Text :> QueryParam "email" Text :> Verb 'GET 200 '[JSON] [ShortAccount] -- 'privateInstitutionAccountsList' route
    :<|> "account" :> "institution" :> "accounts" :> "search" :> ReqBody '[JSON] InstitutionAccountsSearch :> Verb 'POST 200 '[JSON] [ShortAccount] -- 'privateInstitutionAccountsSearch' route
    :<|> "account" :> "institution" :> "accounts" :> Capture "account_id" Integer :> ReqBody '[JSON] AccountUpdate :> Verb 'PUT 200 '[JSON] () -- 'privateInstitutionAccountsUpdate' route
    :<|> "account" :> "institution" :> "articles" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> QueryParam "order" Text :> QueryParam "order_direction" Text :> QueryParam "published_since" Text :> QueryParam "modified_since" Text :> QueryParam "status" Integer :> QueryParam "resource_doi" Text :> QueryParam "item_type" Integer :> Verb 'GET 200 '[JSON] [Article] -- 'privateInstitutionArticles' route
    :<|> "account" :> "institution" :> Verb 'GET 200 '[JSON] Institution -- 'privateInstitutionDetails' route
    :<|> "account" :> "institution" :> "embargo_options" :> Verb 'GET 200 '[JSON] [GroupEmbargoOptions] -- 'privateInstitutionEmbargoOptionsDetails' route
    :<|> "account" :> "institution" :> "groups" :> Verb 'GET 200 '[JSON] [Group] -- 'privateInstitutionGroupsList' route
    :<|> "account" :> "institution" :> "roles" :> Verb 'GET 200 '[JSON] [Role] -- 'privateInstitutionRolesList' route
    :<|> "categories" :> Verb 'GET 200 '[JSON] [Category] -- 'categoriesList' route
    :<|> "file" :> "download" :> Capture "file_id" Integer :> Verb 'GET 200 '[JSON] () -- 'fileDownload' route
    :<|> "licenses" :> Verb 'GET 200 '[JSON] [License] -- 'licensesList' route
    :<|> "account" :> Verb 'GET 200 '[JSON] Account -- 'privateAccount' route
    :<|> "account" :> "funding" :> "search" :> ReqBody '[JSON] FundingSearch :> Verb 'POST 200 '[JSON] [FundingInformation] -- 'privateFundingSearch' route
    :<|> "account" :> "licenses" :> Verb 'GET 200 '[JSON] [License] -- 'privateLicensesList' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "articles" :> Capture "article_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateProjectArticleDelete' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "articles" :> Capture "article_id" Integer :> Verb 'GET 200 '[JSON] ProjectArticle -- 'privateProjectArticleDetails' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "articles" :> Capture "article_id" Integer :> "files" :> Capture "file_id" Integer :> Verb 'GET 200 '[JSON] PrivateFile -- 'privateProjectArticleFile' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "articles" :> Capture "article_id" Integer :> "files" :> Verb 'GET 200 '[JSON] [PrivateFile] -- 'privateProjectArticleFiles' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "articles" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> ReqBody '[JSON] ArticleProjectCreate :> Verb 'POST 200 '[JSON] Location -- 'privateProjectArticlesCreate' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "articles" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> Verb 'GET 200 '[JSON] [Article] -- 'privateProjectArticlesList' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "collaborators" :> Capture "user_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateProjectCollaboratorDelete' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "collaborators" :> ReqBody '[JSON] ProjectCollaboratorInvite :> Verb 'POST 200 '[JSON] ResponseMessage -- 'privateProjectCollaboratorsInvite' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "collaborators" :> Verb 'GET 200 '[JSON] [ProjectCollaborator] -- 'privateProjectCollaboratorsList' route
    :<|> "account" :> "projects" :> ReqBody '[JSON] ProjectCreate :> Verb 'POST 200 '[JSON] Location -- 'privateProjectCreate' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateProjectDelete' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> Verb 'GET 200 '[JSON] ProjectCompletePrivate -- 'privateProjectDetails' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "leave" :> Verb 'POST 200 '[JSON] () -- 'privateProjectLeave' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "notes" :> Capture "note_id" Integer :> Verb 'GET 200 '[JSON] ProjectNotePrivate -- 'privateProjectNote' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "notes" :> Capture "note_id" Integer :> Verb 'DELETE 200 '[JSON] () -- 'privateProjectNoteDelete' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "notes" :> Capture "note_id" Integer :> ReqBody '[JSON] ProjectNoteCreate :> Verb 'PUT 200 '[JSON] () -- 'privateProjectNoteUpdate' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "notes" :> ReqBody '[JSON] ProjectNoteCreate :> Verb 'POST 200 '[JSON] Location -- 'privateProjectNotesCreate' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "notes" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> Verb 'GET 200 '[JSON] [ProjectNote] -- 'privateProjectNotesList' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> "publish" :> Verb 'POST 200 '[JSON] ResponseMessage -- 'privateProjectPublish' route
    :<|> "account" :> "projects" :> Capture "project_id" Integer :> ReqBody '[JSON] ProjectUpdate :> Verb 'PUT 200 '[JSON] () -- 'privateProjectUpdate' route
    :<|> "account" :> "projects" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> QueryParam "order" Text :> QueryParam "order_direction" Text :> QueryParam "storage" Text :> QueryParam "roles" Text :> Verb 'GET 200 '[JSON] [ProjectPrivate] -- 'privateProjectsList' route
    :<|> "account" :> "projects" :> "search" :> ReqBody '[JSON] ProjectsSearch :> Verb 'POST 200 '[JSON] [ProjectPrivate] -- 'privateProjectsSearch' route
    :<|> "projects" :> Capture "project_id" Integer :> "articles" :> Verb 'GET 200 '[JSON] [Article] -- 'projectArticles' route
    :<|> "projects" :> Capture "project_id" Integer :> Verb 'GET 200 '[JSON] ProjectComplete -- 'projectDetails' route
    :<|> "projects" :> QueryParam "page" Integer :> QueryParam "page_size" Integer :> QueryParam "limit" Integer :> QueryParam "offset" Integer :> QueryParam "order" Text :> QueryParam "order_direction" Text :> QueryParam "institution" Integer :> QueryParam "published_since" Text :> QueryParam "group" Integer :> Verb 'GET 200 '[JSON] [Project] -- 'projectsList' route
    :<|> "projects" :> "search" :> ReqBody '[JSON] ProjectsSearch :> Verb 'POST 200 '[JSON] [Project] -- 'projectsSearch' route

-- | Server or client configuration, specifying the host and port to query or serve on.
data ServerConfig = ServerConfig
  { configHost :: String  -- ^ Hostname to serve on, e.g. "127.0.0.1"
  , configPort :: Int      -- ^ Port to serve on, e.g. 8080
  } deriving (Eq, Ord, Show, Read)

-- | List of elements parsed from a query.
newtype QueryList (p :: CollectionFormat) a = QueryList
  { fromQueryList :: [a]
  } deriving (Functor, Applicative, Monad, Foldable, Traversable)

-- | Formats in which a list can be encoded into a HTTP path.
data CollectionFormat
  = CommaSeparated -- ^ CSV format for multiple parameters.
  | SpaceSeparated -- ^ Also called "SSV"
  | TabSeparated -- ^ Also called "TSV"
  | PipeSeparated -- ^ `value1|value2|value2`
  | MultiParamArray -- ^ Using multiple GET parameters, e.g. `foo=bar&foo=baz`. Only for GET params.

instance FromHttpApiData a => FromHttpApiData (QueryList 'CommaSeparated a) where
  parseQueryParam = parseSeparatedQueryList ','

instance FromHttpApiData a => FromHttpApiData (QueryList 'TabSeparated a) where
  parseQueryParam = parseSeparatedQueryList '\t'

instance FromHttpApiData a => FromHttpApiData (QueryList 'SpaceSeparated a) where
  parseQueryParam = parseSeparatedQueryList ' '

instance FromHttpApiData a => FromHttpApiData (QueryList 'PipeSeparated a) where
  parseQueryParam = parseSeparatedQueryList '|'

instance FromHttpApiData a => FromHttpApiData (QueryList 'MultiParamArray a) where
  parseQueryParam = error "unimplemented FromHttpApiData for MultiParamArray collection format"

parseSeparatedQueryList :: FromHttpApiData a => Char -> Text -> Either Text (QueryList p a)
parseSeparatedQueryList char = fmap QueryList . mapM parseQueryParam . T.split (== char)

instance ToHttpApiData a => ToHttpApiData (QueryList 'CommaSeparated a) where
  toQueryParam = formatSeparatedQueryList ','

instance ToHttpApiData a => ToHttpApiData (QueryList 'TabSeparated a) where
  toQueryParam = formatSeparatedQueryList '\t'

instance ToHttpApiData a => ToHttpApiData (QueryList 'SpaceSeparated a) where
  toQueryParam = formatSeparatedQueryList ' '

instance ToHttpApiData a => ToHttpApiData (QueryList 'PipeSeparated a) where
  toQueryParam = formatSeparatedQueryList '|'

instance ToHttpApiData a => ToHttpApiData (QueryList 'MultiParamArray a) where
  toQueryParam = error "unimplemented ToHttpApiData for MultiParamArray collection format"

formatSeparatedQueryList :: ToHttpApiData a => Char ->  QueryList p a -> Text
formatSeparatedQueryList char = T.intercalate (T.singleton char) . map toQueryParam . fromQueryList


-- | Backend for Figshare.
-- The backend can be used both for the client and the server. The client generated from the Figshare Swagger spec
-- is a backend that executes actions by sending HTTP requests (see @createFigshareClient@). Alternatively, provided
-- a backend, the API can be served using @runFigshareServer@.
data FigshareBackend m = FigshareBackend
  { accountArticleReport :: Maybe Integer -> m [AccountReport]{- ^ Return status on all reports generated for the account from the oauth credentials -}
  , accountArticleReportGenerate :: m AccountReport{- ^ Initiate a new Article Report for this Account -}
  , articleDetails :: Integer -> m ArticleComplete{- ^ View an article -}
  , articleFileDetails :: Integer -> Integer -> m PublicFile{- ^ File by id -}
  , articleFiles :: Integer -> m [PublicFile]{- ^ Files list for article -}
  , articleVersionConfidentiality :: Integer -> Integer -> m ArticleConfidentiality{- ^ Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows. -}
  , articleVersionDetails :: Integer -> Integer -> m ArticleComplete{- ^ Article with specified version -}
  , articleVersionEmbargo :: Integer -> Integer -> m ArticleEmbargo{- ^ Embargo for article version -}
  , articleVersionUpdateThumb :: Integer -> Integer -> FileId -> m (){- ^ For a given public article version update the article thumb by choosing one of the associated files -}
  , articleVersions :: Integer -> m [ArticleVersions]{- ^ List public article versions -}
  , articlesList :: Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Text -> Maybe Text -> Maybe Integer -> Maybe Text -> Maybe Text -> Maybe Integer -> Maybe Text -> Maybe Integer -> Maybe Text -> Maybe Text -> m [Article]{- ^ Returns a list of public articles -}
  , articlesSearch :: ArticleSearch -> m [Article]{- ^ Returns a list of public articles, filtered by the search parameters -}
  , privateArticleAuthorDelete :: Integer -> Integer -> m (){- ^ De-associate author from article -}
  , privateArticleAuthorsAdd :: Integer -> AuthorsCreator -> m (){- ^ Associate new authors with the article. This will add new authors to the list of already associated authors -}
  , privateArticleAuthorsList :: Integer -> m [Author]{- ^ List article authors -}
  , privateArticleAuthorsReplace :: Integer -> AuthorsCreator -> m (){- ^ Associate new authors with the article. This will remove all already associated authors and add these new ones -}
  , privateArticleCategoriesAdd :: Integer -> CategoriesCreator -> m (){- ^ Associate new categories with the article. This will add new categories to the list of already associated categories -}
  , privateArticleCategoriesList :: Integer -> m [Category]{- ^ List article categories -}
  , privateArticleCategoriesReplace :: Integer -> CategoriesCreator -> m (){- ^ Associate new categories with the article. This will remove all already associated categories and add these new ones -}
  , privateArticleCategoryDelete :: Integer -> Integer -> m (){- ^ De-associate category from article -}
  , privateArticleConfidentialityDelete :: Integer -> m (){- ^ Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows. -}
  , privateArticleConfidentialityDetails :: Integer -> m ArticleConfidentiality{- ^ View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows. -}
  , privateArticleConfidentialityUpdate :: Integer -> ConfidentialityCreator -> m (){- ^ Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows. -}
  , privateArticleCreate :: ArticleCreate -> m Location{- ^ Create a new Article by sending article information -}
  , privateArticleDelete :: Integer -> m (){- ^ Delete an article -}
  , privateArticleDetails :: Integer -> m ArticleCompletePrivate{- ^ View a private article -}
  , privateArticleEmbargoDelete :: Integer -> m (){- ^ Will lift the embargo for the specified article -}
  , privateArticleEmbargoDetails :: Integer -> m ArticleEmbargo{- ^ View a private article embargo details -}
  , privateArticleEmbargoUpdate :: Integer -> ArticleEmbargoUpdater -> m (){- ^ Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality. -}
  , privateArticleFile :: Integer -> Integer -> m PrivateFile{- ^ View details of file for specified article -}
  , privateArticleFileDelete :: Integer -> Integer -> m (){- ^ Complete file upload -}
  , privateArticleFilesList :: Integer -> m [PrivateFile]{- ^ List private files -}
  , privateArticlePrivateLink :: Integer -> m [PrivateLink]{- ^ List private links -}
  , privateArticlePrivateLinkCreate :: Integer -> PrivateLinkCreator -> m Location{- ^ Create new private link for this article -}
  , privateArticlePrivateLinkDelete :: Integer -> Text -> m (){- ^ Disable/delete private link for this article -}
  , privateArticlePrivateLinkUpdate :: Integer -> Text -> PrivateLinkCreator -> m (){- ^ Update existing private link for this article -}
  , privateArticlePublish :: Integer -> m Location{- ^ - If the whole article is under embargo, it will not be published immediatly, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed. -}
  , privateArticleReserveDoi :: Integer -> m ArticleDOI{- ^ Reserve DOI for article -}
  , privateArticleReserveHandle :: Integer -> m ArticleHandle{- ^ Reserve Handle for article -}
  , privateArticleUpdate :: Integer -> ArticleUpdate -> m (){- ^ Updating an article by passing body parameters -}
  , privateArticleUploadComplete :: Integer -> Integer -> m (){- ^ Complete file upload -}
  , privateArticleUploadInitiate :: Integer -> FileCreator -> m Location{- ^ Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size). -}
  , privateArticlesList :: Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> m [Article]{- ^ Get Own Articles -}
  , privateArticlesSearch :: PrivateArticleSearch -> m [Article]{- ^ Returns a list of private articles filtered by the search parameters -}
  , privateAuthorDetails :: Integer -> m AuthorComplete{- ^ View author details -}
  , privateAuthorsSearch :: PrivateAuthorsSearch -> m [Author]{- ^ Search for authors -}
  , collectionArticles :: Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> m [Article]{- ^ Returns a list of public collection articles -}
  , collectionDetails :: Integer -> m CollectionComplete{- ^ View a collection -}
  , collectionVersionDetails :: Integer -> Integer -> m CollectionComplete{- ^ View details for a certain version of a collection -}
  , collectionVersions :: Integer -> m [CollectionVersions]{- ^ Returns a list of public collection Versions -}
  , collectionsList :: Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Text -> Maybe Text -> Maybe Integer -> Maybe Text -> Maybe Text -> Maybe Integer -> Maybe Text -> Maybe Text -> Maybe Text -> m [Collection]{- ^ Returns a list of public collections -}
  , collectionsSearch :: CollectionSearch -> m [Collection]{- ^ Returns a list of public collections -}
  , privateCollectionArticleDelete :: Integer -> Integer -> m (){- ^ De-associate article from collection -}
  , privateCollectionArticlesAdd :: Integer -> ArticlesCreator -> m Location{- ^ Associate new articles with the collection. This will add new articles to the list of already associated articles -}
  , privateCollectionArticlesList :: Integer -> m [Article]{- ^ List collection articles -}
  , privateCollectionArticlesReplace :: Integer -> ArticlesCreator -> m (){- ^ Associate new articles with the collection. This will remove all already associated articles and add these new ones -}
  , privateCollectionAuthorDelete :: Integer -> Integer -> m (){- ^ Delete collection author -}
  , privateCollectionAuthorsAdd :: Integer -> AuthorsCreator -> m Location{- ^ Associate new authors with the collection. This will add new authors to the list of already associated authors -}
  , privateCollectionAuthorsList :: Integer -> m [Author]{- ^ List collection authors -}
  , privateCollectionAuthorsReplace :: Integer -> AuthorsCreator -> m (){- ^ Associate new authors with the collection. This will remove all already associated authors and add these new ones -}
  , privateCollectionCategoriesAdd :: Integer -> CategoriesCreator -> m Location{- ^ Associate new categories with the collection. This will add new categories to the list of already associated categories -}
  , privateCollectionCategoriesList :: Integer -> m [Category]{- ^ List collection categories -}
  , privateCollectionCategoriesReplace :: Integer -> CategoriesCreator -> m (){- ^ Associate new categories with the collection. This will remove all already associated categories and add these new ones -}
  , privateCollectionCategoryDelete :: Integer -> Integer -> m (){- ^ De-associate category from collection -}
  , privateCollectionCreate :: CollectionCreate -> m CollectionComplete{- ^ Create a new Collection by sending collection information -}
  , privateCollectionDelete :: Integer -> m (){- ^ Delete n collection -}
  , privateCollectionDetails :: Integer -> m CollectionComplete{- ^ View a collection -}
  , privateCollectionPrivateLinkCreate :: Integer -> CollectionPrivateLinkCreator -> m Location{- ^ Create new private link -}
  , privateCollectionPrivateLinkDelete :: Integer -> Text -> m (){- ^ Disable/delete private link for this collection -}
  , privateCollectionPrivateLinkUpdate :: Integer -> Text -> CollectionPrivateLinkCreator -> m (){- ^ Update existing private link for this collection -}
  , privateCollectionPrivateLinksList :: Integer -> m [PrivateLink]{- ^ List article private links -}
  , privateCollectionPublish :: Integer -> m Location{- ^ When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed. -}
  , privateCollectionReserveDoi :: Integer -> m CollectionDOI{- ^ Reserve DOI for collection -}
  , privateCollectionReserveHandle :: Integer -> m CollectionHandle{- ^ Reserve Handle for collection -}
  , privateCollectionUpdate :: Integer -> CollectionUpdate -> m (){- ^ Update collection details -}
  , privateCollectionsList :: Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Text -> Maybe Text -> m [Collection]{- ^ List private collections -}
  , privateCollectionsSearch :: PrivateCollectionSearch -> m [Collection]{- ^ Returns a list of private Collections -}
  , accountInstitutionCuration :: Integer -> m CurationDetail{- ^ Retrieve a certain curation review by its ID -}
  , accountInstitutionCurationComments :: Integer -> Maybe Integer -> Maybe Integer -> m CurationComment{- ^ Retrieve a certain curation review's comments. -}
  , accountInstitutionCurationComments_0 :: Integer -> CurationCommentCreate -> m (){- ^ Add a new comment to the review. -}
  , accountInstitutionCurations :: Maybe Integer -> Maybe Integer -> Maybe Text -> Maybe Integer -> Maybe Integer -> m Curation{- ^ Retrieve a list of curation reviews for this institution -}
  , institutionArticles :: Text -> Maybe Text -> Maybe Text -> m [Article]{- ^ Returns a list of articles belonging to the institution -}
  , institutionHrfeedUpload :: FormInstitutionHrfeedUpload -> m ResponseMessage{- ^ More info in the <a href=\"#hr_feed\">HR Feed section</a> -}
  , privateAccountInstitutionUser :: Integer -> m User{- ^ Retrieve institution user information using the account_id -}
  , privateCategoriesList :: m [Category]{- ^ List institution categories (including parent Categories) -}
  , privateGroupEmbargoOptionsDetails :: Integer -> m [GroupEmbargoOptions]{- ^ Account institution group embargo options details -}
  , privateInstitutionAccountGroupRoleDelete :: Integer -> Integer -> Integer -> m (){- ^ Delete Institution Account Group Role -}
  , privateInstitutionAccountGroupRoles :: Integer -> m AccountGroupRoles{- ^ List Institution Account Group Roles -}
  , privateInstitutionAccountGroupRolesCreate :: Integer -> AccountGroupRolesCreate -> m (){- ^ Add Institution Account Group Roles -}
  , privateInstitutionAccountsCreate :: AccountCreate -> m (){- ^ Create a new Account by sending account information -}
  , privateInstitutionAccountsList :: Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Text -> Maybe Text -> m [ShortAccount]{- ^ Returns the accounts for which the account has administrative privileges (assigned and inherited). -}
  , privateInstitutionAccountsSearch :: InstitutionAccountsSearch -> m [ShortAccount]{- ^ Returns the accounts for which the account has administrative privileges (assigned and inherited). -}
  , privateInstitutionAccountsUpdate :: Integer -> AccountUpdate -> m (){- ^ Update Institution Account -}
  , privateInstitutionArticles :: Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Text -> Maybe Text -> Maybe Text -> Maybe Text -> Maybe Integer -> Maybe Text -> Maybe Integer -> m [Article]{- ^ Get Articles from own institution. User must be administrator of the institution -}
  , privateInstitutionDetails :: m Institution{- ^ Account institution details -}
  , privateInstitutionEmbargoOptionsDetails :: m [GroupEmbargoOptions]{- ^ Account institution embargo options details -}
  , privateInstitutionGroupsList :: m [Group]{- ^ Returns the groups for which the account has administrative privileges (assigned and inherited). -}
  , privateInstitutionRolesList :: m [Role]{- ^ Returns the roles available for groups and the institution group. -}
  , categoriesList :: m [Category]{- ^ Returns a list of public categories -}
  , fileDownload :: Integer -> m (){- ^ Starts the download of a file -}
  , licensesList :: m [License]{- ^ Returns a list of public licenses -}
  , privateAccount :: m Account{- ^ Account information for token/personal token -}
  , privateFundingSearch :: FundingSearch -> m [FundingInformation]{- ^ Search for fundings -}
  , privateLicensesList :: m [License]{- ^ This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution. -}
  , privateProjectArticleDelete :: Integer -> Integer -> m (){- ^ Delete project article -}
  , privateProjectArticleDetails :: Integer -> Integer -> m ProjectArticle{- ^ Project article details -}
  , privateProjectArticleFile :: Integer -> Integer -> Integer -> m PrivateFile{- ^ Project article file details -}
  , privateProjectArticleFiles :: Integer -> Integer -> m [PrivateFile]{- ^ List article files -}
  , privateProjectArticlesCreate :: Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> ArticleProjectCreate -> m Location{- ^ Create a new Article and associate it with this project -}
  , privateProjectArticlesList :: Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> m [Article]{- ^ List project articles -}
  , privateProjectCollaboratorDelete :: Integer -> Integer -> m (){- ^ Remove project collaborator -}
  , privateProjectCollaboratorsInvite :: Integer -> ProjectCollaboratorInvite -> m ResponseMessage{- ^ Invite users to collaborate on project or view the project -}
  , privateProjectCollaboratorsList :: Integer -> m [ProjectCollaborator]{- ^ List Project collaborators and invited users -}
  , privateProjectCreate :: ProjectCreate -> m Location{- ^ Create a new project -}
  , privateProjectDelete :: Integer -> m (){- ^ A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project.  -}
  , privateProjectDetails :: Integer -> m ProjectCompletePrivate{- ^ View a private project -}
  , privateProjectLeave :: Integer -> m (){- ^ Please note: project's owner cannot leave the project. -}
  , privateProjectNote :: Integer -> Integer -> m ProjectNotePrivate{- ^  -}
  , privateProjectNoteDelete :: Integer -> Integer -> m (){- ^  -}
  , privateProjectNoteUpdate :: Integer -> Integer -> ProjectNoteCreate -> m (){- ^  -}
  , privateProjectNotesCreate :: Integer -> ProjectNoteCreate -> m Location{- ^ Create a new project note -}
  , privateProjectNotesList :: Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> m [ProjectNote]{- ^ List project notes -}
  , privateProjectPublish :: Integer -> m ResponseMessage{- ^ Publish a project. Possible after all items inside it are public -}
  , privateProjectUpdate :: Integer -> ProjectUpdate -> m (){- ^ Updating an project by passing body parameters -}
  , privateProjectsList :: Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Text -> Maybe Text -> Maybe Text -> Maybe Text -> m [ProjectPrivate]{- ^ List private projects -}
  , privateProjectsSearch :: ProjectsSearch -> m [ProjectPrivate]{- ^ Search inside the private projects -}
  , projectArticles :: Integer -> m [Article]{- ^ List articles in project -}
  , projectDetails :: Integer -> m ProjectComplete{- ^ View a project -}
  , projectsList :: Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Integer -> Maybe Text -> Maybe Text -> Maybe Integer -> Maybe Text -> Maybe Integer -> m [Project]{- ^ Returns a list of public projects -}
  , projectsSearch :: ProjectsSearch -> m [Project]{- ^ Returns a list of public articles -}
  }

newtype FigshareClient a = FigshareClient
  { runClient :: Manager -> BaseUrl -> ExceptT ServantError IO a
  } deriving Functor

instance Applicative FigshareClient where
  pure x = FigshareClient (\_ _ -> pure x)
  (FigshareClient f) <*> (FigshareClient x) =
    FigshareClient (\manager url -> f manager url <*> x manager url)

instance Monad FigshareClient where
  (FigshareClient a) >>= f =
    FigshareClient (\manager url -> do
      value <- a manager url
      runClient (f value) manager url)

instance MonadIO FigshareClient where
  liftIO io = FigshareClient (\_ _ -> liftIO io)

createFigshareClient :: FigshareBackend FigshareClient
createFigshareClient = FigshareBackend{..}
  where
    ((coerce -> accountArticleReport) :<|>
     (coerce -> accountArticleReportGenerate) :<|>
     (coerce -> articleDetails) :<|>
     (coerce -> articleFileDetails) :<|>
     (coerce -> articleFiles) :<|>
     (coerce -> articleVersionConfidentiality) :<|>
     (coerce -> articleVersionDetails) :<|>
     (coerce -> articleVersionEmbargo) :<|>
     (coerce -> articleVersionUpdateThumb) :<|>
     (coerce -> articleVersions) :<|>
     (coerce -> articlesList) :<|>
     (coerce -> articlesSearch) :<|>
     (coerce -> privateArticleAuthorDelete) :<|>
     (coerce -> privateArticleAuthorsAdd) :<|>
     (coerce -> privateArticleAuthorsList) :<|>
     (coerce -> privateArticleAuthorsReplace) :<|>
     (coerce -> privateArticleCategoriesAdd) :<|>
     (coerce -> privateArticleCategoriesList) :<|>
     (coerce -> privateArticleCategoriesReplace) :<|>
     (coerce -> privateArticleCategoryDelete) :<|>
     (coerce -> privateArticleConfidentialityDelete) :<|>
     (coerce -> privateArticleConfidentialityDetails) :<|>
     (coerce -> privateArticleConfidentialityUpdate) :<|>
     (coerce -> privateArticleCreate) :<|>
     (coerce -> privateArticleDelete) :<|>
     (coerce -> privateArticleDetails) :<|>
     (coerce -> privateArticleEmbargoDelete) :<|>
     (coerce -> privateArticleEmbargoDetails) :<|>
     (coerce -> privateArticleEmbargoUpdate) :<|>
     (coerce -> privateArticleFile) :<|>
     (coerce -> privateArticleFileDelete) :<|>
     (coerce -> privateArticleFilesList) :<|>
     (coerce -> privateArticlePrivateLink) :<|>
     (coerce -> privateArticlePrivateLinkCreate) :<|>
     (coerce -> privateArticlePrivateLinkDelete) :<|>
     (coerce -> privateArticlePrivateLinkUpdate) :<|>
     (coerce -> privateArticlePublish) :<|>
     (coerce -> privateArticleReserveDoi) :<|>
     (coerce -> privateArticleReserveHandle) :<|>
     (coerce -> privateArticleUpdate) :<|>
     (coerce -> privateArticleUploadComplete) :<|>
     (coerce -> privateArticleUploadInitiate) :<|>
     (coerce -> privateArticlesList) :<|>
     (coerce -> privateArticlesSearch) :<|>
     (coerce -> privateAuthorDetails) :<|>
     (coerce -> privateAuthorsSearch) :<|>
     (coerce -> collectionArticles) :<|>
     (coerce -> collectionDetails) :<|>
     (coerce -> collectionVersionDetails) :<|>
     (coerce -> collectionVersions) :<|>
     (coerce -> collectionsList) :<|>
     (coerce -> collectionsSearch) :<|>
     (coerce -> privateCollectionArticleDelete) :<|>
     (coerce -> privateCollectionArticlesAdd) :<|>
     (coerce -> privateCollectionArticlesList) :<|>
     (coerce -> privateCollectionArticlesReplace) :<|>
     (coerce -> privateCollectionAuthorDelete) :<|>
     (coerce -> privateCollectionAuthorsAdd) :<|>
     (coerce -> privateCollectionAuthorsList) :<|>
     (coerce -> privateCollectionAuthorsReplace) :<|>
     (coerce -> privateCollectionCategoriesAdd) :<|>
     (coerce -> privateCollectionCategoriesList) :<|>
     (coerce -> privateCollectionCategoriesReplace) :<|>
     (coerce -> privateCollectionCategoryDelete) :<|>
     (coerce -> privateCollectionCreate) :<|>
     (coerce -> privateCollectionDelete) :<|>
     (coerce -> privateCollectionDetails) :<|>
     (coerce -> privateCollectionPrivateLinkCreate) :<|>
     (coerce -> privateCollectionPrivateLinkDelete) :<|>
     (coerce -> privateCollectionPrivateLinkUpdate) :<|>
     (coerce -> privateCollectionPrivateLinksList) :<|>
     (coerce -> privateCollectionPublish) :<|>
     (coerce -> privateCollectionReserveDoi) :<|>
     (coerce -> privateCollectionReserveHandle) :<|>
     (coerce -> privateCollectionUpdate) :<|>
     (coerce -> privateCollectionsList) :<|>
     (coerce -> privateCollectionsSearch) :<|>
     (coerce -> accountInstitutionCuration) :<|>
     (coerce -> accountInstitutionCurationComments) :<|>
     (coerce -> accountInstitutionCurationComments_0) :<|>
     (coerce -> accountInstitutionCurations) :<|>
     (coerce -> institutionArticles) :<|>
     (coerce -> institutionHrfeedUpload) :<|>
     (coerce -> privateAccountInstitutionUser) :<|>
     (coerce -> privateCategoriesList) :<|>
     (coerce -> privateGroupEmbargoOptionsDetails) :<|>
     (coerce -> privateInstitutionAccountGroupRoleDelete) :<|>
     (coerce -> privateInstitutionAccountGroupRoles) :<|>
     (coerce -> privateInstitutionAccountGroupRolesCreate) :<|>
     (coerce -> privateInstitutionAccountsCreate) :<|>
     (coerce -> privateInstitutionAccountsList) :<|>
     (coerce -> privateInstitutionAccountsSearch) :<|>
     (coerce -> privateInstitutionAccountsUpdate) :<|>
     (coerce -> privateInstitutionArticles) :<|>
     (coerce -> privateInstitutionDetails) :<|>
     (coerce -> privateInstitutionEmbargoOptionsDetails) :<|>
     (coerce -> privateInstitutionGroupsList) :<|>
     (coerce -> privateInstitutionRolesList) :<|>
     (coerce -> categoriesList) :<|>
     (coerce -> fileDownload) :<|>
     (coerce -> licensesList) :<|>
     (coerce -> privateAccount) :<|>
     (coerce -> privateFundingSearch) :<|>
     (coerce -> privateLicensesList) :<|>
     (coerce -> privateProjectArticleDelete) :<|>
     (coerce -> privateProjectArticleDetails) :<|>
     (coerce -> privateProjectArticleFile) :<|>
     (coerce -> privateProjectArticleFiles) :<|>
     (coerce -> privateProjectArticlesCreate) :<|>
     (coerce -> privateProjectArticlesList) :<|>
     (coerce -> privateProjectCollaboratorDelete) :<|>
     (coerce -> privateProjectCollaboratorsInvite) :<|>
     (coerce -> privateProjectCollaboratorsList) :<|>
     (coerce -> privateProjectCreate) :<|>
     (coerce -> privateProjectDelete) :<|>
     (coerce -> privateProjectDetails) :<|>
     (coerce -> privateProjectLeave) :<|>
     (coerce -> privateProjectNote) :<|>
     (coerce -> privateProjectNoteDelete) :<|>
     (coerce -> privateProjectNoteUpdate) :<|>
     (coerce -> privateProjectNotesCreate) :<|>
     (coerce -> privateProjectNotesList) :<|>
     (coerce -> privateProjectPublish) :<|>
     (coerce -> privateProjectUpdate) :<|>
     (coerce -> privateProjectsList) :<|>
     (coerce -> privateProjectsSearch) :<|>
     (coerce -> projectArticles) :<|>
     (coerce -> projectDetails) :<|>
     (coerce -> projectsList) :<|>
     (coerce -> projectsSearch)) = client (Proxy :: Proxy FigshareAPI)

-- | Run requests in the FigshareClient monad.
runFigshareClient :: ServerConfig -> FigshareClient a -> ExceptT ServantError IO a
runFigshareClient clientConfig cl = do
  manager <- liftIO $ newManager defaultManagerSettings
  runFigshareClientWithManager manager clientConfig cl

-- | Run requests in the FigshareClient monad using a custom manager.
runFigshareClientWithManager :: Manager -> ServerConfig -> FigshareClient a -> ExceptT ServantError IO a
runFigshareClientWithManager manager clientConfig cl =
  runClient cl manager $ BaseUrl Http (configHost clientConfig) (configPort clientConfig) ""

-- | Run the Figshare server at the provided host and port.
runFigshareServer :: MonadIO m => ServerConfig -> FigshareBackend (ExceptT ServantErr IO)  -> m ()
runFigshareServer ServerConfig{..} backend =
  liftIO $ Warp.runSettings warpSettings $ serve (Proxy :: Proxy FigshareAPI) (serverFromBackend backend)
  where
    warpSettings = Warp.defaultSettings & Warp.setPort configPort & Warp.setHost (fromString configHost)
    serverFromBackend FigshareBackend{..} =
      (coerce accountArticleReport :<|>
       coerce accountArticleReportGenerate :<|>
       coerce articleDetails :<|>
       coerce articleFileDetails :<|>
       coerce articleFiles :<|>
       coerce articleVersionConfidentiality :<|>
       coerce articleVersionDetails :<|>
       coerce articleVersionEmbargo :<|>
       coerce articleVersionUpdateThumb :<|>
       coerce articleVersions :<|>
       coerce articlesList :<|>
       coerce articlesSearch :<|>
       coerce privateArticleAuthorDelete :<|>
       coerce privateArticleAuthorsAdd :<|>
       coerce privateArticleAuthorsList :<|>
       coerce privateArticleAuthorsReplace :<|>
       coerce privateArticleCategoriesAdd :<|>
       coerce privateArticleCategoriesList :<|>
       coerce privateArticleCategoriesReplace :<|>
       coerce privateArticleCategoryDelete :<|>
       coerce privateArticleConfidentialityDelete :<|>
       coerce privateArticleConfidentialityDetails :<|>
       coerce privateArticleConfidentialityUpdate :<|>
       coerce privateArticleCreate :<|>
       coerce privateArticleDelete :<|>
       coerce privateArticleDetails :<|>
       coerce privateArticleEmbargoDelete :<|>
       coerce privateArticleEmbargoDetails :<|>
       coerce privateArticleEmbargoUpdate :<|>
       coerce privateArticleFile :<|>
       coerce privateArticleFileDelete :<|>
       coerce privateArticleFilesList :<|>
       coerce privateArticlePrivateLink :<|>
       coerce privateArticlePrivateLinkCreate :<|>
       coerce privateArticlePrivateLinkDelete :<|>
       coerce privateArticlePrivateLinkUpdate :<|>
       coerce privateArticlePublish :<|>
       coerce privateArticleReserveDoi :<|>
       coerce privateArticleReserveHandle :<|>
       coerce privateArticleUpdate :<|>
       coerce privateArticleUploadComplete :<|>
       coerce privateArticleUploadInitiate :<|>
       coerce privateArticlesList :<|>
       coerce privateArticlesSearch :<|>
       coerce privateAuthorDetails :<|>
       coerce privateAuthorsSearch :<|>
       coerce collectionArticles :<|>
       coerce collectionDetails :<|>
       coerce collectionVersionDetails :<|>
       coerce collectionVersions :<|>
       coerce collectionsList :<|>
       coerce collectionsSearch :<|>
       coerce privateCollectionArticleDelete :<|>
       coerce privateCollectionArticlesAdd :<|>
       coerce privateCollectionArticlesList :<|>
       coerce privateCollectionArticlesReplace :<|>
       coerce privateCollectionAuthorDelete :<|>
       coerce privateCollectionAuthorsAdd :<|>
       coerce privateCollectionAuthorsList :<|>
       coerce privateCollectionAuthorsReplace :<|>
       coerce privateCollectionCategoriesAdd :<|>
       coerce privateCollectionCategoriesList :<|>
       coerce privateCollectionCategoriesReplace :<|>
       coerce privateCollectionCategoryDelete :<|>
       coerce privateCollectionCreate :<|>
       coerce privateCollectionDelete :<|>
       coerce privateCollectionDetails :<|>
       coerce privateCollectionPrivateLinkCreate :<|>
       coerce privateCollectionPrivateLinkDelete :<|>
       coerce privateCollectionPrivateLinkUpdate :<|>
       coerce privateCollectionPrivateLinksList :<|>
       coerce privateCollectionPublish :<|>
       coerce privateCollectionReserveDoi :<|>
       coerce privateCollectionReserveHandle :<|>
       coerce privateCollectionUpdate :<|>
       coerce privateCollectionsList :<|>
       coerce privateCollectionsSearch :<|>
       coerce accountInstitutionCuration :<|>
       coerce accountInstitutionCurationComments :<|>
       coerce accountInstitutionCurationComments_0 :<|>
       coerce accountInstitutionCurations :<|>
       coerce institutionArticles :<|>
       coerce institutionHrfeedUpload :<|>
       coerce privateAccountInstitutionUser :<|>
       coerce privateCategoriesList :<|>
       coerce privateGroupEmbargoOptionsDetails :<|>
       coerce privateInstitutionAccountGroupRoleDelete :<|>
       coerce privateInstitutionAccountGroupRoles :<|>
       coerce privateInstitutionAccountGroupRolesCreate :<|>
       coerce privateInstitutionAccountsCreate :<|>
       coerce privateInstitutionAccountsList :<|>
       coerce privateInstitutionAccountsSearch :<|>
       coerce privateInstitutionAccountsUpdate :<|>
       coerce privateInstitutionArticles :<|>
       coerce privateInstitutionDetails :<|>
       coerce privateInstitutionEmbargoOptionsDetails :<|>
       coerce privateInstitutionGroupsList :<|>
       coerce privateInstitutionRolesList :<|>
       coerce categoriesList :<|>
       coerce fileDownload :<|>
       coerce licensesList :<|>
       coerce privateAccount :<|>
       coerce privateFundingSearch :<|>
       coerce privateLicensesList :<|>
       coerce privateProjectArticleDelete :<|>
       coerce privateProjectArticleDetails :<|>
       coerce privateProjectArticleFile :<|>
       coerce privateProjectArticleFiles :<|>
       coerce privateProjectArticlesCreate :<|>
       coerce privateProjectArticlesList :<|>
       coerce privateProjectCollaboratorDelete :<|>
       coerce privateProjectCollaboratorsInvite :<|>
       coerce privateProjectCollaboratorsList :<|>
       coerce privateProjectCreate :<|>
       coerce privateProjectDelete :<|>
       coerce privateProjectDetails :<|>
       coerce privateProjectLeave :<|>
       coerce privateProjectNote :<|>
       coerce privateProjectNoteDelete :<|>
       coerce privateProjectNoteUpdate :<|>
       coerce privateProjectNotesCreate :<|>
       coerce privateProjectNotesList :<|>
       coerce privateProjectPublish :<|>
       coerce privateProjectUpdate :<|>
       coerce privateProjectsList :<|>
       coerce privateProjectsSearch :<|>
       coerce projectArticles :<|>
       coerce projectDetails :<|>
       coerce projectsList :<|>
       coerce projectsSearch)
