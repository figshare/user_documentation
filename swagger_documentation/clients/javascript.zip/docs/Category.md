# FigshareApi.Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentId** | **Number** | Parent category | [optional] 
**id** | **Number** | Category id | [optional] 
**title** | **String** | Category title | [optional] 


