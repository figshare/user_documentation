# FigshareApi.Collection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Collection id | 
**title** | **String** | Collection title | 
**doi** | **String** | Collection DOI | 
**handle** | **String** | Collection Handle | 
**url** | **String** | Api endpoint | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 


