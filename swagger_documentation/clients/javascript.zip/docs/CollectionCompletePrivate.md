# FigshareApi.CollectionCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


