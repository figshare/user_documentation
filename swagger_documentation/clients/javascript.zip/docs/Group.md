# FigshareApi.Group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Group id | [optional] 
**name** | **String** | Group name | [optional] 
**resourceId** | **String** | Group resource id | [optional] 
**parentId** | **Number** | Parent group if any | [optional] 
**associatedCode** | **String** | HR code associated with group, if code exists | [optional] 


