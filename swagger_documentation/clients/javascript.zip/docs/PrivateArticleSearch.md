# FigshareApi.PrivateArticleSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


