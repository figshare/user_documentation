# FigshareApi.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | User id | [optional] 
**firstName** | **String** | First Name | [optional] 
**lastName** | **String** | Last Name | [optional] 
**name** | **String** | Full Name | [optional] 
**isActive** | **Boolean** | Account activity status | [optional] 
**urlName** | **String** | Name that appears in website url | [optional] 
**isPublic** | **Boolean** | Account public status | [optional] 
**jobTitle** | **String** | User Job title | [optional] 
**orcidId** | **String** | Orcid associated to this User | [optional] 


