# FigshareApi.AuthorsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**privateAuthorDetails**](AuthorsApi.md#privateAuthorDetails) | **GET** /account/authors/{author_id} | Author details
[**privateAuthorsSearch**](AuthorsApi.md#privateAuthorsSearch) | **POST** /account/authors/search | Search Authors


<a name="privateAuthorDetails"></a>
# **privateAuthorDetails**
> AuthorComplete privateAuthorDetails(authorId)

Author details

View author details

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.AuthorsApi();

var authorId = 789; // Number | Author unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateAuthorDetails(authorId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorId** | **Number**| Author unique identifier | 

### Return type

[**AuthorComplete**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateAuthorsSearch"></a>
# **privateAuthorsSearch**
> [Author] privateAuthorsSearch(opts)

Search Authors

Search for authors

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.AuthorsApi();

var opts = { 
  'search': new FigshareApi.PrivateAuthorsSearch() // PrivateAuthorsSearch | Search Parameters
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateAuthorsSearch(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateAuthorsSearch**](PrivateAuthorsSearch.md)| Search Parameters | [optional] 

### Return type

[**[Author]**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

