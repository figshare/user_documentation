# FigshareApi.Collaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**roleName** | **String** | Collaborator role | [optional] 
**userId** | **Number** | Collaborator id | [optional] 
**name** | **String** | Collaborator name | [optional] 


