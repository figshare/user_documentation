# FigshareApi.ArticleWithProject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


