# FigshareApi.ProjectsSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


