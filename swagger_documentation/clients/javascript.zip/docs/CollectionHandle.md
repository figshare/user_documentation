# FigshareApi.CollectionHandle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handle** | **String** | Reserved Handle | 


