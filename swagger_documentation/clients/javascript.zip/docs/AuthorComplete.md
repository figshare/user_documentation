# FigshareApi.AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


