# FigshareApi.ArticleVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **Number** | Version number | 
**url** | **String** | Api endpoint for the item version | 


