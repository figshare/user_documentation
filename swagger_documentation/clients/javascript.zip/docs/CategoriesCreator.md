# FigshareApi.CategoriesCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **[Number]** | List of category ids | 


