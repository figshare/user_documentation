# FigshareApi.ArticleSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


