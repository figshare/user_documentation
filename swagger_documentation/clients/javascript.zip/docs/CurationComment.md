# FigshareApi.CurationComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | The ID of the comment. | [optional] 
**accountId** | **Number** | The ID of the account which generated this comment. | [optional] 
**type** | **String** | The ID of the account which generated this comment. | [optional] 
**text** | **String** | The value/content of the comment. | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `comment` (value: `"comment"`)

* `approved` (value: `"approved"`)

* `rejected` (value: `"rejected"`)

* `closed` (value: `"closed"`)




