# FigshareApi.CurationComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | The ID of the comment. | 
**accountId** | **Number** | The ID of the account which generated this comment. | 
**type** | **String** | The ID of the account which generated this comment. | 
**text** | **String** | The value/content of the comment. | 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `comment` (value: `"comment"`)

* `approved` (value: `"approved"`)

* `rejected` (value: `"rejected"`)

* `closed` (value: `"closed"`)




