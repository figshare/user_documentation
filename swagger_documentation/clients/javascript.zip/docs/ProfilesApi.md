# FigshareApi.ProfilesApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateUserProfile**](ProfilesApi.md#updateUserProfile) | **PUT** /account/profile/{user_id} | Update public profile
[**updateUserProfilePicture**](ProfilesApi.md#updateUserProfilePicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture


<a name="updateUserProfile"></a>
# **updateUserProfile**
> updateUserProfile(userId, userProfileData)

Update public profile

Updates the fields of the user's public profile.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ProfilesApi();

var userId = 789; // Number | User ID

var userProfileData = new FigshareApi.ProfileUpdateData(); // ProfileUpdateData | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.updateUserProfile(userId, userProfileData, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **Number**| User ID | 
 **userProfileData** | [**ProfileUpdateData**](ProfileUpdateData.md)|  | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateUserProfilePicture"></a>
# **updateUserProfilePicture**
> updateUserProfilePicture(userId, profilePicture)

Update public profile picture

Updates the profile picture of the user's public profile.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.ProfilesApi();

var userId = 789; // Number | User ID

var profilePicture = "/path/to/file.txt"; // File | User profile picture


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.updateUserProfilePicture(userId, profilePicture, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **Number**| User ID | 
 **profilePicture** | **File**| User profile picture | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

