# FigshareApi.Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | ID of resource item | [optional] [default to '']
**title** | **String** | Title of resource item | [optional] [default to '']
**doi** | **String** | DOI of resource item | [optional] [default to '']
**link** | **String** | Link of resource item | [optional] [default to '']
**status** | **String** | Status of resource item | [optional] [default to '']
**version** | **Number** | Version of resource item | [optional] [default to 0]


