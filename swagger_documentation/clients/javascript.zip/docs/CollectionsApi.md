# FigshareApi.CollectionsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**collectionArticles**](CollectionsApi.md#collectionArticles) | **GET** /collections/{collection_id}/articles | Public Collection Articles
[**collectionDetails**](CollectionsApi.md#collectionDetails) | **GET** /collections/{collection_id} | Collection details
[**collectionVersionDetails**](CollectionsApi.md#collectionVersionDetails) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details
[**collectionVersions**](CollectionsApi.md#collectionVersions) | **GET** /collections/{collection_id}/versions | Collection Versions list
[**collectionsList**](CollectionsApi.md#collectionsList) | **GET** /collections | Public Collections
[**collectionsSearch**](CollectionsApi.md#collectionsSearch) | **POST** /collections/search | Public Collections Search
[**privateCollectionArticleDelete**](CollectionsApi.md#privateCollectionArticleDelete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article
[**privateCollectionArticlesAdd**](CollectionsApi.md#privateCollectionArticlesAdd) | **POST** /account/collections/{collection_id}/articles | Add collection articles
[**privateCollectionArticlesList**](CollectionsApi.md#privateCollectionArticlesList) | **GET** /account/collections/{collection_id}/articles | List collection articles
[**privateCollectionArticlesReplace**](CollectionsApi.md#privateCollectionArticlesReplace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles
[**privateCollectionAuthorDelete**](CollectionsApi.md#privateCollectionAuthorDelete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author
[**privateCollectionAuthorsAdd**](CollectionsApi.md#privateCollectionAuthorsAdd) | **POST** /account/collections/{collection_id}/authors | Add collection authors
[**privateCollectionAuthorsList**](CollectionsApi.md#privateCollectionAuthorsList) | **GET** /account/collections/{collection_id}/authors | List collection authors
[**privateCollectionAuthorsReplace**](CollectionsApi.md#privateCollectionAuthorsReplace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors
[**privateCollectionCategoriesAdd**](CollectionsApi.md#privateCollectionCategoriesAdd) | **POST** /account/collections/{collection_id}/categories | Add collection categories
[**privateCollectionCategoriesList**](CollectionsApi.md#privateCollectionCategoriesList) | **GET** /account/collections/{collection_id}/categories | List collection categories
[**privateCollectionCategoriesReplace**](CollectionsApi.md#privateCollectionCategoriesReplace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories
[**privateCollectionCategoryDelete**](CollectionsApi.md#privateCollectionCategoryDelete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category
[**privateCollectionCreate**](CollectionsApi.md#privateCollectionCreate) | **POST** /account/collections | Create collection
[**privateCollectionDelete**](CollectionsApi.md#privateCollectionDelete) | **DELETE** /account/collections/{collection_id} | Delete collection
[**privateCollectionDetails**](CollectionsApi.md#privateCollectionDetails) | **GET** /account/collections/{collection_id} | Collection details
[**privateCollectionPrivateLinkCreate**](CollectionsApi.md#privateCollectionPrivateLinkCreate) | **POST** /account/collections/{collection_id}/private_links | Create collection private link
[**privateCollectionPrivateLinkDelete**](CollectionsApi.md#privateCollectionPrivateLinkDelete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link
[**privateCollectionPrivateLinkUpdate**](CollectionsApi.md#privateCollectionPrivateLinkUpdate) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link
[**privateCollectionPrivateLinksList**](CollectionsApi.md#privateCollectionPrivateLinksList) | **GET** /account/collections/{collection_id}/private_links | List collection private links
[**privateCollectionPublish**](CollectionsApi.md#privateCollectionPublish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish
[**privateCollectionReserveDoi**](CollectionsApi.md#privateCollectionReserveDoi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI
[**privateCollectionUpdate**](CollectionsApi.md#privateCollectionUpdate) | **PUT** /account/collections/{collection_id} | Update collection
[**privateCollectionsList**](CollectionsApi.md#privateCollectionsList) | **GET** /account/collections | Private Collections List
[**privateCollectionsSearch**](CollectionsApi.md#privateCollectionsSearch) | **POST** /account/collections/search | Private Collections Search


<a name="collectionArticles"></a>
# **collectionArticles**
> [Article] collectionArticles(collectionId, opts)

Public Collection Articles

Returns a list of public collection articles

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection Unique identifier

var opts = { 
  'page': 789, // Number | Page number. Used for pagination with page_size
  'pageSize': 10, // Number | The number of results included on a page. Used for pagination with page
  'limit': 789, // Number | Number of results included on a page. Used for pagination with query
  'offset': 789 // Number | Where to start the listing(the offset of the first result). Used for pagination with limit
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.collectionArticles(collectionId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection Unique identifier | 
 **page** | **Number**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Number**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Number**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Number**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="collectionDetails"></a>
# **collectionDetails**
> CollectionComplete collectionDetails(collectionId)

Collection details

View a collection

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection Unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.collectionDetails(collectionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection Unique identifier | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="collectionVersionDetails"></a>
# **collectionVersionDetails**
> CollectionComplete collectionVersionDetails(collectionId, versionId)

Collection Version details

View details for a certain version of a collection

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection Unique identifier

var versionId = 789; // Number | Version Number


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.collectionVersionDetails(collectionId, versionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection Unique identifier | 
 **versionId** | **Number**| Version Number | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="collectionVersions"></a>
# **collectionVersions**
> [Version] collectionVersions(collectionId)

Collection Versions list

Returns a list of public collection Versions

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection Unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.collectionVersions(collectionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection Unique identifier | 

### Return type

[**[Version]**](Version.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="collectionsList"></a>
# **collectionsList**
> [Collection] collectionsList(opts)

Public Collections

Returns a list of public collections

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.CollectionsApi();

var opts = { 
  'page': 789, // Number | Page number. Used for pagination with page_size
  'pageSize': 10, // Number | The number of results included on a page. Used for pagination with page
  'limit': 789, // Number | Number of results included on a page. Used for pagination with query
  'offset': 789, // Number | Where to start the listing(the offset of the first result). Used for pagination with limit
  'order': "published_date", // String | The field by which to order. Default varies by endpoint/resource.
  'orderDirection': "desc", // String | 
  'institution': 789, // Number | only return collections from this institution
  'publishedSince': "publishedSince_example", // String | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
  'modifiedSince': "modifiedSince_example", // String | Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
  'group': 789, // Number | only return collections from this group
  'resourceDoi': "resourceDoi_example", // String | only return collections with this resource_doi
  'doi': "doi_example" // String | only return collections with this doi
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.collectionsList(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Number**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Number**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Number**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Number**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **String**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **orderDirection** | **String**|  | [optional] [default to desc]
 **institution** | **Number**| only return collections from this institution | [optional] 
 **publishedSince** | **String**| Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **modifiedSince** | **String**| Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **group** | **Number**| only return collections from this group | [optional] 
 **resourceDoi** | **String**| only return collections with this resource_doi | [optional] 
 **doi** | **String**| only return collections with this doi | [optional] 

### Return type

[**[Collection]**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="collectionsSearch"></a>
# **collectionsSearch**
> [Collection] collectionsSearch(opts)

Public Collections Search

Returns a list of public collections

### Example
```javascript
var FigshareApi = require('figshare_api');

var apiInstance = new FigshareApi.CollectionsApi();

var opts = { 
  'search': new FigshareApi.CollectionSearch() // CollectionSearch | Search Parameters
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.collectionsSearch(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**CollectionSearch**](CollectionSearch.md)| Search Parameters | [optional] 

### Return type

[**[Collection]**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionArticleDelete"></a>
# **privateCollectionArticleDelete**
> privateCollectionArticleDelete(collectionId, articleId)

Delete collection article

De-associate article from collection

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var articleId = 789; // Number | Collection article unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionArticleDelete(collectionId, articleId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **articleId** | **Number**| Collection article unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionArticlesAdd"></a>
# **privateCollectionArticlesAdd**
> Location privateCollectionArticlesAdd(collectionId, articles)

Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var articles = new FigshareApi.ArticlesCreator(); // ArticlesCreator | Articles list


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionArticlesAdd(collectionId, articles, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **articles** | [**ArticlesCreator**](ArticlesCreator.md)| Articles list | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionArticlesList"></a>
# **privateCollectionArticlesList**
> [Article] privateCollectionArticlesList(collectionId, )

List collection articles

List collection articles

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionArticlesList(collectionId, , callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 

### Return type

[**[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionArticlesReplace"></a>
# **privateCollectionArticlesReplace**
> privateCollectionArticlesReplace(collectionId, articles)

Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var articles = new FigshareApi.ArticlesCreator(); // ArticlesCreator | Articles List


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionArticlesReplace(collectionId, articles, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **articles** | [**ArticlesCreator**](ArticlesCreator.md)| Articles List | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionAuthorDelete"></a>
# **privateCollectionAuthorDelete**
> privateCollectionAuthorDelete(collectionId, authorId)

Delete collection author

Delete collection author

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var authorId = 789; // Number | Collection Author unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionAuthorDelete(collectionId, authorId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **authorId** | **Number**| Collection Author unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionAuthorsAdd"></a>
# **privateCollectionAuthorsAdd**
> Location privateCollectionAuthorsAdd(collectionId, authors)

Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var authors = new FigshareApi.AuthorsCreator(); // AuthorsCreator | List of authors


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionAuthorsAdd(collectionId, authors, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| List of authors | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionAuthorsList"></a>
# **privateCollectionAuthorsList**
> [Author] privateCollectionAuthorsList(collectionId, )

List collection authors

List collection authors

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionAuthorsList(collectionId, , callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 

### Return type

[**[Author]**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionAuthorsReplace"></a>
# **privateCollectionAuthorsReplace**
> privateCollectionAuthorsReplace(collectionId, authors)

Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var authors = new FigshareApi.AuthorsCreator(); // AuthorsCreator | List of authors


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionAuthorsReplace(collectionId, authors, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| List of authors | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionCategoriesAdd"></a>
# **privateCollectionCategoriesAdd**
> Location privateCollectionCategoriesAdd(collectionId, categories)

Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var categories = new FigshareApi.CategoriesCreator(); // CategoriesCreator | Categories list


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionCategoriesAdd(collectionId, categories, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)| Categories list | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionCategoriesList"></a>
# **privateCollectionCategoriesList**
> [Category] privateCollectionCategoriesList(collectionId, )

List collection categories

List collection categories

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionCategoriesList(collectionId, , callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 

### Return type

[**[Category]**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionCategoriesReplace"></a>
# **privateCollectionCategoriesReplace**
> privateCollectionCategoriesReplace(collectionId, categories)

Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var categories = new FigshareApi.CategoriesCreator(); // CategoriesCreator | Categories list


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionCategoriesReplace(collectionId, categories, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)| Categories list | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionCategoryDelete"></a>
# **privateCollectionCategoryDelete**
> privateCollectionCategoryDelete(collectionId, categoryId)

Delete collection category

De-associate category from collection

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var categoryId = 789; // Number | Collection category unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionCategoryDelete(collectionId, categoryId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **categoryId** | **Number**| Collection category unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionCreate"></a>
# **privateCollectionCreate**
> CollectionComplete privateCollectionCreate(collection)

Create collection

Create a new Collection by sending collection information

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collection = new FigshareApi.CollectionCreate(); // CollectionCreate | Collection description


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionCreate(collection, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection** | [**CollectionCreate**](CollectionCreate.md)| Collection description | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionDelete"></a>
# **privateCollectionDelete**
> privateCollectionDelete(collectionId)

Delete collection

Delete n collection

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection Unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionDelete(collectionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection Unique identifier | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionDetails"></a>
# **privateCollectionDetails**
> CollectionComplete privateCollectionDetails(collectionId)

Collection details

View a collection

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection Unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionDetails(collectionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection Unique identifier | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionPrivateLinkCreate"></a>
# **privateCollectionPrivateLinkCreate**
> Location privateCollectionPrivateLinkCreate(collectionId, opts)

Create collection private link

Create new private link

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var opts = { 
  'privateLink': new FigshareApi.CollectionPrivateLinkCreator() // CollectionPrivateLinkCreator | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionPrivateLinkCreate(collectionId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **privateLink** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)|  | [optional] 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionPrivateLinkDelete"></a>
# **privateCollectionPrivateLinkDelete**
> privateCollectionPrivateLinkDelete(collectionId, linkId)

Disable private link

Disable/delete private link for this collection

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var linkId = "linkId_example"; // String | Private link token


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionPrivateLinkDelete(collectionId, linkId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **linkId** | **String**| Private link token | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionPrivateLinkUpdate"></a>
# **privateCollectionPrivateLinkUpdate**
> privateCollectionPrivateLinkUpdate(collectionId, linkId, opts)

Update collection private link

Update existing private link for this collection

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier

var linkId = "linkId_example"; // String | Private link token

var opts = { 
  'privateLink': new FigshareApi.CollectionPrivateLinkCreator() // CollectionPrivateLinkCreator | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionPrivateLinkUpdate(collectionId, linkId, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 
 **linkId** | **String**| Private link token | 
 **privateLink** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)|  | [optional] 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionPrivateLinksList"></a>
# **privateCollectionPrivateLinksList**
> [PrivateLink] privateCollectionPrivateLinksList(collectionId)

List collection private links

List article private links

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionPrivateLinksList(collectionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection unique identifier | 

### Return type

[**[PrivateLink]**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionPublish"></a>
# **privateCollectionPublish**
> Location privateCollectionPublish(collectionId)

Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection Unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionPublish(collectionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection Unique identifier | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionReserveDoi"></a>
# **privateCollectionReserveDoi**
> ArticleDOI privateCollectionReserveDoi(collectionId)

Private Collection Reserve DOI

Reserve DOI for collection

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection Unique identifier


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionReserveDoi(collectionId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection Unique identifier | 

### Return type

[**ArticleDOI**](ArticleDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionUpdate"></a>
# **privateCollectionUpdate**
> privateCollectionUpdate(collectionIdcollection)

Update collection

Update collection details

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var collectionId = 789; // Number | Collection Unique identifier

var collection = new FigshareApi.CollectionUpdate(); // CollectionUpdate | Collection description


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.privateCollectionUpdate(collectionIdcollection, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Number**| Collection Unique identifier | 
 **collection** | [**CollectionUpdate**](CollectionUpdate.md)| Collection description | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionsList"></a>
# **privateCollectionsList**
> [Collection] privateCollectionsList(opts)

Private Collections List

List private collections

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var opts = { 
  'page': 789, // Number | Page number. Used for pagination with page_size
  'pageSize': 10, // Number | The number of results included on a page. Used for pagination with page
  'limit': 789, // Number | Number of results included on a page. Used for pagination with query
  'offset': 789, // Number | Where to start the listing(the offset of the first result). Used for pagination with limit
  'order': "published_date", // String | The field by which to order. Default varies by endpoint/resource.
  'orderDirection': "desc" // String | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionsList(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Number**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Number**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Number**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Number**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **String**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **orderDirection** | **String**|  | [optional] [default to desc]

### Return type

[**[Collection]**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="privateCollectionsSearch"></a>
# **privateCollectionsSearch**
> [Collection] privateCollectionsSearch(search)

Private Collections Search

Returns a list of private Collections

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.default;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.CollectionsApi();

var search = new FigshareApi.PrivateCollectionSearch(); // PrivateCollectionSearch | Search Parameters


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.privateCollectionsSearch(search, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateCollectionSearch**](PrivateCollectionSearch.md)| Search Parameters | 

### Return type

[**[Collection]**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

