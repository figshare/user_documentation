# FigshareApi.Project

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Api endpoint | [optional] 
**id** | **Number** | Project id | [optional] 
**title** | **String** | Project title | [optional] 


