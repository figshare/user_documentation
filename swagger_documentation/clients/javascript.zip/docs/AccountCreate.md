# FigshareApi.AccountCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** | Email of account | 
**firstName** | **String** | First Name | [default to '']
**lastName** | **String** | Last Name | [optional] [default to '']
**groupId** | **Number** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 
**institutionUserId** | **String** | Institution user id | [optional] [default to '']
**symplecticUserId** | **String** | Symplectic user id | [optional] [default to '']
**quota** | **Number** | Account quota | [optional] 
**isActive** | **Boolean** | Is account active | [optional] 


