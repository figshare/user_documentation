# FigshareApi.Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Account id | [optional] 
**firstName** | **String** | First Name | [optional] 
**lastName** | **String** | Last Name | [optional] 
**usedQuotaPrivate** | **Number** | Account used private quota | [optional] 
**modifiedDate** | **String** | Date of last account modification | [optional] 
**usedQuota** | **Number** | Account total used quota | [optional] 
**createdDate** | **String** | Date when account was created | [optional] 
**quota** | **Number** | Account quota | [optional] 
**institutionUserId** | **String** | Account institution user id | [optional] 
**institutionId** | **Number** | Account institution | [optional] 
**email** | **String** | User email | [optional] 
**usedQuotaPublic** | **Number** | Account public used quota | [optional] 
**pendingQuotaRequest** | **Boolean** | True if a quota request is pending | [optional] 
**active** | **Number** | Account activity status | [optional] 
**maximumFileSize** | **Number** | Maximum upload size for account | [optional] 


