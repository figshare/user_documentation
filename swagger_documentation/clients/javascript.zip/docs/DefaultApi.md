# FigshareApi.DefaultApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**accountArticleReport**](DefaultApi.md#accountArticleReport) | **GET** /account/articles/export | Account Article Report
[**accountArticleReportGenerate**](DefaultApi.md#accountArticleReportGenerate) | **POST** /account/articles/export | Initiate a new Report


<a name="accountArticleReport"></a>
# **accountArticleReport**
> [AccountReport] accountArticleReport(opts)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.DefaultApi();

var opts = { 
  'groupId': 789 // Number | A group ID to filter by
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.accountArticleReport(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **Number**| A group ID to filter by | [optional] 

### Return type

[**[AccountReport]**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="accountArticleReportGenerate"></a>
# **accountArticleReportGenerate**
> AccountReport accountArticleReportGenerate()

Initiate a new Report

Initiate a new Article Report for this Account

### Example
```javascript
var FigshareApi = require('figshare_api');
var defaultClient = FigshareApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new FigshareApi.DefaultApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.accountArticleReportGenerate(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

