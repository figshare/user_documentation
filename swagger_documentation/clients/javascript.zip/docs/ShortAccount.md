# FigshareApi.ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Account id | [optional] 
**firstName** | **String** | First Name | [optional] 
**lastName** | **String** | Last Name | [optional] 
**institutionId** | **Number** | Account institution | [optional] 
**email** | **String** | User email | [optional] 
**active** | **Number** | Account activity status | [optional] 
**institutionUserId** | **String** | Account institution user id | [optional] 


