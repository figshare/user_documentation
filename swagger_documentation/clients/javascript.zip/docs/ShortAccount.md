# FigshareApi.ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Account id | [optional] 
**firstName** | **String** | First Name | [optional] 
**lastName** | **String** | Last Name | [optional] 
**institutionId** | **Number** | Account institution | [optional] 
**email** | **String** | User email | [optional] 
**active** | **Number** | Account activity status | [optional] 
**institutionUserId** | **String** | Account institution user id | [optional] 
**quota** | **Number** | Total storage available to account, in bytes | [optional] 
**usedQuota** | **Number** | Storage used by the account, in bytes | [optional] 
**userId** | **Number** | User id associated with account, useful for example for adding the account as an author to an item | [optional] 
**orcidId** | **String** | ORCID iD associated to account | [optional] 


