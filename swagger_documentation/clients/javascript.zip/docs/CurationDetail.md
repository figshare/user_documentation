# FigshareApi.CurationDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item** | [**ArticleComplete**](ArticleComplete.md) | Article details | 


