# FigshareApi.CurationDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


