# FigshareApi.PrivateFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


