# FigshareApi.ProjectCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


