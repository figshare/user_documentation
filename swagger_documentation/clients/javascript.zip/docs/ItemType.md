# FigshareApi.ItemType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | The ID of the item type. | [optional] 
**name** | **String** | The name of the item type | [optional] 
**stringId** | **String** | The string identifier of the item type. | [optional] 
**icon** | **String** | The string identifying the icon of the item type. | [optional] 
**publicDescription** | **String** | The description of the item type. | [optional] 
**isSelectable** | **Boolean** | The selectable status | [optional] 
**urlName** | **String** | The URL name of the item type. | [optional] 


