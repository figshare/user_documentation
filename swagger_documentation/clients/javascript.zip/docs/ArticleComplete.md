# FigshareApi.ArticleComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**figshareUrl** | **String** | Article public url | 
**downloadDisabled** | **Boolean** | If true, downloading of files for this article is disabled | 
**files** | [**[PublicFile]**](PublicFile.md) | List of article files | 
**authors** | [**[Author]**](Author.md) | List of article authors | 
**customFields** | [**[CustomArticleField]**](CustomArticleField.md) | List of custom fields values | 
**embargoOptions** | [**[GroupEmbargoOptions]**](GroupEmbargoOptions.md) | List of embargo options | 


