# FigshareApi.ArticleComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


