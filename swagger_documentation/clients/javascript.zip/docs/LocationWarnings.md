# FigshareApi.LocationWarnings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** | Url for entity | [optional] 
**warnings** | **[String]** | Issues encountered during the operation | [optional] 


