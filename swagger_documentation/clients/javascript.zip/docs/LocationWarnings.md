# FigshareApi.LocationWarnings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entityId** | **Number** | Figshare ID of the entity | [optional] 
**location** | **String** | Url for entity | [optional] 
**warnings** | **[String]** | Issues encountered during the operation | [optional] 


