# FigshareApi.ArticleConfidentiality

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isConfidential** | **Boolean** | True if article is confidential | [optional] 
**reason** | **String** | Reason for confidentiality | [optional] 


