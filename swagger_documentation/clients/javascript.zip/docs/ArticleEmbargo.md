# FigshareApi.ArticleEmbargo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isEmbargoed** | **Boolean** | True if embargoed | [optional] 
**embargoReason** | **String** | Reason for embargo | [optional] 


