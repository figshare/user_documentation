# FigshareApi.CurationWithComments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


