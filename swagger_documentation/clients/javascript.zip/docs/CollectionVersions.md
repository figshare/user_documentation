# FigshareApi.CollectionVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Version number | 
**url** | **String** | Api endpoint for the collection version | 


