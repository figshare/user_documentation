# FigshareApi.RelatedMaterial

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | The ID of the related material; can be used to add existing materials of the same account to items. | [optional] 
**identifier** | **String** | The related material identifier (e.g., DOI, Handle, ISBN) | [optional] 
**title** | **String** | The related material title | [optional] 
**relation** | **String** | The relation between the item and the related material; defaults to 'References' | [optional] [default to 'References']
**identifierType** | **String** | The type of the identifier of the related material; defaults to 'URL' | [optional] [default to 'URL']
**isLinkout** | **Boolean** | Flag for highlighting this related material in the call-out box | [optional] 
**link** | **String** | The full hyperlink for the identifier | [optional] 


<a name="RelationEnum"></a>
## Enum: RelationEnum


* `isCitedBy` (value: `"IsCitedBy"`)

* `cites` (value: `"Cites"`)

* `isSupplementTo` (value: `"IsSupplementTo"`)

* `isSupplementedBy` (value: `"IsSupplementedBy"`)

* `isContinuedBy` (value: `"IsContinuedBy"`)

* `continues` (value: `"Continues"`)

* `describes` (value: `"Describes"`)

* `isDescribedBy` (value: `"IsDescribedBy"`)

* `hasMetadata` (value: `"HasMetadata"`)

* `isMetadataFor` (value: `"IsMetadataFor"`)

* `hasVersion` (value: `"HasVersion"`)

* `isVersionOf` (value: `"IsVersionOf"`)

* `isNewVersionOf` (value: `"IsNewVersionOf"`)

* `isPreviousVersionOf` (value: `"IsPreviousVersionOf"`)

* `isPartOf` (value: `"IsPartOf"`)

* `hasPart` (value: `"HasPart"`)

* `isPublishedIn` (value: `"IsPublishedIn"`)

* `isReferencedBy` (value: `"IsReferencedBy"`)

* `references` (value: `"References"`)

* `isDocumentedBy` (value: `"IsDocumentedBy"`)

* `documents` (value: `"Documents"`)

* `isCompiledBy` (value: `"IsCompiledBy"`)

* `compiles` (value: `"Compiles"`)

* `isVariantFormOf` (value: `"IsVariantFormOf"`)

* `isOriginalFormOf` (value: `"IsOriginalFormOf"`)

* `isIdenticalTo` (value: `"IsIdenticalTo"`)

* `isReviewedBy` (value: `"IsReviewedBy"`)

* `reviews` (value: `"Reviews"`)

* `isDerivedFrom` (value: `"IsDerivedFrom"`)

* `isSourceOf` (value: `"IsSourceOf"`)

* `isRequiredBy` (value: `"IsRequiredBy"`)

* `requires` (value: `"Requires"`)

* `isObsoletedBy` (value: `"IsObsoletedBy"`)

* `obsoletes` (value: `"Obsoletes"`)




<a name="IdentifierTypeEnum"></a>
## Enum: IdentifierTypeEnum


* `ARK` (value: `"ARK"`)

* `arXiv` (value: `"arXiv"`)

* `bibcode` (value: `"bibcode"`)

* `DOI` (value: `"DOI"`)

* `eAN13` (value: `"EAN13"`)

* `EISSN` (value: `"EISSN"`)

* `handle` (value: `"Handle"`)

* `IGSN` (value: `"IGSN"`)

* `ISBN` (value: `"ISBN"`)

* `ISSN` (value: `"ISSN"`)

* `ISTC` (value: `"ISTC"`)

* `LISSN` (value: `"LISSN"`)

* `LSID` (value: `"LSID"`)

* `PMID` (value: `"PMID"`)

* `PURL` (value: `"PURL"`)

* `UPC` (value: `"UPC"`)

* `URL` (value: `"URL"`)

* `URN` (value: `"URN"`)

* `w3id` (value: `"w3id"`)




