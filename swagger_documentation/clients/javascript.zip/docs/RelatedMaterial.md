# FigshareApi.RelatedMaterial

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | The ID of the related material; can be used to add existing materials of the same account to items. | [optional] 
**identifier** | **String** | The related material identifier (e.g., DOI, Handle, ISBN) | [optional] 
**title** | **String** | The related material title | [optional] 
**relation** | **String** | The relation between the item and the related material; defaults to &#39;References&#39; | [optional] [default to &#39;References&#39;]
**identifierType** | **String** | The type of the identifier of the related material; defaults to &#39;URL&#39; | [optional] [default to &#39;URL&#39;]
**isLinkout** | **Boolean** | Flag for highlighting this related material in the call-out box | [optional] 
**link** | **String** | The full hyperlink for the identifier | [optional] 


<a name="RelationEnum"></a>
## Enum: RelationEnum


* `IsCitedBy` (value: `"IsCitedBy"`)

* `Cites` (value: `"Cites"`)

* `IsSupplementTo` (value: `"IsSupplementTo"`)

* `IsSupplementedBy` (value: `"IsSupplementedBy"`)

* `IsContinuedBy` (value: `"IsContinuedBy"`)

* `Continues` (value: `"Continues"`)

* `Describes` (value: `"Describes"`)

* `IsDescribedBy` (value: `"IsDescribedBy"`)

* `HasMetadata` (value: `"HasMetadata"`)

* `IsMetadataFor` (value: `"IsMetadataFor"`)

* `HasVersion` (value: `"HasVersion"`)

* `IsVersionOf` (value: `"IsVersionOf"`)

* `IsNewVersionOf` (value: `"IsNewVersionOf"`)

* `IsPreviousVersionOf` (value: `"IsPreviousVersionOf"`)

* `IsPartOf` (value: `"IsPartOf"`)

* `HasPart` (value: `"HasPart"`)

* `IsPublishedIn` (value: `"IsPublishedIn"`)

* `IsReferencedBy` (value: `"IsReferencedBy"`)

* `References` (value: `"References"`)

* `IsDocumentedBy` (value: `"IsDocumentedBy"`)

* `Documents` (value: `"Documents"`)

* `IsCompiledBy` (value: `"IsCompiledBy"`)

* `Compiles` (value: `"Compiles"`)

* `IsVariantFormOf` (value: `"IsVariantFormOf"`)

* `IsOriginalFormOf` (value: `"IsOriginalFormOf"`)

* `IsIdenticalTo` (value: `"IsIdenticalTo"`)

* `IsReviewedBy` (value: `"IsReviewedBy"`)

* `Reviews` (value: `"Reviews"`)

* `IsDerivedFrom` (value: `"IsDerivedFrom"`)

* `IsSourceOf` (value: `"IsSourceOf"`)

* `IsRequiredBy` (value: `"IsRequiredBy"`)

* `Requires` (value: `"Requires"`)

* `IsObsoletedBy` (value: `"IsObsoletedBy"`)

* `Obsoletes` (value: `"Obsoletes"`)




<a name="IdentifierTypeEnum"></a>
## Enum: IdentifierTypeEnum


* `ARK` (value: `"ARK"`)

* `arXiv` (value: `"arXiv"`)

* `bibcode` (value: `"bibcode"`)

* `DOI` (value: `"DOI"`)

* `EAN13` (value: `"EAN13"`)

* `EISSN` (value: `"EISSN"`)

* `Handle` (value: `"Handle"`)

* `IGSN` (value: `"IGSN"`)

* `ISBN` (value: `"ISBN"`)

* `ISSN` (value: `"ISSN"`)

* `ISTC` (value: `"ISTC"`)

* `LISSN` (value: `"LISSN"`)

* `LSID` (value: `"LSID"`)

* `PMID` (value: `"PMID"`)

* `PURL` (value: `"PURL"`)

* `UPC` (value: `"UPC"`)

* `URL` (value: `"URL"`)

* `URN` (value: `"URN"`)

* `w3id` (value: `"w3id"`)




