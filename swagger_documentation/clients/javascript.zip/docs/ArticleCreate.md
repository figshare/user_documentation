# FigshareApi.ArticleCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** | Title of article | 
**description** | **String** | The article description. In a publisher case, usually this is the remote article description | [optional] [default to &#39;&#39;]
**tags** | **[String]** | List of tags to be associated with the article. Keywords can be used instead | [optional] 
**keywords** | **[String]** | List of tags to be associated with the article. Tags can be used instead | [optional] 
**references** | **[String]** | List of links to be associated with the article (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) | [optional] 
**categories** | **[Number]** | List of category ids to be associated with the article(e.g [1, 23, 33, 66]) | [optional] 
**authors** | **[Object]** | List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. No more than 10 authors. For adding more authors use the specific authors endpoint. | [optional] 
**customFields** | **Object** | List of key, values pairs to be associated with the article | [optional] 
**definedType** | **String** | Article type. In responses this will be an integer which is mapped to item types as: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code, 11 - Metadata, 12 - Preprint | [optional] 
**funding** | **String** | Grant number or funding authority | [optional] [default to &#39;&#39;]
**license** | **Number** | License id for this article. | [optional] [default to 0]
**doi** | **String** | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional] [default to &#39;&#39;]
**resourceDoi** | **String** | Not applicable to regular users. In a publisher case, this is the publisher article DOI. For linkback this needs to be used in combination with resource_title. | [optional] [default to &#39;&#39;]
**resourceTitle** | **String** | Not applicable to regular users. In a publisher case, this is the publisher article title. For linkback this needs to be used in combination with resource_doi. | [optional] [default to &#39;&#39;]
**groupId** | **Number** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 


<a name="DefinedTypeEnum"></a>
## Enum: DefinedTypeEnum


* `figure` (value: `"figure"`)

* `media` (value: `"media"`)

* `dataset` (value: `"dataset"`)

* `fileset` (value: `"fileset"`)

* `poster` (value: `"poster"`)

* `paper` (value: `"paper"`)

* `presentation` (value: `"presentation"`)

* `thesis` (value: `"thesis"`)

* `code` (value: `"code"`)

* `metadata` (value: `"metadata"`)

* `preprint` (value: `"preprint"`)




