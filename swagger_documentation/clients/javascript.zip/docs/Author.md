# FigshareApi.Author

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Author id | [optional] 
**fullName** | **String** | Author full name | [optional] 
**isActive** | **Boolean** | True if author has published items | [optional] 
**urlName** | **String** | Author url name | [optional] 
**orcidId** | **String** | Author Orcid | [optional] 


