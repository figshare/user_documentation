# FigshareApi.Author

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Author id | 
**fullName** | **String** | Author full name | 
**firstName** | **String** | Author first name | 
**lastName** | **String** | Author last name | 
**isActive** | **Boolean** | True if author has published items | 
**urlName** | **String** | Author url name | 
**orcidId** | **String** | Author Orcid | 


