# FigshareApi.ProjectPrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


