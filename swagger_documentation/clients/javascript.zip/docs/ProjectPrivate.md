# FigshareApi.ProjectPrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **String** | Role inside this project | 
**storage** | **String** | Project storage type | 


<a name="RoleEnum"></a>
## Enum: RoleEnum


* `owner` (value: `"Owner"`)

* `collaborator` (value: `"Collaborator"`)

* `viewer` (value: `"Viewer"`)




<a name="StorageEnum"></a>
## Enum: StorageEnum


* `individual` (value: `"individual"`)

* `group` (value: `"group"`)




