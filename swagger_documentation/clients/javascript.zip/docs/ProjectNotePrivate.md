# FigshareApi.ProjectNotePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


