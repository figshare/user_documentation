# FigshareApi.CollectionSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


