# FigshareApi.ArticleCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountId** | **Number** | ID of the account owning the article | 


