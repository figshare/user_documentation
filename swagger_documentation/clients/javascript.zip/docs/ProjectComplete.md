# FigshareApi.ProjectComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


