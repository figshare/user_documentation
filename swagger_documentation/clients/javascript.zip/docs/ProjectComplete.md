# FigshareApi.ProjectComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **String** | Project funding | 
**fundingList** | [**[FundingInformation]**](FundingInformation.md) | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [**[Collaborator]**](Collaborator.md) | List of project collaborators | 


