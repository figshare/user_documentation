# FigshareApi.Role

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Role id | 
**name** | **String** | Role name | 
**category** | **String** | Role category | 
**description** | **String** | Role description | 


