# FigshareApi.Curation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | The review id | [optional] 
**groupId** | **Number** | The group in which the article is present. | [optional] 
**accountId** | **Number** | The ID of the account of the owner of the article of this review. | [optional] 
**assignedTo** | **Number** | The ID of the account to which this review is assigned. | [optional] 
**articleId** | **Number** | The ID of the article of this review. | [optional] 
**version** | **Number** | The Version number of the article in review. | [optional] 
**commentsCount** | **Number** | The number of comments in the review. | [optional] 
**status** | **String** | The status of the review. | [optional] 
**createdDate** | **String** | The creation date of the review. | [optional] 
**modifiedDate** | **String** | The date the review has been modified. | [optional] 


<a name="StatusEnum"></a>
## Enum: StatusEnum


* `pending` (value: `"pending"`)

* `approved` (value: `"approved"`)

* `rejected` (value: `"rejected"`)

* `closed` (value: `"closed"`)




