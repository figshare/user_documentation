# FigshareApi.PublicFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | File id | [optional] 
**name** | **String** | File name | [optional] 
**size** | **Number** | File size | [optional] 
**isLinkOnly** | **Boolean** | True if file is hosted somewhere else | [optional] 
**downloadUrl** | **String** | Url for file download | [optional] 
**suppliedMd5** | **String** | File supplied md5 | [optional] 
**computedMd5** | **String** | File computed md5 | [optional] 


