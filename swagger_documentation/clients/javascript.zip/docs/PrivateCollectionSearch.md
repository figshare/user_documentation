# FigshareApi.PrivateCollectionSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


