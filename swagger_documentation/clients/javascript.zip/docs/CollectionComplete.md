# FigshareApi.CollectionComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


