# FigshareApi.GroupEmbargoOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Embargo option id | [optional] 
**type** | **String** | Embargo permission type | [optional] 
**ipName** | **String** | IP range name; value appears if type is ip_range | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `logged_in` (value: `"logged_in"`)

* `ip_range` (value: `"ip_range"`)

* `administrator` (value: `"administrator"`)




