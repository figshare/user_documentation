# IO.Swagger.Model.ArticleCompletePrivate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Unique identifier for article | [optional] 
**Title** | **string** | Title of article | [optional] 
**Doi** | **string** | DOI | [optional] 
**Handle** | **string** | Handle | [optional] 
**Url** | **string** | Api endpoint for article | [optional] 
**UrlPublicHtml** | **string** | Public site endpoint for article | [optional] 
**UrlPublicApi** | **string** | Public Api endpoint for article | [optional] 
**UrlPrivateHtml** | **string** | Private site endpoint for article | [optional] 
**UrlPrivateApi** | **string** | Private Api endpoint for article | [optional] 
**Timeline** | [**Timeline**](Timeline.md) | Various timeline dates | [optional] 
**Thumb** | **string** | Thumbnail image | [optional] 
**DefinedType** | **long?** | Type of article identifier | [optional] 
**DefinedTypeName** | **string** | Name of the article type identifier | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

