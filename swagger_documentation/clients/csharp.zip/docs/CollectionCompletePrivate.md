# IO.Swagger.Model.CollectionCompletePrivate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Collection id | [optional] 
**Title** | **string** | Collection title | [optional] 
**Doi** | **string** | Collection DOI | [optional] 
**Handle** | **string** | Collection Handle | [optional] 
**Url** | **string** | Api endpoint | [optional] 
**Timeline** | [**Timeline**](Timeline.md) | Various timeline dates | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

