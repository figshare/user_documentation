# IO.Swagger.Model.Role
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Role id | [optional] 
**Name** | **string** | Role name | [optional] 
**Category** | **string** | Role category | [optional] 
**Description** | **string** | Role description | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

