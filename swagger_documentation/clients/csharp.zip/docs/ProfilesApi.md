# IO.Swagger.Api.ProfilesApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**UpdateUserProfile**](ProfilesApi.md#updateuserprofile) | **PUT** /account/profile/{user_id} | Update public profile
[**UpdateUserProfilePicture**](ProfilesApi.md#updateuserprofilepicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture


<a name="updateuserprofile"></a>
# **UpdateUserProfile**
> Object UpdateUserProfile (long? userId, ProfileUpdateData userProfileData)

Update public profile

Updates the fields of the user's public profile.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateUserProfileExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProfilesApi();
            var userId = 789;  // long? | User ID
            var userProfileData = new ProfileUpdateData(); // ProfileUpdateData | 

            try
            {
                // Update public profile
                Object result = apiInstance.UpdateUserProfile(userId, userProfileData);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProfilesApi.UpdateUserProfile: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **long?**| User ID | 
 **userProfileData** | [**ProfileUpdateData**](ProfileUpdateData.md)|  | 

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="updateuserprofilepicture"></a>
# **UpdateUserProfilePicture**
> Object UpdateUserProfilePicture (long? userId, System.IO.Stream profilePicture)

Update public profile picture

Updates the profile picture of the user's public profile.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateUserProfilePictureExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProfilesApi();
            var userId = 789;  // long? | User ID
            var profilePicture = new System.IO.Stream(); // System.IO.Stream | User profile picture

            try
            {
                // Update public profile picture
                Object result = apiInstance.UpdateUserProfilePicture(userId, profilePicture);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProfilesApi.UpdateUserProfilePicture: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **long?**| User ID | 
 **profilePicture** | **System.IO.Stream**| User profile picture | 

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

