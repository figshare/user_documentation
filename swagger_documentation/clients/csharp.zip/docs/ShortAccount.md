# IO.Swagger.Model.ShortAccount
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Account id | [optional] 
**FirstName** | **string** | First Name | [optional] 
**LastName** | **string** | Last Name | [optional] 
**InstitutionId** | **long?** | Account institution | [optional] 
**Email** | **string** | User email | [optional] 
**Active** | **long?** | Account activity status | [optional] 
**InstitutionUserId** | **string** | Account institution user id | [optional] 
**Quota** | **long?** | Total storage available to account, in bytes | [optional] 
**UsedQuota** | **long?** | Storage used by the account, in bytes | [optional] 
**UserId** | **long?** | User id associated with account, useful for example for adding the account as an author to an item | [optional] 
**OrcidId** | **string** | ORCID iD associated to account | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

