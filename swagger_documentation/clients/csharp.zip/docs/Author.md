# IO.Swagger.Model.Author
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Author id | [optional] 
**FullName** | **string** | Author full name | [optional] 
**IsActive** | **bool?** | True if author has published items | [optional] 
**UrlName** | **string** | Author url name | [optional] 
**OrcidId** | **string** | Author Orcid | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

