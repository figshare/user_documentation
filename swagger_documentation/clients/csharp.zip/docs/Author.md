# IO.Swagger.Model.Author
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Author id | 
**FullName** | **string** | Author full name | 
**IsActive** | **bool?** | True if author has published items | 
**UrlName** | **string** | Author url name | 
**OrcidId** | **string** | Author Orcid | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

