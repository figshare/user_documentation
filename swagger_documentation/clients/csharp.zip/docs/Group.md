# IO.Swagger.Model.Group
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Group id | [optional] 
**Name** | **string** | Group name | [optional] 
**ResourceId** | **string** | Group resource id | [optional] 
**ParentId** | **long?** | Parent group if any | [optional] 
**AssociationCriteria** | **string** | HR code associated with group, if code exists | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

