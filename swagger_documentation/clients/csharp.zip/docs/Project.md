# IO.Swagger.Model.Project
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Url** | **string** | Api endpoint | 
**Id** | **long?** | Project id | 
**Title** | **string** | Project title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

