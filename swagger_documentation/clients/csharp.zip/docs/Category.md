# IO.Swagger.Model.Category
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParentId** | **long?** | Parent category | [optional] 
**Id** | **long?** | Category id | [optional] 
**Title** | **string** | Category title | [optional] 
**Path** | **string** | Path to all ancestor ids | [optional] 
**SourceId** | **string** | ID in original standard taxonomy | [optional] 
**TaxonomyId** | **long?** | Internal id of taxonomy the category is part of | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

