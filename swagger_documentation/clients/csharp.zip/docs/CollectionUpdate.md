# IO.Swagger.Model.CollectionUpdate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** | Title of article | [optional] 
**Description** | **string** | The article description. In a publisher case, usually this is the remote article description | [optional] [default to ""]
**Articles** | **List&lt;int?&gt;** | List of articles to be associated with the collection | [optional] 
**Authors** | **List&lt;Object&gt;** | List of authors to be assosciated with the article. The list can contain author ids or author names. No more than 10 authors. For adding more authors use the specific authors endpoint. | [optional] 
**Categories** | **List&lt;long?&gt;** | List of category ids to be associated with the article(e.g [1, 23, 33, 66]) | [optional] 
**Tags** | **List&lt;string&gt;** | List of tags to be associated with the article. Keywords can be used instead | [optional] 
**Keywords** | **List&lt;string&gt;** | List of tags to be associated with the article. Tags can be used instead | [optional] 
**References** | **List&lt;string&gt;** | List of links to be associated with the article (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) | [optional] 
**CustomFields** | **Object** | List of key, values pairs to be associated with the article | [optional] 
**ResourceId** | **string** | Not applicable to regular users. In a publisher case, this is the publisher article id | [optional] 
**ResourceDoi** | **string** | Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [optional] [default to ""]
**ResourceLink** | **string** | Not applicable to regular users. In a publisher case, this is the publisher article link | [optional] 
**ResourceTitle** | **string** | Not applicable to regular users. In a publisher case, this is the publisher article title. | [optional] [default to ""]
**ResourceVersion** | **int?** | Not applicable to regular users. In a publisher case, this is the publisher article version | [optional] 
**GroupId** | **long?** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

