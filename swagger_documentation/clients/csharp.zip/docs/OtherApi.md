# IO.Swagger.Api.OtherApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CategoriesList**](OtherApi.md#categorieslist) | **GET** /categories | Public Categories
[**FileDownload**](OtherApi.md#filedownload) | **GET** /file/download/{file_id} | Public File Download
[**LicensesList**](OtherApi.md#licenseslist) | **GET** /licenses | Public Licenses
[**PrivateAccount**](OtherApi.md#privateaccount) | **GET** /account | Private Account information
[**PrivateLicensesList**](OtherApi.md#privatelicenseslist) | **GET** /account/licenses | Private Account Licenses


<a name="categorieslist"></a>
# **CategoriesList**
> List<Category> CategoriesList ()

Public Categories

Returns a list of public categories

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CategoriesListExample
    {
        public void main()
        {
            
            var apiInstance = new OtherApi();

            try
            {
                // Public Categories
                List&lt;Category&gt; result = apiInstance.CategoriesList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OtherApi.CategoriesList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<Category>**](Category.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="filedownload"></a>
# **FileDownload**
> void FileDownload (long? fileId)

Public File Download

Starts the download of a file

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FileDownloadExample
    {
        public void main()
        {
            
            var apiInstance = new OtherApi();
            var fileId = 789;  // long? | 

            try
            {
                // Public File Download
                apiInstance.FileDownload(fileId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OtherApi.FileDownload: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **fileId** | **long?**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/force-download

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="licenseslist"></a>
# **LicensesList**
> List<License> LicensesList ()

Public Licenses

Returns a list of public licenses

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class LicensesListExample
    {
        public void main()
        {
            
            var apiInstance = new OtherApi();

            try
            {
                // Public Licenses
                List&lt;License&gt; result = apiInstance.LicensesList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OtherApi.LicensesList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<License>**](License.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateaccount"></a>
# **PrivateAccount**
> Account PrivateAccount ()

Private Account information

Account information for token/personal token

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateAccountExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OtherApi();

            try
            {
                // Private Account information
                Account result = apiInstance.PrivateAccount();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OtherApi.PrivateAccount: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatelicenseslist"></a>
# **PrivateLicensesList**
> List<License> PrivateLicensesList ()

Private Account Licenses

This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateLicensesListExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OtherApi();

            try
            {
                // Private Account Licenses
                List&lt;License&gt; result = apiInstance.PrivateLicensesList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OtherApi.PrivateLicensesList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<License>**](License.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

