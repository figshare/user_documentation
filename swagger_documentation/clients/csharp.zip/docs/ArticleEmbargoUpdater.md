# IO.Swagger.Model.ArticleEmbargoUpdater
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsEmbargoed** | **bool?** | Confidentiality status | [optional] 
**EmbargoDate** | **string** | Date when the embargo expires and the article gets published | [optional] 
**EmbargoType** | **string** | Embargo can be enabled at the article or the file level. Possible values: article, file | [optional] 
**EmbargoReason** | **string** | Reason for setting embargo | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

