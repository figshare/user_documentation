# IO.Swagger.Api.DefaultApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AccountArticleReportGenerate**](DefaultApi.md#accountarticlereportgenerate) | **POST** /account/articles/export | Initiate a new Report


<a name="accountarticlereportgenerate"></a>
# **AccountArticleReportGenerate**
> AccountReport AccountArticleReportGenerate ()

Initiate a new Report

Initiate a new Article Report for this Account

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AccountArticleReportGenerateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DefaultApi();

            try
            {
                // Initiate a new Report
                AccountReport result = apiInstance.AccountArticleReportGenerate();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.AccountArticleReportGenerate: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

