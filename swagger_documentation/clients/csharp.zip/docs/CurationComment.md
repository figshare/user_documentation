# IO.Swagger.Model.CurationComment
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | The ID of the comment. | [optional] 
**AccountId** | **long?** | The ID of the account which generated this comment. | [optional] 
**Type** | **string** | The ID of the account which generated this comment. | [optional] 
**Text** | **string** | The value/content of the comment. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

