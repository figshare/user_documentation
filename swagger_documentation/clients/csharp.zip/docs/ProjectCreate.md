# IO.Swagger.Model.ProjectCreate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** | The title for this project - mandatory. 3 - 500 characters. | 
**Description** | **string** | Project description | [optional] 
**Funding** | **string** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 
**FundingList** | [**List&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items | [optional] 
**GroupId** | **long?** | Only if project type is group. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

