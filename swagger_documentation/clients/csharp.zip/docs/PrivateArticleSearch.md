# IO.Swagger.Model.PrivateArticleSearch
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Order** | **string** | The field by which to order | [optional] [default to created_date]
**ResourceDoi** | **string** | Only return articles with this resource_doi | [optional] 
**ItemType** | **long?** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
**Doi** | **string** | Only return articles with this doi | [optional] 
**Handle** | **string** | Only return articles with this handle | [optional] 
**ProjectId** | **long?** | Only return articles in this project | [optional] 
**SearchFor** | **string** | Search term | [optional] 
**Page** | **long?** | Page number. Used for pagination with page_size | [optional] 
**PageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**Limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional] 
**Offset** | **long?** | Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
**OrderDirection** | **string** | Direction of ordering | [optional] [default to OrderDirectionEnum.Desc]
**Institution** | **int?** | only return collections from this institution | [optional] 
**PublishedSince** | **string** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
**ModifiedSince** | **string** | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
**Group** | **int?** | only return collections from this group | [optional] 
**ResourceId** | **string** | only return collections with this resource_id | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

