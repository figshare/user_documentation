# IO.Swagger.Model.AccountReport
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | A unique ID for the AccountRecord | [optional] 
**AccountId** | **long?** | The ID of the account which generated this report. | [optional] 
**CreatedDate** | **string** | Date when the AccountReport was requested | [optional] 
**Status** | **string** | Status of the report | [optional] 
**DownloadUrl** | **string** | The download link for the generated XLSX | [optional] 
**GroupId** | **long?** | The group ID that was used to filter the report, if any. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

