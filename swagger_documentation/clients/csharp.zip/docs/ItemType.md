# IO.Swagger.Model.ItemType
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | The ID of the item type. | [optional] 
**Name** | **string** | The name of the item type | [optional] 
**StringId** | **string** | The string identifier of the item type. | [optional] 
**Icon** | **string** | The string identifying the icon of the item type. | [optional] 
**PublicDescription** | **string** | The description of the item type. | [optional] 
**IsSelectable** | **long?** | Filter by the selectable status | [optional] 
**UrlName** | **string** | The URL name of the item type. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

