# IO.Swagger.Model.CreateProjectResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EntityId** | **long?** | Figshare ID of the entity | 
**Location** | **string** | Url for entity | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

