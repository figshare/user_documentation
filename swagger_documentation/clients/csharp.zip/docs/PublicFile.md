# IO.Swagger.Model.PublicFile
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | File id | [optional] 
**Name** | **string** | File name | [optional] 
**Size** | **long?** | File size | [optional] 
**IsLinkOnly** | **bool?** | True if file is hosted somewhere else | [optional] 
**DownloadUrl** | **string** | Url for file download | [optional] 
**SuppliedMd5** | **string** | File supplied md5 | [optional] 
**ComputedMd5** | **string** | File computed md5 | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

