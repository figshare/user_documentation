# IO.Swagger.Model.PublicFile
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | File id | 
**Name** | **string** | File name | 
**Size** | **long?** | File size | 
**IsLinkOnly** | **bool?** | True if file is hosted somewhere else | 
**DownloadUrl** | **string** | Url for file download | 
**SuppliedMd5** | **string** | File supplied md5 | 
**ComputedMd5** | **string** | File computed md5 | 
**Mimetype** | **string** | MIME Type of the file, it defaults to an empty string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

