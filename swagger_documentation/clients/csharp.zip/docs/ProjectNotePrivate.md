# IO.Swagger.Model.ProjectNotePrivate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Project note id | [optional] 
**UserId** | **long?** | User who wrote the note | [optional] 
**_Abstract** | **string** | Note Abstract - short/truncated content | [optional] 
**UserName** | **string** | Username of the one who wrote the note | [optional] 
**CreatedDate** | **string** | Date when note was created | [optional] 
**ModifiedDate** | **string** | Date when note was last modified | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

