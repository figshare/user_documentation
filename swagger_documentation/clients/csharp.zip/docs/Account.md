# IO.Swagger.Model.Account
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Account id | [optional] 
**FirstName** | **string** | First Name | [optional] 
**LastName** | **string** | Last Name | [optional] 
**UsedQuotaPrivate** | **long?** | Account used private quota | [optional] 
**ModifiedDate** | **string** | Date of last account modification | [optional] 
**UsedQuota** | **long?** | Account total used quota | [optional] 
**CreatedDate** | **string** | Date when account was created | [optional] 
**Quota** | **long?** | Account quota | [optional] 
**GroupId** | **long?** | Account group id | [optional] 
**InstitutionUserId** | **string** | Account institution user id | [optional] 
**InstitutionId** | **long?** | Account institution | [optional] 
**Email** | **string** | User email | [optional] 
**UsedQuotaPublic** | **long?** | Account public used quota | [optional] 
**PendingQuotaRequest** | **bool?** | True if a quota request is pending | [optional] 
**Active** | **long?** | Account activity status | [optional] 
**MaximumFileSize** | **long?** | Maximum upload size for account | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

