# IO.Swagger.Model.ShortCustomField
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Custom field id | [optional] 
**Name** | **string** | Custom field name | [optional] 
**FieldType** | **string** | Custom field type | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

