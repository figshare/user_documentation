# IO.Swagger.Model.License
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Value** | **long?** | License value | [optional] 
**Name** | **string** | License name | [optional] 
**Url** | **string** | License url | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

