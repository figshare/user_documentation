# IO.Swagger.Model.ArticleEmbargo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsEmbargoed** | **bool?** | True if embargoed | [optional] 
**EmbargoReason** | **string** | Reason for embargo | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

