# IO.Swagger.Model.PrivateLink
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Private link id | [optional] 
**IsActive** | **bool?** | True if private link is active | [optional] 
**ExpiresDate** | **string** | Date when link will expire | [optional] 
**HtmlLocation** | **string** | HTML url for private link | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

