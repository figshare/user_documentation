# IO.Swagger.Model.Article
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Unique identifier for article | [optional] 
**Title** | **string** | Title of article | [optional] 
**Doi** | **string** | DOI | [optional] 
**Url** | **string** | Api endpoint for article | [optional] 
**UrlPublicHtml** | **string** | Public site endpoint for article | [optional] 
**UrlPublicApi** | **string** | Public Api endpoint for article | [optional] 
**UrlPrivateHtml** | **string** | Private site endpoint for article | [optional] 
**UrlPrivateApi** | **string** | Private Api endpoint for article | [optional] 
**Thumb** | **string** | Thumbnail image | [optional] 
**DefinedType** | **long?** | Integer which is mapped to item types as: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

