# IO.Swagger.Model.CollectionComplete
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Collection id | 
**Title** | **string** | Collection title | 
**Doi** | **string** | Collection DOI | 
**Handle** | **string** | Collection Handle | 
**Url** | **string** | Api endpoint | 
**Timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**Funding** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information | 
**ResourceId** | **string** | Collection resource id | 
**ResourceDoi** | **string** | Collection resource doi | 
**ResourceTitle** | **string** | Collection resource title | 
**ResourceLink** | **string** | Collection resource link | 
**ResourceVersion** | **long?** | Collection resource version | 
**Version** | **long?** | Collection version | 
**Description** | **string** | Collection description | 
**Categories** | [**List&lt;Category&gt;**](Category.md) | List of collection categories | 
**References** | **List&lt;string&gt;** | List of collection references | 
**Tags** | **List&lt;string&gt;** | List of collection tags | 
**Authors** | [**List&lt;Author&gt;**](Author.md) | List of collection authors | 
**InstitutionId** | **long?** | Collection institution | 
**GroupId** | **long?** | Collection group | 
**ArticlesCount** | **long?** | Number of articles in collection | 
**Public** | **bool?** | True if collection is published | 
**Citation** | **string** | Collection citation | 
**CustomFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Collection custom fields | 
**ModifiedDate** | **string** | Date when collection was last modified | 
**CreatedDate** | **string** | Date when collection was created | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

