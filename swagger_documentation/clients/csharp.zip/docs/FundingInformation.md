# IO.Swagger.Model.FundingInformation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Funding id | [optional] 
**Title** | **string** | The funding name | [optional] 
**GrantCode** | **string** | The grant code | [optional] 
**FunderName** | **string** | Funder&#39;s name | [optional] 
**IsUserDefined** | **bool?** | Return whether the grant has been introduced manually | [optional] 
**Url** | **string** | The grant url | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

