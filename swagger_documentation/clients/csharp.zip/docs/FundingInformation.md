# IO.Swagger.Model.FundingInformation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Funding id | 
**Title** | **string** | The funding name | 
**GrantCode** | **string** | The grant code | 
**FunderName** | **string** | Funder&#39;s name | 
**IsUserDefined** | **long?** | Return 1 whether the grant has been introduced manually, 0 otherwise | 
**Url** | **string** | The grant url | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

