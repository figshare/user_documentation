# IO.Swagger.Model.PrivateLinkCreator
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExpiresDate** | **string** | Date when this private link should expire - optional. By default private links expire in 365 days. | [optional] 
**_ReadOnly** | **bool?** | Optional, default true. Set to false to give private link users editing rights for this collection. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

