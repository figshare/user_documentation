# IO.Swagger.Model.User
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | User id | [optional] 
**FirstName** | **string** | First Name | [optional] 
**LastName** | **string** | Last Name | [optional] 
**Name** | **string** | Full Name | [optional] 
**IsActive** | **bool?** | Account activity status | [optional] 
**UrlName** | **string** | Name that appears in website url | [optional] 
**IsPublic** | **bool?** | Account public status | [optional] 
**JobTitle** | **string** | User Job title | [optional] 
**OrcidId** | **string** | Orcid associated to this User | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

