# IO.Swagger.Model.ArticleVersions
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Version** | **long?** | Version number | 
**Url** | **string** | Api endpoint for the item version | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

