# WWW::SwaggerClient::Object::ArticleConfidentiality

## Load the model package
```perl
use WWW::SwaggerClient::Object::ArticleConfidentiality;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_confidential** | **boolean** | True if article is confidential | 
**reason** | **string** | Reason for confidentiality | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


