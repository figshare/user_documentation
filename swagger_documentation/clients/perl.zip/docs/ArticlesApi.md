# WWW::SwaggerClient::ArticlesApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ArticlesApi;
```

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**account_article_report**](ArticlesApi.md#account_article_report) | **GET** /account/articles/export | Account Article Report
[**account_article_report_generate**](ArticlesApi.md#account_article_report_generate) | **POST** /account/articles/export | Initiate a new Report
[**article_details**](ArticlesApi.md#article_details) | **GET** /articles/{article_id} | View article details
[**article_file_details**](ArticlesApi.md#article_file_details) | **GET** /articles/{article_id}/files/{file_id} | Article file details
[**article_files**](ArticlesApi.md#article_files) | **GET** /articles/{article_id}/files | List article files
[**article_version_confidentiality**](ArticlesApi.md#article_version_confidentiality) | **GET** /articles/{article_id}/versions/{v_number}/confidentiality | Public Article Confidentiality for article version
[**article_version_details**](ArticlesApi.md#article_version_details) | **GET** /articles/{article_id}/versions/{v_number} | Article details for version
[**article_version_embargo**](ArticlesApi.md#article_version_embargo) | **GET** /articles/{article_id}/versions/{v_number}/embargo | Public Article Embargo for article version
[**article_version_update**](ArticlesApi.md#article_version_update) | **PUT** /account/articles/{article_id}/versions/{version_id}/ | Update article version
[**article_version_update_thumb**](ArticlesApi.md#article_version_update_thumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail
[**article_versions**](ArticlesApi.md#article_versions) | **GET** /articles/{article_id}/versions | List article versions
[**articles_list**](ArticlesApi.md#articles_list) | **GET** /articles | Public Articles
[**articles_search**](ArticlesApi.md#articles_search) | **POST** /articles/search | Public Articles Search
[**private_article_author_delete**](ArticlesApi.md#private_article_author_delete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author
[**private_article_authors_add**](ArticlesApi.md#private_article_authors_add) | **POST** /account/articles/{article_id}/authors | Add article authors
[**private_article_authors_list**](ArticlesApi.md#private_article_authors_list) | **GET** /account/articles/{article_id}/authors | List article authors
[**private_article_authors_replace**](ArticlesApi.md#private_article_authors_replace) | **PUT** /account/articles/{article_id}/authors | Replace article authors
[**private_article_categories_add**](ArticlesApi.md#private_article_categories_add) | **POST** /account/articles/{article_id}/categories | Add article categories
[**private_article_categories_list**](ArticlesApi.md#private_article_categories_list) | **GET** /account/articles/{article_id}/categories | List article categories
[**private_article_categories_replace**](ArticlesApi.md#private_article_categories_replace) | **PUT** /account/articles/{article_id}/categories | Replace article categories
[**private_article_category_delete**](ArticlesApi.md#private_article_category_delete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category
[**private_article_confidentiality_delete**](ArticlesApi.md#private_article_confidentiality_delete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality
[**private_article_confidentiality_details**](ArticlesApi.md#private_article_confidentiality_details) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details
[**private_article_confidentiality_update**](ArticlesApi.md#private_article_confidentiality_update) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality
[**private_article_create**](ArticlesApi.md#private_article_create) | **POST** /account/articles | Create new Article
[**private_article_delete**](ArticlesApi.md#private_article_delete) | **DELETE** /account/articles/{article_id} | Delete article
[**private_article_details**](ArticlesApi.md#private_article_details) | **GET** /account/articles/{article_id} | Article details
[**private_article_embargo_delete**](ArticlesApi.md#private_article_embargo_delete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo
[**private_article_embargo_details**](ArticlesApi.md#private_article_embargo_details) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details
[**private_article_embargo_update**](ArticlesApi.md#private_article_embargo_update) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo
[**private_article_file**](ArticlesApi.md#private_article_file) | **GET** /account/articles/{article_id}/files/{file_id} | Single File
[**private_article_file_delete**](ArticlesApi.md#private_article_file_delete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete
[**private_article_files_list**](ArticlesApi.md#private_article_files_list) | **GET** /account/articles/{article_id}/files | List article files
[**private_article_private_link**](ArticlesApi.md#private_article_private_link) | **GET** /account/articles/{article_id}/private_links | List private links
[**private_article_private_link_create**](ArticlesApi.md#private_article_private_link_create) | **POST** /account/articles/{article_id}/private_links | Create private link
[**private_article_private_link_delete**](ArticlesApi.md#private_article_private_link_delete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link
[**private_article_private_link_update**](ArticlesApi.md#private_article_private_link_update) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link
[**private_article_publish**](ArticlesApi.md#private_article_publish) | **POST** /account/articles/{article_id}/publish | Private Article Publish
[**private_article_reserve_doi**](ArticlesApi.md#private_article_reserve_doi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI
[**private_article_reserve_handle**](ArticlesApi.md#private_article_reserve_handle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle
[**private_article_resource**](ArticlesApi.md#private_article_resource) | **POST** /account/articles/{article_id}/resource | Private Article Resource
[**private_article_update**](ArticlesApi.md#private_article_update) | **PUT** /account/articles/{article_id} | Update article
[**private_article_upload_complete**](ArticlesApi.md#private_article_upload_complete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload
[**private_article_upload_initiate**](ArticlesApi.md#private_article_upload_initiate) | **POST** /account/articles/{article_id}/files | Initiate Upload
[**private_articles_list**](ArticlesApi.md#private_articles_list) | **GET** /account/articles | Private Articles
[**private_articles_search**](ArticlesApi.md#private_articles_search) | **POST** /account/articles/search | Private Articles search


# **account_article_report**
> ARRAY[AccountReport] account_article_report(group_id => $group_id)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $group_id = 789; # int | A group ID to filter by

eval { 
    my $result = $api_instance->account_article_report(group_id => $group_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->account_article_report: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| A group ID to filter by | [optional] 

### Return type

[**ARRAY[AccountReport]**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **account_article_report_generate**
> AccountReport account_article_report_generate()

Initiate a new Report

Initiate a new Article Report for this Account

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();

eval { 
    my $result = $api_instance->account_article_report_generate();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->account_article_report_generate: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_details**
> ArticleComplete article_details(article_id => $article_id)

View article details

View an article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article Unique identifier

eval { 
    my $result = $api_instance->article_details(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->article_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_file_details**
> PublicFile article_file_details(article_id => $article_id, file_id => $file_id)

Article file details

File by id

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article Unique identifier
my $file_id = 789; # int | File Unique identifier

eval { 
    my $result = $api_instance->article_file_details(article_id => $article_id, file_id => $file_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->article_file_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **file_id** | **int**| File Unique identifier | 

### Return type

[**PublicFile**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_files**
> ARRAY[PublicFile] article_files(article_id => $article_id)

List article files

Files list for article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article Unique identifier

eval { 
    my $result = $api_instance->article_files(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->article_files: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 

### Return type

[**ARRAY[PublicFile]**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_confidentiality**
> ArticleConfidentiality article_version_confidentiality(article_id => $article_id, v_number => $v_number)

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article Unique identifier
my $v_number = 789; # int | Version Number

eval { 
    my $result = $api_instance->article_version_confidentiality(article_id => $article_id, v_number => $v_number);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->article_version_confidentiality: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **v_number** | **int**| Version Number | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_details**
> ArticleComplete article_version_details(article_id => $article_id, v_number => $v_number)

Article details for version

Article with specified version

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article Unique identifier
my $v_number = 789; # int | Article Version Number

eval { 
    my $result = $api_instance->article_version_details(article_id => $article_id, v_number => $v_number);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->article_version_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **v_number** | **int**| Article Version Number | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_embargo**
> ArticleEmbargo article_version_embargo(article_id => $article_id, v_number => $v_number)

Public Article Embargo for article version

Embargo for article version

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article Unique identifier
my $v_number = 789; # int | Version Number

eval { 
    my $result = $api_instance->article_version_embargo(article_id => $article_id, v_number => $v_number);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->article_version_embargo: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **v_number** | **int**| Version Number | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_update**
> LocationWarnings article_version_update(article_id => $article_id, version_id => $version_id, article => $article)

Update article version

Updating an article version by passing body parameters; request can also be made with the PATCH method.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $version_id = 789; # int | Article version identifier
my $article = WWW::SwaggerClient::Object::ArticleUpdate->new(); # ArticleUpdate | Article description

eval { 
    my $result = $api_instance->article_version_update(article_id => $article_id, version_id => $version_id, article => $article);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->article_version_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **version_id** | **int**| Article version identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md)| Article description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_update_thumb**
> article_version_update_thumb(article_id => $article_id, version_id => $version_id, file_id => $file_id)

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $version_id = 789; # int | Article version identifier
my $file_id = WWW::SwaggerClient::Object::FileId->new(); # FileId | File ID

eval { 
    $api_instance->article_version_update_thumb(article_id => $article_id, version_id => $version_id, file_id => $file_id);
};
if ($@) {
    warn "Exception when calling ArticlesApi->article_version_update_thumb: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **version_id** | **int**| Article version identifier | 
 **file_id** | [**FileId**](FileId.md)| File ID | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_versions**
> ARRAY[ArticleVersions] article_versions(article_id => $article_id)

List article versions

List public article versions

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article Unique identifier

eval { 
    my $result = $api_instance->article_versions(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->article_versions: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 

### Return type

[**ARRAY[ArticleVersions]**](ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articles_list**
> ARRAY[Article] articles_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, institution => $institution, published_since => $published_since, modified_since => $modified_since, group => $group, resource_doi => $resource_doi, item_type => $item_type, doi => $doi, handle => $handle)

Public Articles

Returns a list of public articles

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 789; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing(the offset of the first result). Used for pagination with limit
my $order = 'order_example'; # string | The field by which to order. Default varies by endpoint/resource.
my $order_direction = 'order_direction_example'; # string | 
my $institution = 789; # int | only return articles from this institution
my $published_since = 'published_since_example'; # string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
my $modified_since = 'modified_since_example'; # string | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
my $group = 789; # int | only return articles from this group
my $resource_doi = 'resource_doi_example'; # string | only return articles with this resource_doi
my $item_type = 789; # int | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
my $doi = 'doi_example'; # string | only return articles with this doi
my $handle = 'handle_example'; # string | only return articles with this handle

eval { 
    my $result = $api_instance->articles_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, institution => $institution, published_since => $published_since, modified_since => $modified_since, group => $group, resource_doi => $resource_doi, item_type => $item_type, doi => $doi, handle => $handle);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->articles_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]
 **institution** | **int**| only return articles from this institution | [optional] 
 **published_since** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **modified_since** | **string**| Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **group** | **int**| only return articles from this group | [optional] 
 **resource_doi** | **string**| only return articles with this resource_doi | [optional] 
 **item_type** | **int**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
 **doi** | **string**| only return articles with this doi | [optional] 
 **handle** | **string**| only return articles with this handle | [optional] 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articles_search**
> ARRAY[Article] articles_search(search => $search)

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $search = WWW::SwaggerClient::Object::ArticleSearch->new(); # ArticleSearch | Search Parameters

eval { 
    my $result = $api_instance->articles_search(search => $search);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->articles_search: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**ArticleSearch**](ArticleSearch.md)| Search Parameters | [optional] 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_author_delete**
> private_article_author_delete(article_id => $article_id, author_id => $author_id)

Delete article author

De-associate author from article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $author_id = 789; # int | Article Author unique identifier

eval { 
    $api_instance->private_article_author_delete(article_id => $article_id, author_id => $author_id);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_author_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **author_id** | **int**| Article Author unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_authors_add**
> private_article_authors_add(article_id => $article_id, authors => $authors)

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $authors = WWW::SwaggerClient::Object::AuthorsCreator->new(); # AuthorsCreator | Authors description

eval { 
    $api_instance->private_article_authors_add(article_id => $article_id, authors => $authors);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_authors_add: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_authors_list**
> ARRAY[Author] private_article_authors_list(article_id => $article_id)

List article authors

List article authors

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_authors_list(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_authors_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ARRAY[Author]**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_authors_replace**
> private_article_authors_replace(article_id => $article_id, authors => $authors)

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $authors = WWW::SwaggerClient::Object::AuthorsCreator->new(); # AuthorsCreator | Authors description

eval { 
    $api_instance->private_article_authors_replace(article_id => $article_id, authors => $authors);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_authors_replace: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_categories_add**
> private_article_categories_add(article_id => $article_id, categories => $categories)

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $categories = WWW::SwaggerClient::Object::CategoriesCreator->new(); # CategoriesCreator | 

eval { 
    $api_instance->private_article_categories_add(article_id => $article_id, categories => $categories);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_categories_add: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_categories_list**
> ARRAY[Category] private_article_categories_list(article_id => $article_id)

List article categories

List article categories

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_categories_list(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_categories_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ARRAY[Category]**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_categories_replace**
> private_article_categories_replace(article_id => $article_id, categories => $categories)

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $categories = WWW::SwaggerClient::Object::CategoriesCreator->new(); # CategoriesCreator | 

eval { 
    $api_instance->private_article_categories_replace(article_id => $article_id, categories => $categories);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_categories_replace: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_category_delete**
> private_article_category_delete(article_id => $article_id, category_id => $category_id)

Delete article category

De-associate category from article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $category_id = 789; # int | Category unique identifier

eval { 
    $api_instance->private_article_category_delete(article_id => $article_id, category_id => $category_id);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_category_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **category_id** | **int**| Category unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_confidentiality_delete**
> private_article_confidentiality_delete(article_id => $article_id)

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    $api_instance->private_article_confidentiality_delete(article_id => $article_id);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_confidentiality_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_confidentiality_details**
> ArticleConfidentiality private_article_confidentiality_details(article_id => $article_id)

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_confidentiality_details(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_confidentiality_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_confidentiality_update**
> private_article_confidentiality_update(article_id => $article_id, reason => $reason)

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $reason = WWW::SwaggerClient::Object::ConfidentialityCreator->new(); # ConfidentialityCreator | 

eval { 
    $api_instance->private_article_confidentiality_update(article_id => $article_id, reason => $reason);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_confidentiality_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **reason** | [**ConfidentialityCreator**](ConfidentialityCreator.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_create**
> LocationWarnings private_article_create(article => $article)

Create new Article

Create a new Article by sending article information

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article = WWW::SwaggerClient::Object::ArticleCreate->new(); # ArticleCreate | Article description

eval { 
    my $result = $api_instance->private_article_create(article => $article);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_create: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article** | [**ArticleCreate**](ArticleCreate.md)| Article description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_delete**
> private_article_delete(article_id => $article_id)

Delete article

Delete an article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    $api_instance->private_article_delete(article_id => $article_id);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_details**
> ArticleCompletePrivate private_article_details(article_id => $article_id)

Article details

View a private article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_details(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_embargo_delete**
> private_article_embargo_delete(article_id => $article_id)

Delete Article Embargo

Will lift the embargo for the specified article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    $api_instance->private_article_embargo_delete(article_id => $article_id);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_embargo_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_embargo_details**
> ArticleEmbargo private_article_embargo_details(article_id => $article_id)

Article Embargo Details

View a private article embargo details

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_embargo_details(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_embargo_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_embargo_update**
> private_article_embargo_update(article_id => $article_id, embargo => $embargo)

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $embargo = WWW::SwaggerClient::Object::ArticleEmbargoUpdater->new(); # ArticleEmbargoUpdater | Embargo description

eval { 
    $api_instance->private_article_embargo_update(article_id => $article_id, embargo => $embargo);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_embargo_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **embargo** | [**ArticleEmbargoUpdater**](ArticleEmbargoUpdater.md)| Embargo description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_file**
> PrivateFile private_article_file(article_id => $article_id, file_id => $file_id)

Single File

View details of file for specified article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $file_id = 789; # int | File unique identifier

eval { 
    my $result = $api_instance->private_article_file(article_id => $article_id, file_id => $file_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_file: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **file_id** | **int**| File unique identifier | 

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_file_delete**
> private_article_file_delete(article_id => $article_id, file_id => $file_id)

File Delete

Complete file upload

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $file_id = 789; # int | File unique identifier

eval { 
    $api_instance->private_article_file_delete(article_id => $article_id, file_id => $file_id);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_file_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **file_id** | **int**| File unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_files_list**
> ARRAY[PrivateFile] private_article_files_list(article_id => $article_id)

List article files

List private files

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_files_list(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_files_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ARRAY[PrivateFile]**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_private_link**
> ARRAY[PrivateLink] private_article_private_link(article_id => $article_id)

List private links

List private links

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_private_link(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_private_link: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ARRAY[PrivateLink]**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_private_link_create**
> Location private_article_private_link_create(article_id => $article_id, private_link => $private_link)

Create private link

Create new private link for this article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $private_link = WWW::SwaggerClient::Object::PrivateLinkCreator->new(); # PrivateLinkCreator | 

eval { 
    my $result = $api_instance->private_article_private_link_create(article_id => $article_id, private_link => $private_link);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_private_link_create: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **private_link** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_private_link_delete**
> private_article_private_link_delete(article_id => $article_id, link_id => $link_id)

Disable private link

Disable/delete private link for this article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $link_id = 'link_id_example'; # string | Private link token

eval { 
    $api_instance->private_article_private_link_delete(article_id => $article_id, link_id => $link_id);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_private_link_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **link_id** | **string**| Private link token | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_private_link_update**
> private_article_private_link_update(article_id => $article_id, link_id => $link_id, private_link => $private_link)

Update private link

Update existing private link for this article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $link_id = 'link_id_example'; # string | Private link token
my $private_link = WWW::SwaggerClient::Object::PrivateLinkCreator->new(); # PrivateLinkCreator | 

eval { 
    $api_instance->private_article_private_link_update(article_id => $article_id, link_id => $link_id, private_link => $private_link);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_private_link_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **link_id** | **string**| Private link token | 
 **private_link** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_publish**
> Location private_article_publish(article_id => $article_id)

Private Article Publish

- If the whole article is under embargo, it will not be published immediatly, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_publish(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_publish: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_reserve_doi**
> ArticleDOI private_article_reserve_doi(article_id => $article_id)

Private Article Reserve DOI

Reserve DOI for article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_reserve_doi(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_reserve_doi: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleDOI**](ArticleDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_reserve_handle**
> ArticleHandle private_article_reserve_handle(article_id => $article_id)

Private Article Reserve Handle

Reserve Handle for article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier

eval { 
    my $result = $api_instance->private_article_reserve_handle(article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_reserve_handle: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleHandle**](ArticleHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_resource**
> private_article_resource(article_id => $article_id, resource => $resource)

Private Article Resource

Edit article resource data.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $resource = WWW::SwaggerClient::Object::Resource->new(); # Resource | Resource data

eval { 
    $api_instance->private_article_resource(article_id => $article_id, resource => $resource);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_resource: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **resource** | [**Resource**](Resource.md)| Resource data | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_update**
> LocationWarnings private_article_update(article_id => $article_id, article => $article)

Update article

Updating an article by passing body parameters; request can also be made with the PATCH method.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $article = WWW::SwaggerClient::Object::ArticleUpdate->new(); # ArticleUpdate | Article description

eval { 
    my $result = $api_instance->private_article_update(article_id => $article_id, article => $article);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md)| Article description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_upload_complete**
> private_article_upload_complete(article_id => $article_id, file_id => $file_id)

Complete Upload

Complete file upload

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $file_id = 789; # int | File unique identifier

eval { 
    $api_instance->private_article_upload_complete(article_id => $article_id, file_id => $file_id);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_upload_complete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **file_id** | **int**| File unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_upload_initiate**
> Location private_article_upload_initiate(article_id => $article_id, file => $file)

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $article_id = 789; # int | Article unique identifier
my $file = WWW::SwaggerClient::Object::FileCreator->new(); # FileCreator | 

eval { 
    my $result = $api_instance->private_article_upload_initiate(article_id => $article_id, file => $file);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_article_upload_initiate: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **file** | [**FileCreator**](FileCreator.md)|  | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_articles_list**
> ARRAY[Article] private_articles_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset)

Private Articles

Get Own Articles

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 789; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing(the offset of the first result). Used for pagination with limit

eval { 
    my $result = $api_instance->private_articles_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_articles_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_articles_search**
> ARRAY[Article] private_articles_search(search => $search)

Private Articles search

Returns a list of private articles filtered by the search parameters

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::ArticlesApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::ArticlesApi->new();
my $search = WWW::SwaggerClient::Object::PrivateArticleSearch->new(); # PrivateArticleSearch | Search Parameters

eval { 
    my $result = $api_instance->private_articles_search(search => $search);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArticlesApi->private_articles_search: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateArticleSearch**](PrivateArticleSearch.md)| Search Parameters | 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

