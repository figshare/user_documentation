# WWW::SwaggerClient::Object::AccountUpdate

## Load the model package
```perl
use WWW::SwaggerClient::Object::AccountUpdate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_id** | **int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 
**is_active** | **boolean** | Is account active | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


