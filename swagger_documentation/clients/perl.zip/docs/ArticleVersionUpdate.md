# WWW::SwaggerClient::Object::ArticleVersionUpdate

## Load the model package
```perl
use WWW::SwaggerClient::Object::ArticleVersionUpdate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supplementary_fields** | **ARRAY[object]** | List of supplementary fields to be associated with the article version | [optional] 
**internal_metadata** | **object** | List of supplementary fields to be associated with the article version | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


