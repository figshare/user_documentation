# WWW::SwaggerClient::Object::ResponseMessage

## Load the model package
```perl
use WWW::SwaggerClient::Object::ResponseMessage;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **string** | Response message text | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


