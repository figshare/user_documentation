# WWW::SwaggerClient::Object::Group

## Load the model package
```perl
use WWW::SwaggerClient::Object::Group;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Group id | 
**name** | **string** | Group name | 
**resource_id** | **string** | Group resource id | 
**parent_id** | **int** | Parent group if any | 
**association_criteria** | **string** | HR code associated with group, if code exists | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


