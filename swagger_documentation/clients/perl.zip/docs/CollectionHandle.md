# WWW::SwaggerClient::Object::CollectionHandle

## Load the model package
```perl
use WWW::SwaggerClient::Object::CollectionHandle;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handle** | **string** | Reserved Handle | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


