# WWW::SwaggerClient::Object::User

## Load the model package
```perl
use WWW::SwaggerClient::Object::User;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | User id | [optional] 
**first_name** | **string** | First Name | [optional] 
**last_name** | **string** | Last Name | [optional] 
**name** | **string** | Full Name | [optional] 
**is_active** | **boolean** | Account activity status | [optional] 
**url_name** | **string** | Name that appears in website url | [optional] 
**is_public** | **boolean** | Account public status | [optional] 
**job_title** | **string** | User Job title | [optional] 
**orcid_id** | **string** | Orcid associated to this User | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


