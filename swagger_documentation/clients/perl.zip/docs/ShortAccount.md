# WWW::SwaggerClient::Object::ShortAccount

## Load the model package
```perl
use WWW::SwaggerClient::Object::ShortAccount;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id | [optional] 
**first_name** | **string** | First Name | [optional] 
**last_name** | **string** | Last Name | [optional] 
**institution_id** | **int** | Account institution | [optional] 
**email** | **string** | User email | [optional] 
**active** | **int** | Account activity status | [optional] 
**institution_user_id** | **string** | Account institution user id | [optional] 
**quota** | **int** | Total storage available to account, in bytes | [optional] 
**used_quota** | **int** | Storage used by the account, in bytes | [optional] 
**user_id** | **int** | User id associated with account, useful for example for adding the account as an author to an item | [optional] 
**orcid_id** | **string** | ORCID iD associated to account | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


