# WWW::SwaggerClient::Object::ShortAccount

## Load the model package
```perl
use WWW::SwaggerClient::Object::ShortAccount;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id | [optional] 
**first_name** | **string** | First Name | [optional] 
**last_name** | **string** | Last Name | [optional] 
**institution_id** | **int** | Account institution | [optional] 
**email** | **string** | User email | [optional] 
**active** | **int** | Account activity status | [optional] 
**institution_user_id** | **string** | Account institution user id | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


