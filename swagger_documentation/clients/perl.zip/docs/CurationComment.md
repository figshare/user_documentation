# WWW::SwaggerClient::Object::CurationComment

## Load the model package
```perl
use WWW::SwaggerClient::Object::CurationComment;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the comment. | 
**account_id** | **int** | The ID of the account which generated this comment. | 
**type** | **string** | The ID of the account which generated this comment. | 
**text** | **string** | The value/content of the comment. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


