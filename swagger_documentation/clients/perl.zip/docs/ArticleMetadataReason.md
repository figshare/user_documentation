# WWW::SwaggerClient::Object::ArticleMetadataReason

## Load the model package
```perl
use WWW::SwaggerClient::Object::ArticleMetadataReason;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_metadata_record** | **boolean** | True if the article is metadata record | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


