# WWW::SwaggerClient::Object::ProjectPrivate

## Load the model package
```perl
use WWW::SwaggerClient::Object::ProjectPrivate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **string** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **string** | Project title | 
**role** | **string** | Role inside this project | 
**storage** | **string** | Project storage type | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


