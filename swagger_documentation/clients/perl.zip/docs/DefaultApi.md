# WWW::SwaggerClient::DefaultApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::DefaultApi;
```

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**account_article_report_generate**](DefaultApi.md#account_article_report_generate) | **POST** /account/articles/export | Initiate a new Report


# **account_article_report_generate**
> AccountReport account_article_report_generate()

Initiate a new Report

Initiate a new Article Report for this Account

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::DefaultApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::DefaultApi->new();

eval { 
    my $result = $api_instance->account_article_report_generate();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling DefaultApi->account_article_report_generate: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

