# WWW::SwaggerClient::Object::ProfileUpdateData

## Load the model package
```perl
use WWW::SwaggerClient::Object::ProfileUpdateData;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | **string** | First name | [optional] 
**last_name** | **string** | Last Name | [optional] 
**orcid** | **string** | User ORCID | [optional] 
**job_title** | **string** | User job title | [optional] 
**fields_of_interest** | **ARRAY[int]** | User fields of interest (category ids) | [optional] 
**fields_of_interest_by_source_id** | **ARRAY[string]** | User fields of interest (category source IDs), supersedes the fields_of_interest property | [optional] 
**location** | **string** | User location | [optional] 
**facebook** | **string** | User facebook URL | [optional] 
**x** | **string** | User X (twitter) URL | [optional] 
**linkedin** | **string** | User linkedin URL | [optional] 
**bio** | **string** | User biographical information | [optional] 
**personal_profiles** | [**ARRAY[ProfileUpdateDataPersonalProfiles]**](ProfileUpdateDataPersonalProfiles.md) | Add up to 10 additional personal profile links | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


