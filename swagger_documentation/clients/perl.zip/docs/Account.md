# WWW::SwaggerClient::Object::Account

## Load the model package
```perl
use WWW::SwaggerClient::Object::Account;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id | 
**first_name** | **string** | First Name | 
**last_name** | **string** | Last Name | 
**used_quota_private** | **int** | Account used private quota | 
**modified_date** | **string** | Date of last account modification | 
**used_quota** | **int** | Account total used quota | 
**created_date** | **string** | Date when account was created | 
**quota** | **int** | Account quota | 
**group_id** | **int** | Account group id | 
**institution_user_id** | **string** | Account institution user id | 
**institution_id** | **int** | Account institution | 
**email** | **string** | User email | 
**used_quota_public** | **int** | Account public used quota | 
**pending_quota_request** | **boolean** | True if a quota request is pending | 
**active** | **int** | Account activity status | 
**maximum_file_size** | **int** | Maximum upload size for account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


