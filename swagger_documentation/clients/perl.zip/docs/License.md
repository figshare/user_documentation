# WWW::SwaggerClient::Object::License

## Load the model package
```perl
use WWW::SwaggerClient::Object::License;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **int** | License value | [optional] 
**name** | **string** | License name | [optional] 
**url** | **string** | License url | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


