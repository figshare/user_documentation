# WWW::SwaggerClient::Object::FundingInformation

## Load the model package
```perl
use WWW::SwaggerClient::Object::FundingInformation;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Funding id | [optional] 
**title** | **string** | The funding name | [optional] 
**grant_code** | **string** | The grant code | [optional] 
**funder_name** | **string** | Funder&#39;s name | [optional] 
**is_user_defined** | **boolean** | Return whether the grant has been introduced manually | [optional] 
**url** | **string** | The grant url | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


