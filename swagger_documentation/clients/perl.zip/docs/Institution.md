# WWW::SwaggerClient::Object::Institution

## Load the model package
```perl
use WWW::SwaggerClient::Object::Institution;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Institution id | [optional] 
**name** | **string** | Institution name | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


