# WWW::SwaggerClient::AuthorsApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::AuthorsApi;
```

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**private_author_details**](AuthorsApi.md#private_author_details) | **GET** /account/authors/{author_id} | Author details
[**private_authors_search**](AuthorsApi.md#private_authors_search) | **POST** /account/authors/search | Search Authors


# **private_author_details**
> AuthorComplete private_author_details(author_id => $author_id)

Author details

View author details

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::AuthorsApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::AuthorsApi->new();
my $author_id = 789; # int | Author unique identifier

eval { 
    my $result = $api_instance->private_author_details(author_id => $author_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling AuthorsApi->private_author_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **author_id** | **int**| Author unique identifier | 

### Return type

[**AuthorComplete**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_authors_search**
> ARRAY[Author] private_authors_search(search => $search)

Search Authors

Search for authors

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::Configuration;
use WWW::SwaggerClient::AuthorsApi;

# Configure OAuth2 access token for authorization: OAuth2
$WWW::SwaggerClient::Configuration::access_token = 'YOUR_ACCESS_TOKEN';

my $api_instance = WWW::SwaggerClient::AuthorsApi->new();
my $search = WWW::SwaggerClient::Object::PrivateAuthorsSearch->new(); # PrivateAuthorsSearch | Search Parameters

eval { 
    my $result = $api_instance->private_authors_search(search => $search);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling AuthorsApi->private_authors_search: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateAuthorsSearch**](PrivateAuthorsSearch.md)| Search Parameters | [optional] 

### Return type

[**ARRAY[Author]**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

