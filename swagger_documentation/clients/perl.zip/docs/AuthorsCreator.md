# WWW::SwaggerClient::Object::AuthorsCreator

## Load the model package
```perl
use WWW::SwaggerClient::Object::AuthorsCreator;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | **ARRAY[object]** | List of authors to be assosciated with the article. The list can contain author ids or author names [{\&quot;id\&quot;: 12121}, {\&quot;id\&quot;: 34345}, {\&quot;name\&quot;: \&quot;John Doe\&quot;}]. No more than 10 authors. For adding more authors use the specific authors endpoint. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


