# WWW::SwaggerClient::Object::ProjectCompletePrivate

## Load the model package
```perl
use WWW::SwaggerClient::Object::ProjectCompletePrivate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **string** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **string** | Project title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


