# WWW::SwaggerClient::Object::RelatedMaterial

## Load the model package
```perl
use WWW::SwaggerClient::Object::RelatedMaterial;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the related material; can be used to add existing materials of the same account to items. | [optional] 
**identifier** | **string** | The related material identifier (e.g., DOI, Handle, ISBN) | [optional] 
**title** | **string** | The related material title | [optional] 
**relation** | **string** | The relation between the item and the related material; defaults to &#39;References&#39; | [optional] [default to &#39;References&#39;]
**identifier_type** | **string** | The type of the identifier of the related material; defaults to &#39;URL&#39; | [optional] [default to &#39;URL&#39;]
**is_linkout** | **boolean** | Flag for highlighting this related material in the call-out box | [optional] 
**link** | **string** | The full hyperlink for the identifier | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


