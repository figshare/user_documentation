# WWW::SwaggerClient::Object::Category

## Load the model package
```perl
use WWW::SwaggerClient::Object::Category;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **int** | Parent category | [optional] 
**id** | **int** | Category id | [optional] 
**title** | **string** | Category title | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


