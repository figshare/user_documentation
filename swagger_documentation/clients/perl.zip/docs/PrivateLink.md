# WWW::SwaggerClient::Object::PrivateLink

## Load the model package
```perl
use WWW::SwaggerClient::Object::PrivateLink;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | Private link id | [optional] 
**is_active** | **boolean** | True if private link is active | [optional] 
**expires_date** | **string** | Date when link will expire | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


