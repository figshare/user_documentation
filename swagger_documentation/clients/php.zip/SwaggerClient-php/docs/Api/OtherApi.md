# Swagger\Client\OtherApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categoriesList**](OtherApi.md#categoriesList) | **GET** /categories | Public Categories
[**fileDownload**](OtherApi.md#fileDownload) | **GET** /file/download/{file_id} | Public File Download
[**licensesList**](OtherApi.md#licensesList) | **GET** /licenses | Public Licenses
[**privateAccount**](OtherApi.md#privateAccount) | **GET** /account | Private Account information
[**privateLicensesList**](OtherApi.md#privateLicensesList) | **GET** /account/licenses | Private Account Licenses


# **categoriesList**
> \Swagger\Client\Model\Category[] categoriesList()

Public Categories

Returns a list of public categories

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\OtherApi();

try {
    $result = $api_instance->categoriesList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OtherApi->categoriesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Category[]**](../Model/Category.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **fileDownload**
> fileDownload($file_id)

Public File Download

Starts the download of a file

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\OtherApi();
$file_id = 789; // int | 

try {
    $api_instance->fileDownload($file_id);
} catch (Exception $e) {
    echo 'Exception when calling OtherApi->fileDownload: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **file_id** | **int**|  |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/force-download

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **licensesList**
> \Swagger\Client\Model\License[] licensesList()

Public Licenses

Returns a list of public licenses

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\OtherApi();

try {
    $result = $api_instance->licensesList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OtherApi->licensesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\License[]**](../Model/License.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateAccount**
> \Swagger\Client\Model\Account privateAccount()

Private Account information

Account information for token/personal token

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\OtherApi();

try {
    $result = $api_instance->privateAccount();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OtherApi->privateAccount: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Account**](../Model/Account.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateLicensesList**
> \Swagger\Client\Model\License[] privateLicensesList()

Private Account Licenses

This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\OtherApi();

try {
    $result = $api_instance->privateLicensesList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OtherApi->privateLicensesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\License[]**](../Model/License.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

