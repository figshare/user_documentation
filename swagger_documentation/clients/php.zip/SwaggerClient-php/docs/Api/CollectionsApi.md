# Swagger\Client\CollectionsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**collectionArticles**](CollectionsApi.md#collectionArticles) | **GET** /collections/{collection_id}/articles | Public Collection Articles
[**collectionDetails**](CollectionsApi.md#collectionDetails) | **GET** /collections/{collection_id} | Collection details
[**collectionVersionDetails**](CollectionsApi.md#collectionVersionDetails) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details
[**collectionVersions**](CollectionsApi.md#collectionVersions) | **GET** /collections/{collection_id}/versions | Collection Versions list
[**collectionsList**](CollectionsApi.md#collectionsList) | **GET** /collections | Public Collections
[**collectionsSearch**](CollectionsApi.md#collectionsSearch) | **POST** /collections/search | Public Collections Search
[**privateCollectionArticleDelete**](CollectionsApi.md#privateCollectionArticleDelete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article
[**privateCollectionArticlesAdd**](CollectionsApi.md#privateCollectionArticlesAdd) | **POST** /account/collections/{collection_id}/articles | Add collection articles
[**privateCollectionArticlesList**](CollectionsApi.md#privateCollectionArticlesList) | **GET** /account/collections/{collection_id}/articles | List collection articles
[**privateCollectionArticlesReplace**](CollectionsApi.md#privateCollectionArticlesReplace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles
[**privateCollectionAuthorDelete**](CollectionsApi.md#privateCollectionAuthorDelete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author
[**privateCollectionAuthorsAdd**](CollectionsApi.md#privateCollectionAuthorsAdd) | **POST** /account/collections/{collection_id}/authors | Add collection authors
[**privateCollectionAuthorsList**](CollectionsApi.md#privateCollectionAuthorsList) | **GET** /account/collections/{collection_id}/authors | List collection authors
[**privateCollectionAuthorsReplace**](CollectionsApi.md#privateCollectionAuthorsReplace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors
[**privateCollectionCategoriesAdd**](CollectionsApi.md#privateCollectionCategoriesAdd) | **POST** /account/collections/{collection_id}/categories | Add collection categories
[**privateCollectionCategoriesList**](CollectionsApi.md#privateCollectionCategoriesList) | **GET** /account/collections/{collection_id}/categories | List collection categories
[**privateCollectionCategoriesReplace**](CollectionsApi.md#privateCollectionCategoriesReplace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories
[**privateCollectionCategoryDelete**](CollectionsApi.md#privateCollectionCategoryDelete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category
[**privateCollectionCreate**](CollectionsApi.md#privateCollectionCreate) | **POST** /account/collections | Create collection
[**privateCollectionDelete**](CollectionsApi.md#privateCollectionDelete) | **DELETE** /account/collections/{collection_id} | Delete collection
[**privateCollectionDetails**](CollectionsApi.md#privateCollectionDetails) | **GET** /account/collections/{collection_id} | Collection details
[**privateCollectionPrivateLinkCreate**](CollectionsApi.md#privateCollectionPrivateLinkCreate) | **POST** /account/collections/{collection_id}/private_links | Create collection private link
[**privateCollectionPrivateLinkDelete**](CollectionsApi.md#privateCollectionPrivateLinkDelete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link
[**privateCollectionPrivateLinkUpdate**](CollectionsApi.md#privateCollectionPrivateLinkUpdate) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link
[**privateCollectionPrivateLinksList**](CollectionsApi.md#privateCollectionPrivateLinksList) | **GET** /account/collections/{collection_id}/private_links | List collection private links
[**privateCollectionPublish**](CollectionsApi.md#privateCollectionPublish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish
[**privateCollectionReserveDoi**](CollectionsApi.md#privateCollectionReserveDoi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI
[**privateCollectionReserveHandle**](CollectionsApi.md#privateCollectionReserveHandle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle
[**privateCollectionResource**](CollectionsApi.md#privateCollectionResource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource
[**privateCollectionUpdate**](CollectionsApi.md#privateCollectionUpdate) | **PUT** /account/collections/{collection_id} | Update collection
[**privateCollectionsList**](CollectionsApi.md#privateCollectionsList) | **GET** /account/collections | Private Collections List
[**privateCollectionsSearch**](CollectionsApi.md#privateCollectionsSearch) | **POST** /account/collections/search | Private Collections Search


# **collectionArticles**
> \Swagger\Client\Model\Article[] collectionArticles($collection_id, $page, $page_size, $limit, $offset)

Public Collection Articles

Returns a list of public collection articles

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing(the offset of the first result). Used for pagination with limit

try {
    $result = $api_instance->collectionArticles($collection_id, $page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionArticles: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **collectionDetails**
> \Swagger\Client\Model\CollectionComplete collectionDetails($collection_id)

Collection details

View a collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier

try {
    $result = $api_instance->collectionDetails($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |

### Return type

[**\Swagger\Client\Model\CollectionComplete**](../Model/CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **collectionVersionDetails**
> \Swagger\Client\Model\CollectionComplete collectionVersionDetails($collection_id, $version_id)

Collection Version details

View details for a certain version of a collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier
$version_id = 789; // int | Version Number

try {
    $result = $api_instance->collectionVersionDetails($collection_id, $version_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionVersionDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |
 **version_id** | **int**| Version Number |

### Return type

[**\Swagger\Client\Model\CollectionComplete**](../Model/CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **collectionVersions**
> \Swagger\Client\Model\CollectionVersions[] collectionVersions($collection_id)

Collection Versions list

Returns a list of public collection Versions

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier

try {
    $result = $api_instance->collectionVersions($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionVersions: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |

### Return type

[**\Swagger\Client\Model\CollectionVersions[]**](../Model/CollectionVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **collectionsList**
> \Swagger\Client\Model\Collection[] collectionsList($page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $modified_since, $group, $resource_doi, $doi, $handle)

Public Collections

Returns a list of public collections

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing(the offset of the first result). Used for pagination with limit
$order = "published_date"; // string | The field by which to order. Default varies by endpoint/resource.
$order_direction = "desc"; // string | 
$institution = 789; // int | only return collections from this institution
$published_since = "published_since_example"; // string | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
$modified_since = "modified_since_example"; // string | Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
$group = 789; // int | only return collections from this group
$resource_doi = "resource_doi_example"; // string | only return collections with this resource_doi
$doi = "doi_example"; // string | only return collections with this doi
$handle = "handle_example"; // string | only return collections with this handle

try {
    $result = $api_instance->collectionsList($page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $modified_since, $group, $resource_doi, $doi, $handle);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]
 **institution** | **int**| only return collections from this institution | [optional]
 **published_since** | **string**| Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional]
 **modified_since** | **string**| Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional]
 **group** | **int**| only return collections from this group | [optional]
 **resource_doi** | **string**| only return collections with this resource_doi | [optional]
 **doi** | **string**| only return collections with this doi | [optional]
 **handle** | **string**| only return collections with this handle | [optional]

### Return type

[**\Swagger\Client\Model\Collection[]**](../Model/Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **collectionsSearch**
> \Swagger\Client\Model\Collection[] collectionsSearch($search)

Public Collections Search

Returns a list of public collections

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$search = new \Swagger\Client\Model\CollectionSearch(); // \Swagger\Client\Model\CollectionSearch | Search Parameters

try {
    $result = $api_instance->collectionsSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionsSearch: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**\Swagger\Client\Model\CollectionSearch**](../Model/CollectionSearch.md)| Search Parameters | [optional]

### Return type

[**\Swagger\Client\Model\Collection[]**](../Model/Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionArticleDelete**
> privateCollectionArticleDelete($collection_id, $article_id)

Delete collection article

De-associate article from collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$article_id = 789; // int | Collection article unique identifier

try {
    $api_instance->privateCollectionArticleDelete($collection_id, $article_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionArticleDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **article_id** | **int**| Collection article unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionArticlesAdd**
> \Swagger\Client\Model\Location privateCollectionArticlesAdd($collection_id, $articles)

Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$articles = new \Swagger\Client\Model\ArticlesCreator(); // \Swagger\Client\Model\ArticlesCreator | Articles list

try {
    $result = $api_instance->privateCollectionArticlesAdd($collection_id, $articles);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionArticlesAdd: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **articles** | [**\Swagger\Client\Model\ArticlesCreator**](../Model/ArticlesCreator.md)| Articles list |

### Return type

[**\Swagger\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionArticlesList**
> \Swagger\Client\Model\Article[] privateCollectionArticlesList($collection_id)

List collection articles

List collection articles

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier

try {
    $result = $api_instance->privateCollectionArticlesList($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionArticlesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionArticlesReplace**
> privateCollectionArticlesReplace($collection_id, $articles)

Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$articles = new \Swagger\Client\Model\ArticlesCreator(); // \Swagger\Client\Model\ArticlesCreator | Articles List

try {
    $api_instance->privateCollectionArticlesReplace($collection_id, $articles);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionArticlesReplace: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **articles** | [**\Swagger\Client\Model\ArticlesCreator**](../Model/ArticlesCreator.md)| Articles List |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionAuthorDelete**
> privateCollectionAuthorDelete($collection_id, $author_id)

Delete collection author

Delete collection author

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$author_id = 789; // int | Collection Author unique identifier

try {
    $api_instance->privateCollectionAuthorDelete($collection_id, $author_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionAuthorDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **author_id** | **int**| Collection Author unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionAuthorsAdd**
> \Swagger\Client\Model\Location privateCollectionAuthorsAdd($collection_id, $authors)

Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$authors = new \Swagger\Client\Model\AuthorsCreator(); // \Swagger\Client\Model\AuthorsCreator | List of authors

try {
    $result = $api_instance->privateCollectionAuthorsAdd($collection_id, $authors);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionAuthorsAdd: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **authors** | [**\Swagger\Client\Model\AuthorsCreator**](../Model/AuthorsCreator.md)| List of authors |

### Return type

[**\Swagger\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionAuthorsList**
> \Swagger\Client\Model\Author[] privateCollectionAuthorsList($collection_id)

List collection authors

List collection authors

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier

try {
    $result = $api_instance->privateCollectionAuthorsList($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionAuthorsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |

### Return type

[**\Swagger\Client\Model\Author[]**](../Model/Author.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionAuthorsReplace**
> privateCollectionAuthorsReplace($collection_id, $authors)

Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$authors = new \Swagger\Client\Model\AuthorsCreator(); // \Swagger\Client\Model\AuthorsCreator | List of authors

try {
    $api_instance->privateCollectionAuthorsReplace($collection_id, $authors);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionAuthorsReplace: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **authors** | [**\Swagger\Client\Model\AuthorsCreator**](../Model/AuthorsCreator.md)| List of authors |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionCategoriesAdd**
> \Swagger\Client\Model\Location privateCollectionCategoriesAdd($collection_id, $categories)

Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$categories = new \Swagger\Client\Model\CategoriesCreator(); // \Swagger\Client\Model\CategoriesCreator | Categories list

try {
    $result = $api_instance->privateCollectionCategoriesAdd($collection_id, $categories);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCategoriesAdd: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **categories** | [**\Swagger\Client\Model\CategoriesCreator**](../Model/CategoriesCreator.md)| Categories list |

### Return type

[**\Swagger\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionCategoriesList**
> \Swagger\Client\Model\Category[] privateCollectionCategoriesList($collection_id)

List collection categories

List collection categories

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier

try {
    $result = $api_instance->privateCollectionCategoriesList($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCategoriesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |

### Return type

[**\Swagger\Client\Model\Category[]**](../Model/Category.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionCategoriesReplace**
> privateCollectionCategoriesReplace($collection_id, $categories)

Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$categories = new \Swagger\Client\Model\CategoriesCreator(); // \Swagger\Client\Model\CategoriesCreator | Categories list

try {
    $api_instance->privateCollectionCategoriesReplace($collection_id, $categories);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCategoriesReplace: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **categories** | [**\Swagger\Client\Model\CategoriesCreator**](../Model/CategoriesCreator.md)| Categories list |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionCategoryDelete**
> privateCollectionCategoryDelete($collection_id, $category_id)

Delete collection category

De-associate category from collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$category_id = 789; // int | Collection category unique identifier

try {
    $api_instance->privateCollectionCategoryDelete($collection_id, $category_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCategoryDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **category_id** | **int**| Collection category unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionCreate**
> \Swagger\Client\Model\LocationWarnings privateCollectionCreate($collection)

Create collection

Create a new Collection by sending collection information

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection = new \Swagger\Client\Model\CollectionCreate(); // \Swagger\Client\Model\CollectionCreate | Collection description

try {
    $result = $api_instance->privateCollectionCreate($collection);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection** | [**\Swagger\Client\Model\CollectionCreate**](../Model/CollectionCreate.md)| Collection description |

### Return type

[**\Swagger\Client\Model\LocationWarnings**](../Model/LocationWarnings.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionDelete**
> privateCollectionDelete($collection_id)

Delete collection

Delete n collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier

try {
    $api_instance->privateCollectionDelete($collection_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionDetails**
> \Swagger\Client\Model\CollectionCompletePrivate privateCollectionDetails($collection_id)

Collection details

View a collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier

try {
    $result = $api_instance->privateCollectionDetails($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |

### Return type

[**\Swagger\Client\Model\CollectionCompletePrivate**](../Model/CollectionCompletePrivate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionPrivateLinkCreate**
> \Swagger\Client\Model\PrivateLinkResponse privateCollectionPrivateLinkCreate($collection_id, $private_link)

Create collection private link

Create new private link

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$private_link = new \Swagger\Client\Model\CollectionPrivateLinkCreator(); // \Swagger\Client\Model\CollectionPrivateLinkCreator | 

try {
    $result = $api_instance->privateCollectionPrivateLinkCreate($collection_id, $private_link);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPrivateLinkCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **private_link** | [**\Swagger\Client\Model\CollectionPrivateLinkCreator**](../Model/CollectionPrivateLinkCreator.md)|  | [optional]

### Return type

[**\Swagger\Client\Model\PrivateLinkResponse**](../Model/PrivateLinkResponse.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionPrivateLinkDelete**
> privateCollectionPrivateLinkDelete($collection_id, $link_id)

Disable private link

Disable/delete private link for this collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$link_id = "link_id_example"; // string | Private link token

try {
    $api_instance->privateCollectionPrivateLinkDelete($collection_id, $link_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPrivateLinkDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **link_id** | **string**| Private link token |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionPrivateLinkUpdate**
> privateCollectionPrivateLinkUpdate($collection_id, $link_id, $private_link)

Update collection private link

Update existing private link for this collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$link_id = "link_id_example"; // string | Private link token
$private_link = new \Swagger\Client\Model\CollectionPrivateLinkCreator(); // \Swagger\Client\Model\CollectionPrivateLinkCreator | 

try {
    $api_instance->privateCollectionPrivateLinkUpdate($collection_id, $link_id, $private_link);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPrivateLinkUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **link_id** | **string**| Private link token |
 **private_link** | [**\Swagger\Client\Model\CollectionPrivateLinkCreator**](../Model/CollectionPrivateLinkCreator.md)|  | [optional]

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionPrivateLinksList**
> \Swagger\Client\Model\PrivateLink[] privateCollectionPrivateLinksList($collection_id)

List collection private links

List article private links

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier

try {
    $result = $api_instance->privateCollectionPrivateLinksList($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPrivateLinksList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |

### Return type

[**\Swagger\Client\Model\PrivateLink[]**](../Model/PrivateLink.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionPublish**
> \Swagger\Client\Model\Location privateCollectionPublish($collection_id)

Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier

try {
    $result = $api_instance->privateCollectionPublish($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPublish: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |

### Return type

[**\Swagger\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionReserveDoi**
> \Swagger\Client\Model\CollectionDOI privateCollectionReserveDoi($collection_id)

Private Collection Reserve DOI

Reserve DOI for collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier

try {
    $result = $api_instance->privateCollectionReserveDoi($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionReserveDoi: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |

### Return type

[**\Swagger\Client\Model\CollectionDOI**](../Model/CollectionDOI.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionReserveHandle**
> \Swagger\Client\Model\CollectionHandle privateCollectionReserveHandle($collection_id)

Private Collection Reserve Handle

Reserve Handle for collection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier

try {
    $result = $api_instance->privateCollectionReserveHandle($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionReserveHandle: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |

### Return type

[**\Swagger\Client\Model\CollectionHandle**](../Model/CollectionHandle.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionResource**
> privateCollectionResource($collection_id, $resource)

Private Collection Resource

Edit collection resource data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection unique identifier
$resource = new \Swagger\Client\Model\Resource(); // \Swagger\Client\Model\Resource | Resource data

try {
    $api_instance->privateCollectionResource($collection_id, $resource);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionResource: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier |
 **resource** | [**\Swagger\Client\Model\Resource**](../Model/Resource.md)| Resource data |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionUpdate**
> \Swagger\Client\Model\LocationWarningsUpdate privateCollectionUpdate($collection_id, $collection)

Update collection

Update collection details; request can also be made with the PATCH method.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$collection_id = 789; // int | Collection Unique identifier
$collection = new \Swagger\Client\Model\CollectionUpdate(); // \Swagger\Client\Model\CollectionUpdate | Collection description

try {
    $result = $api_instance->privateCollectionUpdate($collection_id, $collection);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier |
 **collection** | [**\Swagger\Client\Model\CollectionUpdate**](../Model/CollectionUpdate.md)| Collection description |

### Return type

[**\Swagger\Client\Model\LocationWarningsUpdate**](../Model/LocationWarningsUpdate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionsList**
> \Swagger\Client\Model\Collection[] privateCollectionsList($page, $page_size, $limit, $offset, $order, $order_direction)

Private Collections List

List private collections

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing(the offset of the first result). Used for pagination with limit
$order = "published_date"; // string | The field by which to order. Default varies by endpoint/resource.
$order_direction = "desc"; // string | 

try {
    $result = $api_instance->privateCollectionsList($page, $page_size, $limit, $offset, $order, $order_direction);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]

### Return type

[**\Swagger\Client\Model\Collection[]**](../Model/Collection.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCollectionsSearch**
> \Swagger\Client\Model\Collection[] privateCollectionsSearch($search)

Private Collections Search

Returns a list of private Collections

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\CollectionsApi();
$search = new \Swagger\Client\Model\PrivateCollectionSearch(); // \Swagger\Client\Model\PrivateCollectionSearch | Search Parameters

try {
    $result = $api_instance->privateCollectionsSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionsSearch: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**\Swagger\Client\Model\PrivateCollectionSearch**](../Model/PrivateCollectionSearch.md)| Search Parameters |

### Return type

[**\Swagger\Client\Model\Collection[]**](../Model/Collection.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

