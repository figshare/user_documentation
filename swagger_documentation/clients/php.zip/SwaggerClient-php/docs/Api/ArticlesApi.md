# Swagger\Client\ArticlesApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**accountArticleReport**](ArticlesApi.md#accountArticleReport) | **GET** /account/articles/export | Account Article Report
[**accountArticleReportGenerate**](ArticlesApi.md#accountArticleReportGenerate) | **POST** /account/articles/export | Initiate a new Report
[**articleDetails**](ArticlesApi.md#articleDetails) | **GET** /articles/{article_id} | View article details
[**articleFileDetails**](ArticlesApi.md#articleFileDetails) | **GET** /articles/{article_id}/files/{file_id} | Article file details
[**articleFiles**](ArticlesApi.md#articleFiles) | **GET** /articles/{article_id}/files | List article files
[**articleVersionConfidentiality**](ArticlesApi.md#articleVersionConfidentiality) | **GET** /articles/{article_id}/versions/{v_number}/confidentiality | Public Article Confidentiality for article version
[**articleVersionDetails**](ArticlesApi.md#articleVersionDetails) | **GET** /articles/{article_id}/versions/{v_number} | Article details for version
[**articleVersionEmbargo**](ArticlesApi.md#articleVersionEmbargo) | **GET** /articles/{article_id}/versions/{v_number}/embargo | Public Article Embargo for article version
[**articleVersionUpdate**](ArticlesApi.md#articleVersionUpdate) | **PUT** /account/articles/{article_id}/versions/{version_id}/ | Update article version
[**articleVersionUpdateThumb**](ArticlesApi.md#articleVersionUpdateThumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail
[**articleVersions**](ArticlesApi.md#articleVersions) | **GET** /articles/{article_id}/versions | List article versions
[**articlesList**](ArticlesApi.md#articlesList) | **GET** /articles | Public Articles
[**articlesSearch**](ArticlesApi.md#articlesSearch) | **POST** /articles/search | Public Articles Search
[**privateArticleAuthorDelete**](ArticlesApi.md#privateArticleAuthorDelete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author
[**privateArticleAuthorsAdd**](ArticlesApi.md#privateArticleAuthorsAdd) | **POST** /account/articles/{article_id}/authors | Add article authors
[**privateArticleAuthorsList**](ArticlesApi.md#privateArticleAuthorsList) | **GET** /account/articles/{article_id}/authors | List article authors
[**privateArticleAuthorsReplace**](ArticlesApi.md#privateArticleAuthorsReplace) | **PUT** /account/articles/{article_id}/authors | Replace article authors
[**privateArticleCategoriesAdd**](ArticlesApi.md#privateArticleCategoriesAdd) | **POST** /account/articles/{article_id}/categories | Add article categories
[**privateArticleCategoriesList**](ArticlesApi.md#privateArticleCategoriesList) | **GET** /account/articles/{article_id}/categories | List article categories
[**privateArticleCategoriesReplace**](ArticlesApi.md#privateArticleCategoriesReplace) | **PUT** /account/articles/{article_id}/categories | Replace article categories
[**privateArticleCategoryDelete**](ArticlesApi.md#privateArticleCategoryDelete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category
[**privateArticleConfidentialityDelete**](ArticlesApi.md#privateArticleConfidentialityDelete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality
[**privateArticleConfidentialityDetails**](ArticlesApi.md#privateArticleConfidentialityDetails) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details
[**privateArticleConfidentialityUpdate**](ArticlesApi.md#privateArticleConfidentialityUpdate) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality
[**privateArticleCreate**](ArticlesApi.md#privateArticleCreate) | **POST** /account/articles | Create new Article
[**privateArticleDelete**](ArticlesApi.md#privateArticleDelete) | **DELETE** /account/articles/{article_id} | Delete article
[**privateArticleDetails**](ArticlesApi.md#privateArticleDetails) | **GET** /account/articles/{article_id} | Article details
[**privateArticleEmbargoDelete**](ArticlesApi.md#privateArticleEmbargoDelete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo
[**privateArticleEmbargoDetails**](ArticlesApi.md#privateArticleEmbargoDetails) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details
[**privateArticleEmbargoUpdate**](ArticlesApi.md#privateArticleEmbargoUpdate) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo
[**privateArticleFile**](ArticlesApi.md#privateArticleFile) | **GET** /account/articles/{article_id}/files/{file_id} | Single File
[**privateArticleFileDelete**](ArticlesApi.md#privateArticleFileDelete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete
[**privateArticleFilesList**](ArticlesApi.md#privateArticleFilesList) | **GET** /account/articles/{article_id}/files | List article files
[**privateArticlePrivateLink**](ArticlesApi.md#privateArticlePrivateLink) | **GET** /account/articles/{article_id}/private_links | List private links
[**privateArticlePrivateLinkCreate**](ArticlesApi.md#privateArticlePrivateLinkCreate) | **POST** /account/articles/{article_id}/private_links | Create private link
[**privateArticlePrivateLinkDelete**](ArticlesApi.md#privateArticlePrivateLinkDelete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link
[**privateArticlePrivateLinkUpdate**](ArticlesApi.md#privateArticlePrivateLinkUpdate) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link
[**privateArticlePublish**](ArticlesApi.md#privateArticlePublish) | **POST** /account/articles/{article_id}/publish | Private Article Publish
[**privateArticleReserveDoi**](ArticlesApi.md#privateArticleReserveDoi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI
[**privateArticleReserveHandle**](ArticlesApi.md#privateArticleReserveHandle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle
[**privateArticleResource**](ArticlesApi.md#privateArticleResource) | **POST** /account/articles/{article_id}/resource | Private Article Resource
[**privateArticleUpdate**](ArticlesApi.md#privateArticleUpdate) | **PUT** /account/articles/{article_id} | Update article
[**privateArticleUploadComplete**](ArticlesApi.md#privateArticleUploadComplete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload
[**privateArticleUploadInitiate**](ArticlesApi.md#privateArticleUploadInitiate) | **POST** /account/articles/{article_id}/files | Initiate Upload
[**privateArticlesList**](ArticlesApi.md#privateArticlesList) | **GET** /account/articles | Private Articles
[**privateArticlesSearch**](ArticlesApi.md#privateArticlesSearch) | **POST** /account/articles/search | Private Articles search


# **accountArticleReport**
> \Swagger\Client\Model\AccountReport[] accountArticleReport($group_id)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$group_id = 789; // int | A group ID to filter by

try {
    $result = $api_instance->accountArticleReport($group_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->accountArticleReport: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| A group ID to filter by | [optional]

### Return type

[**\Swagger\Client\Model\AccountReport[]**](../Model/AccountReport.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **accountArticleReportGenerate**
> \Swagger\Client\Model\AccountReport accountArticleReportGenerate()

Initiate a new Report

Initiate a new Article Report for this Account

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();

try {
    $result = $api_instance->accountArticleReportGenerate();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->accountArticleReportGenerate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\AccountReport**](../Model/AccountReport.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articleDetails**
> \Swagger\Client\Model\ArticleComplete articleDetails($article_id)

View article details

View an article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article Unique identifier

try {
    $result = $api_instance->articleDetails($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier |

### Return type

[**\Swagger\Client\Model\ArticleComplete**](../Model/ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articleFileDetails**
> \Swagger\Client\Model\PublicFile articleFileDetails($article_id, $file_id)

Article file details

File by id

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article Unique identifier
$file_id = 789; // int | File Unique identifier

try {
    $result = $api_instance->articleFileDetails($article_id, $file_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleFileDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier |
 **file_id** | **int**| File Unique identifier |

### Return type

[**\Swagger\Client\Model\PublicFile**](../Model/PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articleFiles**
> \Swagger\Client\Model\PublicFile[] articleFiles($article_id)

List article files

Files list for article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article Unique identifier

try {
    $result = $api_instance->articleFiles($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleFiles: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier |

### Return type

[**\Swagger\Client\Model\PublicFile[]**](../Model/PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articleVersionConfidentiality**
> \Swagger\Client\Model\ArticleConfidentiality articleVersionConfidentiality($article_id, $v_number)

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article Unique identifier
$v_number = 789; // int | Version Number

try {
    $result = $api_instance->articleVersionConfidentiality($article_id, $v_number);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionConfidentiality: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier |
 **v_number** | **int**| Version Number |

### Return type

[**\Swagger\Client\Model\ArticleConfidentiality**](../Model/ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articleVersionDetails**
> \Swagger\Client\Model\ArticleComplete articleVersionDetails($article_id, $v_number)

Article details for version

Article with specified version

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article Unique identifier
$v_number = 789; // int | Article Version Number

try {
    $result = $api_instance->articleVersionDetails($article_id, $v_number);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier |
 **v_number** | **int**| Article Version Number |

### Return type

[**\Swagger\Client\Model\ArticleComplete**](../Model/ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articleVersionEmbargo**
> \Swagger\Client\Model\ArticleEmbargo articleVersionEmbargo($article_id, $v_number)

Public Article Embargo for article version

Embargo for article version

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article Unique identifier
$v_number = 789; // int | Version Number

try {
    $result = $api_instance->articleVersionEmbargo($article_id, $v_number);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionEmbargo: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier |
 **v_number** | **int**| Version Number |

### Return type

[**\Swagger\Client\Model\ArticleEmbargo**](../Model/ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articleVersionUpdate**
> \Swagger\Client\Model\LocationWarnings articleVersionUpdate($article_id, $version_id, $article)

Update article version

Updating an article version by passing body parameters; request can also be made with the PATCH method.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$version_id = 789; // int | Article version identifier
$article = new \Swagger\Client\Model\ArticleUpdate(); // \Swagger\Client\Model\ArticleUpdate | Article description

try {
    $result = $api_instance->articleVersionUpdate($article_id, $version_id, $article);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **version_id** | **int**| Article version identifier |
 **article** | [**\Swagger\Client\Model\ArticleUpdate**](../Model/ArticleUpdate.md)| Article description |

### Return type

[**\Swagger\Client\Model\LocationWarnings**](../Model/LocationWarnings.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articleVersionUpdateThumb**
> articleVersionUpdateThumb($article_id, $version_id, $file_id)

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$version_id = 789; // int | Article version identifier
$file_id = new \Swagger\Client\Model\FileId(); // \Swagger\Client\Model\FileId | File ID

try {
    $api_instance->articleVersionUpdateThumb($article_id, $version_id, $file_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersionUpdateThumb: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **version_id** | **int**| Article version identifier |
 **file_id** | [**\Swagger\Client\Model\FileId**](../Model/FileId.md)| File ID |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articleVersions**
> \Swagger\Client\Model\ArticleVersions[] articleVersions($article_id)

List article versions

List public article versions

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article Unique identifier

try {
    $result = $api_instance->articleVersions($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articleVersions: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier |

### Return type

[**\Swagger\Client\Model\ArticleVersions[]**](../Model/ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articlesList**
> \Swagger\Client\Model\Article[] articlesList($page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $modified_since, $group, $resource_doi, $item_type, $doi, $handle)

Public Articles

Returns a list of public articles

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing(the offset of the first result). Used for pagination with limit
$order = "published_date"; // string | The field by which to order. Default varies by endpoint/resource.
$order_direction = "desc"; // string | 
$institution = 789; // int | only return articles from this institution
$published_since = "published_since_example"; // string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
$modified_since = "modified_since_example"; // string | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
$group = 789; // int | only return articles from this group
$resource_doi = "resource_doi_example"; // string | only return articles with this resource_doi
$item_type = 789; // int | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
$doi = "doi_example"; // string | only return articles with this doi
$handle = "handle_example"; // string | only return articles with this handle

try {
    $result = $api_instance->articlesList($page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $modified_since, $group, $resource_doi, $item_type, $doi, $handle);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articlesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]
 **institution** | **int**| only return articles from this institution | [optional]
 **published_since** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional]
 **modified_since** | **string**| Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional]
 **group** | **int**| only return articles from this group | [optional]
 **resource_doi** | **string**| only return articles with this resource_doi | [optional]
 **item_type** | **int**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional]
 **doi** | **string**| only return articles with this doi | [optional]
 **handle** | **string**| only return articles with this handle | [optional]

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **articlesSearch**
> \Swagger\Client\Model\Article[] articlesSearch($search)

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$search = new \Swagger\Client\Model\ArticleSearch(); // \Swagger\Client\Model\ArticleSearch | Search Parameters

try {
    $result = $api_instance->articlesSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->articlesSearch: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**\Swagger\Client\Model\ArticleSearch**](../Model/ArticleSearch.md)| Search Parameters | [optional]

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleAuthorDelete**
> privateArticleAuthorDelete($article_id, $author_id)

Delete article author

De-associate author from article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$author_id = 789; // int | Article Author unique identifier

try {
    $api_instance->privateArticleAuthorDelete($article_id, $author_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleAuthorDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **author_id** | **int**| Article Author unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleAuthorsAdd**
> privateArticleAuthorsAdd($article_id, $authors)

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$authors = new \Swagger\Client\Model\AuthorsCreator(); // \Swagger\Client\Model\AuthorsCreator | Authors description

try {
    $api_instance->privateArticleAuthorsAdd($article_id, $authors);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleAuthorsAdd: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **authors** | [**\Swagger\Client\Model\AuthorsCreator**](../Model/AuthorsCreator.md)| Authors description |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleAuthorsList**
> \Swagger\Client\Model\Author[] privateArticleAuthorsList($article_id)

List article authors

List article authors

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticleAuthorsList($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleAuthorsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\Author[]**](../Model/Author.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleAuthorsReplace**
> privateArticleAuthorsReplace($article_id, $authors)

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$authors = new \Swagger\Client\Model\AuthorsCreator(); // \Swagger\Client\Model\AuthorsCreator | Authors description

try {
    $api_instance->privateArticleAuthorsReplace($article_id, $authors);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleAuthorsReplace: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **authors** | [**\Swagger\Client\Model\AuthorsCreator**](../Model/AuthorsCreator.md)| Authors description |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleCategoriesAdd**
> privateArticleCategoriesAdd($article_id, $categories)

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$categories = new \Swagger\Client\Model\CategoriesCreator(); // \Swagger\Client\Model\CategoriesCreator | 

try {
    $api_instance->privateArticleCategoriesAdd($article_id, $categories);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCategoriesAdd: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **categories** | [**\Swagger\Client\Model\CategoriesCreator**](../Model/CategoriesCreator.md)|  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleCategoriesList**
> \Swagger\Client\Model\Category[] privateArticleCategoriesList($article_id)

List article categories

List article categories

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticleCategoriesList($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCategoriesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\Category[]**](../Model/Category.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleCategoriesReplace**
> privateArticleCategoriesReplace($article_id, $categories)

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$categories = new \Swagger\Client\Model\CategoriesCreator(); // \Swagger\Client\Model\CategoriesCreator | 

try {
    $api_instance->privateArticleCategoriesReplace($article_id, $categories);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCategoriesReplace: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **categories** | [**\Swagger\Client\Model\CategoriesCreator**](../Model/CategoriesCreator.md)|  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleCategoryDelete**
> privateArticleCategoryDelete($article_id, $category_id)

Delete article category

De-associate category from article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$category_id = 789; // int | Category unique identifier

try {
    $api_instance->privateArticleCategoryDelete($article_id, $category_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCategoryDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **category_id** | **int**| Category unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleConfidentialityDelete**
> privateArticleConfidentialityDelete($article_id)

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $api_instance->privateArticleConfidentialityDelete($article_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleConfidentialityDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleConfidentialityDetails**
> \Swagger\Client\Model\ArticleConfidentiality privateArticleConfidentialityDetails($article_id)

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticleConfidentialityDetails($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleConfidentialityDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\ArticleConfidentiality**](../Model/ArticleConfidentiality.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleConfidentialityUpdate**
> privateArticleConfidentialityUpdate($article_id, $reason)

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$reason = new \Swagger\Client\Model\ConfidentialityCreator(); // \Swagger\Client\Model\ConfidentialityCreator | 

try {
    $api_instance->privateArticleConfidentialityUpdate($article_id, $reason);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleConfidentialityUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **reason** | [**\Swagger\Client\Model\ConfidentialityCreator**](../Model/ConfidentialityCreator.md)|  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleCreate**
> \Swagger\Client\Model\LocationWarnings privateArticleCreate($article)

Create new Article

Create a new Article by sending article information

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article = new \Swagger\Client\Model\ArticleCreate(); // \Swagger\Client\Model\ArticleCreate | Article description

try {
    $result = $api_instance->privateArticleCreate($article);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article** | [**\Swagger\Client\Model\ArticleCreate**](../Model/ArticleCreate.md)| Article description |

### Return type

[**\Swagger\Client\Model\LocationWarnings**](../Model/LocationWarnings.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleDelete**
> privateArticleDelete($article_id)

Delete article

Delete an article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $api_instance->privateArticleDelete($article_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleDetails**
> \Swagger\Client\Model\ArticleCompletePrivate privateArticleDetails($article_id)

Article details

View a private article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticleDetails($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\ArticleCompletePrivate**](../Model/ArticleCompletePrivate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleEmbargoDelete**
> privateArticleEmbargoDelete($article_id)

Delete Article Embargo

Will lift the embargo for the specified article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $api_instance->privateArticleEmbargoDelete($article_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleEmbargoDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleEmbargoDetails**
> \Swagger\Client\Model\ArticleEmbargo privateArticleEmbargoDetails($article_id)

Article Embargo Details

View a private article embargo details

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticleEmbargoDetails($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleEmbargoDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\ArticleEmbargo**](../Model/ArticleEmbargo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleEmbargoUpdate**
> privateArticleEmbargoUpdate($article_id, $embargo)

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$embargo = new \Swagger\Client\Model\ArticleEmbargoUpdater(); // \Swagger\Client\Model\ArticleEmbargoUpdater | Embargo description

try {
    $api_instance->privateArticleEmbargoUpdate($article_id, $embargo);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleEmbargoUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **embargo** | [**\Swagger\Client\Model\ArticleEmbargoUpdater**](../Model/ArticleEmbargoUpdater.md)| Embargo description |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleFile**
> \Swagger\Client\Model\PrivateFile privateArticleFile($article_id, $file_id)

Single File

View details of file for specified article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$file_id = 789; // int | File unique identifier

try {
    $result = $api_instance->privateArticleFile($article_id, $file_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleFile: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **file_id** | **int**| File unique identifier |

### Return type

[**\Swagger\Client\Model\PrivateFile**](../Model/PrivateFile.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleFileDelete**
> privateArticleFileDelete($article_id, $file_id)

File Delete

Complete file upload

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$file_id = 789; // int | File unique identifier

try {
    $api_instance->privateArticleFileDelete($article_id, $file_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleFileDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **file_id** | **int**| File unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleFilesList**
> \Swagger\Client\Model\PrivateFile[] privateArticleFilesList($article_id)

List article files

List private files

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticleFilesList($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleFilesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\PrivateFile[]**](../Model/PrivateFile.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticlePrivateLink**
> \Swagger\Client\Model\PrivateLink[] privateArticlePrivateLink($article_id)

List private links

List private links

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticlePrivateLink($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePrivateLink: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\PrivateLink[]**](../Model/PrivateLink.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticlePrivateLinkCreate**
> \Swagger\Client\Model\Location privateArticlePrivateLinkCreate($article_id, $private_link)

Create private link

Create new private link for this article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$private_link = new \Swagger\Client\Model\PrivateLinkCreator(); // \Swagger\Client\Model\PrivateLinkCreator | 

try {
    $result = $api_instance->privateArticlePrivateLinkCreate($article_id, $private_link);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePrivateLinkCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **private_link** | [**\Swagger\Client\Model\PrivateLinkCreator**](../Model/PrivateLinkCreator.md)|  | [optional]

### Return type

[**\Swagger\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticlePrivateLinkDelete**
> privateArticlePrivateLinkDelete($article_id, $link_id)

Disable private link

Disable/delete private link for this article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$link_id = "link_id_example"; // string | Private link token

try {
    $api_instance->privateArticlePrivateLinkDelete($article_id, $link_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePrivateLinkDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **link_id** | **string**| Private link token |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticlePrivateLinkUpdate**
> privateArticlePrivateLinkUpdate($article_id, $link_id, $private_link)

Update private link

Update existing private link for this article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$link_id = "link_id_example"; // string | Private link token
$private_link = new \Swagger\Client\Model\PrivateLinkCreator(); // \Swagger\Client\Model\PrivateLinkCreator | 

try {
    $api_instance->privateArticlePrivateLinkUpdate($article_id, $link_id, $private_link);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePrivateLinkUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **link_id** | **string**| Private link token |
 **private_link** | [**\Swagger\Client\Model\PrivateLinkCreator**](../Model/PrivateLinkCreator.md)|  | [optional]

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticlePublish**
> \Swagger\Client\Model\Location privateArticlePublish($article_id)

Private Article Publish

- If the whole article is under embargo, it will not be published immediatly, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticlePublish($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlePublish: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleReserveDoi**
> \Swagger\Client\Model\ArticleDOI privateArticleReserveDoi($article_id)

Private Article Reserve DOI

Reserve DOI for article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticleReserveDoi($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleReserveDoi: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\ArticleDOI**](../Model/ArticleDOI.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleReserveHandle**
> \Swagger\Client\Model\ArticleHandle privateArticleReserveHandle($article_id)

Private Article Reserve Handle

Reserve Handle for article

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier

try {
    $result = $api_instance->privateArticleReserveHandle($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleReserveHandle: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |

### Return type

[**\Swagger\Client\Model\ArticleHandle**](../Model/ArticleHandle.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleResource**
> privateArticleResource($article_id, $resource)

Private Article Resource

Edit article resource data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$resource = new \Swagger\Client\Model\Resource(); // \Swagger\Client\Model\Resource | Resource data

try {
    $api_instance->privateArticleResource($article_id, $resource);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleResource: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **resource** | [**\Swagger\Client\Model\Resource**](../Model/Resource.md)| Resource data |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleUpdate**
> \Swagger\Client\Model\LocationWarnings privateArticleUpdate($article_id, $article)

Update article

Updating an article by passing body parameters; request can also be made with the PATCH method.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$article = new \Swagger\Client\Model\ArticleUpdate(); // \Swagger\Client\Model\ArticleUpdate | Article description

try {
    $result = $api_instance->privateArticleUpdate($article_id, $article);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **article** | [**\Swagger\Client\Model\ArticleUpdate**](../Model/ArticleUpdate.md)| Article description |

### Return type

[**\Swagger\Client\Model\LocationWarnings**](../Model/LocationWarnings.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleUploadComplete**
> privateArticleUploadComplete($article_id, $file_id)

Complete Upload

Complete file upload

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$file_id = 789; // int | File unique identifier

try {
    $api_instance->privateArticleUploadComplete($article_id, $file_id);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleUploadComplete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **file_id** | **int**| File unique identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticleUploadInitiate**
> \Swagger\Client\Model\Location privateArticleUploadInitiate($article_id, $file)

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$article_id = 789; // int | Article unique identifier
$file = new \Swagger\Client\Model\FileCreator(); // \Swagger\Client\Model\FileCreator | 

try {
    $result = $api_instance->privateArticleUploadInitiate($article_id, $file);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticleUploadInitiate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier |
 **file** | [**\Swagger\Client\Model\FileCreator**](../Model/FileCreator.md)|  |

### Return type

[**\Swagger\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticlesList**
> \Swagger\Client\Model\Article[] privateArticlesList($page, $page_size, $limit, $offset)

Private Articles

Get Own Articles

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing(the offset of the first result). Used for pagination with limit

try {
    $result = $api_instance->privateArticlesList($page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateArticlesSearch**
> \Swagger\Client\Model\Article[] privateArticlesSearch($search)

Private Articles search

Returns a list of private articles filtered by the search parameters

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\ArticlesApi();
$search = new \Swagger\Client\Model\PrivateArticleSearch(); // \Swagger\Client\Model\PrivateArticleSearch | Search Parameters

try {
    $result = $api_instance->privateArticlesSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->privateArticlesSearch: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**\Swagger\Client\Model\PrivateArticleSearch**](../Model/PrivateArticleSearch.md)| Search Parameters |

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

