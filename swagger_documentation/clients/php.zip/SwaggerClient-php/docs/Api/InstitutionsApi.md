# Swagger\Client\InstitutionsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**accountInstitutionCuration**](InstitutionsApi.md#accountInstitutionCuration) | **GET** /account/institution/review/{curation_id} | Institution Curation Review
[**accountInstitutionCurationComments**](InstitutionsApi.md#accountInstitutionCurationComments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments
[**accountInstitutionCurationComments_0**](InstitutionsApi.md#accountInstitutionCurationComments_0) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment
[**accountInstitutionCurations**](InstitutionsApi.md#accountInstitutionCurations) | **GET** /account/institution/reviews | Institution Curation Reviews
[**customFieldsList**](InstitutionsApi.md#customFieldsList) | **GET** /account/institution/custom_fields | Private account institution group custom fields
[**customFieldsUpload**](InstitutionsApi.md#customFieldsUpload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload
[**institutionArticles**](InstitutionsApi.md#institutionArticles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Licenses
[**institutionHrfeedUpload**](InstitutionsApi.md#institutionHrfeedUpload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload
[**privateAccountInstitutionUser**](InstitutionsApi.md#privateAccountInstitutionUser) | **GET** /account/institution/users/{account_id} | Private Account Institution User
[**privateCategoriesList**](InstitutionsApi.md#privateCategoriesList) | **GET** /account/categories | Private Account Categories
[**privateGroupEmbargoOptionsDetails**](InstitutionsApi.md#privateGroupEmbargoOptionsDetails) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options
[**privateInstitutionAccountGroupRoleDelete**](InstitutionsApi.md#privateInstitutionAccountGroupRoleDelete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role
[**privateInstitutionAccountGroupRoles**](InstitutionsApi.md#privateInstitutionAccountGroupRoles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles
[**privateInstitutionAccountGroupRolesCreate**](InstitutionsApi.md#privateInstitutionAccountGroupRolesCreate) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles
[**privateInstitutionAccountsCreate**](InstitutionsApi.md#privateInstitutionAccountsCreate) | **POST** /account/institution/accounts | Create new Institution Account
[**privateInstitutionAccountsList**](InstitutionsApi.md#privateInstitutionAccountsList) | **GET** /account/institution/accounts | Private Account Institution Accounts
[**privateInstitutionAccountsSearch**](InstitutionsApi.md#privateInstitutionAccountsSearch) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search
[**privateInstitutionAccountsUpdate**](InstitutionsApi.md#privateInstitutionAccountsUpdate) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account
[**privateInstitutionArticles**](InstitutionsApi.md#privateInstitutionArticles) | **GET** /account/institution/articles | Private Institution Articles
[**privateInstitutionDetails**](InstitutionsApi.md#privateInstitutionDetails) | **GET** /account/institution | Private Account Institutions
[**privateInstitutionEmbargoOptionsDetails**](InstitutionsApi.md#privateInstitutionEmbargoOptionsDetails) | **GET** /account/institution/embargo_options | Private Account Institution embargo options
[**privateInstitutionGroupsList**](InstitutionsApi.md#privateInstitutionGroupsList) | **GET** /account/institution/groups | Private Account Institution Groups
[**privateInstitutionRolesList**](InstitutionsApi.md#privateInstitutionRolesList) | **GET** /account/institution/roles | Private Account Institution Roles


# **accountInstitutionCuration**
> \Swagger\Client\Model\CurationDetail accountInstitutionCuration($curation_id)

Institution Curation Review

Retrieve a certain curation review by its ID

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$curation_id = 789; // int | ID of the curation

try {
    $result = $api_instance->accountInstitutionCuration($curation_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->accountInstitutionCuration: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curation_id** | **int**| ID of the curation |

### Return type

[**\Swagger\Client\Model\CurationDetail**](../Model/CurationDetail.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **accountInstitutionCurationComments**
> \Swagger\Client\Model\CurationComment accountInstitutionCurationComments($curation_id, $limit, $offset)

Institution Curation Review Comments

Retrieve a certain curation review's comments.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$curation_id = 789; // int | ID of the curation
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing(the offset of the first result). Used for pagination with limit

try {
    $result = $api_instance->accountInstitutionCurationComments($curation_id, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->accountInstitutionCurationComments: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curation_id** | **int**| ID of the curation |
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]

### Return type

[**\Swagger\Client\Model\CurationComment**](../Model/CurationComment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **accountInstitutionCurationComments_0**
> accountInstitutionCurationComments_0($curation_id, $curation_comment)

POST Institution Curation Review Comment

Add a new comment to the review.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$curation_id = 789; // int | ID of the curation
$curation_comment = new \Swagger\Client\Model\CurationCommentCreate(); // \Swagger\Client\Model\CurationCommentCreate | The content/value of the comment.

try {
    $api_instance->accountInstitutionCurationComments_0($curation_id, $curation_comment);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->accountInstitutionCurationComments_0: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curation_id** | **int**| ID of the curation |
 **curation_comment** | [**\Swagger\Client\Model\CurationCommentCreate**](../Model/CurationCommentCreate.md)| The content/value of the comment. |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **accountInstitutionCurations**
> \Swagger\Client\Model\Curation accountInstitutionCurations($group_id, $article_id, $status, $limit, $offset)

Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$group_id = 789; // int | Filter by the group ID
$article_id = 789; // int | Retrieve the reviews for this article
$status = "status_example"; // string | Filter by the status of the review
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing(the offset of the first result). Used for pagination with limit

try {
    $result = $api_instance->accountInstitutionCurations($group_id, $article_id, $status, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->accountInstitutionCurations: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Filter by the group ID | [optional]
 **article_id** | **int**| Retrieve the reviews for this article | [optional]
 **status** | **string**| Filter by the status of the review | [optional]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]

### Return type

[**\Swagger\Client\Model\Curation**](../Model/Curation.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **customFieldsList**
> \Swagger\Client\Model\ShortCustomField[] customFieldsList($group_id)

Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$group_id = 789; // int | Group_id

try {
    $result = $api_instance->customFieldsList($group_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->customFieldsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Group_id | [optional]

### Return type

[**\Swagger\Client\Model\ShortCustomField[]**](../Model/ShortCustomField.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **customFieldsUpload**
> object customFieldsUpload($custom_field_id, $external_file)

Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$custom_field_id = 789; // int | Custom field identifier
$external_file = "/path/to/file.txt"; // \SplFileObject | CSV file to be uploaded

try {
    $result = $api_instance->customFieldsUpload($custom_field_id, $external_file);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->customFieldsUpload: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **custom_field_id** | **int**| Custom field identifier |
 **external_file** | **\SplFileObject**| CSV file to be uploaded | [optional]

### Return type

**object**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **institutionArticles**
> \Swagger\Client\Model\Article[] institutionArticles($institution_string_id, $resource_id, $filename)

Public Licenses

Returns a list of articles belonging to the institution

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$institution_string_id = "institution_string_id_example"; // string | 
$resource_id = "resource_id_example"; // string | 
$filename = "filename_example"; // string | 

try {
    $result = $api_instance->institutionArticles($institution_string_id, $resource_id, $filename);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->institutionArticles: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **institution_string_id** | **string**|  |
 **resource_id** | **string**|  |
 **filename** | **string**|  |

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **institutionHrfeedUpload**
> \Swagger\Client\Model\ResponseMessage institutionHrfeedUpload($hrfeed)

Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$hrfeed = "/path/to/file.txt"; // \SplFileObject | You can find an example in the Hr Feed section

try {
    $result = $api_instance->institutionHrfeedUpload($hrfeed);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->institutionHrfeedUpload: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hrfeed** | **\SplFileObject**| You can find an example in the Hr Feed section | [optional]

### Return type

[**\Swagger\Client\Model\ResponseMessage**](../Model/ResponseMessage.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateAccountInstitutionUser**
> \Swagger\Client\Model\User privateAccountInstitutionUser($account_id)

Private Account Institution User

Retrieve institution user information using the account_id

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$account_id = 789; // int | Account identifier the user is associated to

try {
    $result = $api_instance->privateAccountInstitutionUser($account_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateAccountInstitutionUser: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to |

### Return type

[**\Swagger\Client\Model\User**](../Model/User.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateCategoriesList**
> \Swagger\Client\Model\Category[] privateCategoriesList()

Private Account Categories

List institution categories (including parent Categories)

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();

try {
    $result = $api_instance->privateCategoriesList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateCategoriesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Category[]**](../Model/Category.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateGroupEmbargoOptionsDetails**
> \Swagger\Client\Model\GroupEmbargoOptions[] privateGroupEmbargoOptionsDetails($group_id)

Private Account Institution Group Embargo Options

Account institution group embargo options details

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$group_id = 789; // int | Group identifier

try {
    $result = $api_instance->privateGroupEmbargoOptionsDetails($group_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateGroupEmbargoOptionsDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Group identifier |

### Return type

[**\Swagger\Client\Model\GroupEmbargoOptions[]**](../Model/GroupEmbargoOptions.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionAccountGroupRoleDelete**
> privateInstitutionAccountGroupRoleDelete($account_id, $group_id, $role_id)

Delete Institution Account Group Role

Delete Institution Account Group Role

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$account_id = 789; // int | Account identifier for which to remove the role
$group_id = 789; // int | Group identifier for which to remove the role
$role_id = 789; // int | Role identifier

try {
    $api_instance->privateInstitutionAccountGroupRoleDelete($account_id, $group_id, $role_id);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountGroupRoleDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier for which to remove the role |
 **group_id** | **int**| Group identifier for which to remove the role |
 **role_id** | **int**| Role identifier |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionAccountGroupRoles**
> \Swagger\Client\Model\AccountGroupRoles privateInstitutionAccountGroupRoles($account_id)

List Institution Account Group Roles

List Institution Account Group Roles

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$account_id = 789; // int | Account identifier the user is associated to

try {
    $result = $api_instance->privateInstitutionAccountGroupRoles($account_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountGroupRoles: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to |

### Return type

[**\Swagger\Client\Model\AccountGroupRoles**](../Model/AccountGroupRoles.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionAccountGroupRolesCreate**
> privateInstitutionAccountGroupRolesCreate($account_id, $account)

Add Institution Account Group Roles

Add Institution Account Group Roles

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$account_id = 789; // int | Account identifier the user is associated to
$account = new \Swagger\Client\Model\AccountGroupRolesCreate(); // \Swagger\Client\Model\AccountGroupRolesCreate | Account description

try {
    $api_instance->privateInstitutionAccountGroupRolesCreate($account_id, $account);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountGroupRolesCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to |
 **account** | [**\Swagger\Client\Model\AccountGroupRolesCreate**](../Model/AccountGroupRolesCreate.md)| Account description |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionAccountsCreate**
> privateInstitutionAccountsCreate($account)

Create new Institution Account

Create a new Account by sending account information

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$account = new \Swagger\Client\Model\AccountCreate(); // \Swagger\Client\Model\AccountCreate | Account description

try {
    $api_instance->privateInstitutionAccountsCreate($account);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountsCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account** | [**\Swagger\Client\Model\AccountCreate**](../Model/AccountCreate.md)| Account description |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionAccountsList**
> \Swagger\Client\Model\ShortAccount[] privateInstitutionAccountsList($page, $page_size, $limit, $offset, $is_active, $institution_user_id, $email, $id_lte, $id_gte)

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing(the offset of the first result). Used for pagination with limit
$is_active = 789; // int | Filter by active status
$institution_user_id = "institution_user_id_example"; // string | Filter by institution_user_id
$email = "email_example"; // string | Filter by email
$id_lte = 789; // int | Retrieve accounts with an ID lower or equal to the specified value
$id_gte = 789; // int | Retrieve accounts with an ID greater or equal to the specified value

try {
    $result = $api_instance->privateInstitutionAccountsList($page, $page_size, $limit, $offset, $is_active, $institution_user_id, $email, $id_lte, $id_gte);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]
 **is_active** | **int**| Filter by active status | [optional]
 **institution_user_id** | **string**| Filter by institution_user_id | [optional]
 **email** | **string**| Filter by email | [optional]
 **id_lte** | **int**| Retrieve accounts with an ID lower or equal to the specified value | [optional]
 **id_gte** | **int**| Retrieve accounts with an ID greater or equal to the specified value | [optional]

### Return type

[**\Swagger\Client\Model\ShortAccount[]**](../Model/ShortAccount.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionAccountsSearch**
> \Swagger\Client\Model\ShortAccount[] privateInstitutionAccountsSearch($search)

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$search = new \Swagger\Client\Model\InstitutionAccountsSearch(); // \Swagger\Client\Model\InstitutionAccountsSearch | Search Parameters

try {
    $result = $api_instance->privateInstitutionAccountsSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountsSearch: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**\Swagger\Client\Model\InstitutionAccountsSearch**](../Model/InstitutionAccountsSearch.md)| Search Parameters |

### Return type

[**\Swagger\Client\Model\ShortAccount[]**](../Model/ShortAccount.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionAccountsUpdate**
> privateInstitutionAccountsUpdate($account_id, $account)

Update Institution Account

Update Institution Account

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$account_id = 789; // int | Account identifier the user is associated to
$account = new \Swagger\Client\Model\AccountUpdate(); // \Swagger\Client\Model\AccountUpdate | Account description

try {
    $api_instance->privateInstitutionAccountsUpdate($account_id, $account);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionAccountsUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to |
 **account** | [**\Swagger\Client\Model\AccountUpdate**](../Model/AccountUpdate.md)| Account description |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionArticles**
> \Swagger\Client\Model\Article[] privateInstitutionArticles($page, $page_size, $limit, $offset, $order, $order_direction, $published_since, $modified_since, $status, $resource_doi, $item_type)

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();
$page = 789; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 789; // int | Number of results included on a page. Used for pagination with query
$offset = 789; // int | Where to start the listing(the offset of the first result). Used for pagination with limit
$order = "published_date"; // string | The field by which to order. Default varies by endpoint/resource.
$order_direction = "desc"; // string | 
$published_since = "published_since_example"; // string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
$modified_since = "modified_since_example"; // string | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
$status = 789; // int | only return collections with this status
$resource_doi = "resource_doi_example"; // string | only return collections with this resource_doi
$item_type = 789; // int | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model

try {
    $result = $api_instance->privateInstitutionArticles($page, $page_size, $limit, $offset, $order, $order_direction, $published_since, $modified_since, $status, $resource_doi, $item_type);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionArticles: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional]
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional]
 **offset** | **int**| Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]
 **published_since** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional]
 **modified_since** | **string**| Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional]
 **status** | **int**| only return collections with this status | [optional]
 **resource_doi** | **string**| only return collections with this resource_doi | [optional]
 **item_type** | **int**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional]

### Return type

[**\Swagger\Client\Model\Article[]**](../Model/Article.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionDetails**
> \Swagger\Client\Model\Institution privateInstitutionDetails()

Private Account Institutions

Account institution details

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();

try {
    $result = $api_instance->privateInstitutionDetails();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Institution**](../Model/Institution.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionEmbargoOptionsDetails**
> \Swagger\Client\Model\GroupEmbargoOptions[] privateInstitutionEmbargoOptionsDetails()

Private Account Institution embargo options

Account institution embargo options details

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();

try {
    $result = $api_instance->privateInstitutionEmbargoOptionsDetails();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionEmbargoOptionsDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\GroupEmbargoOptions[]**](../Model/GroupEmbargoOptions.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionGroupsList**
> \Swagger\Client\Model\Group[] privateInstitutionGroupsList()

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();

try {
    $result = $api_instance->privateInstitutionGroupsList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionGroupsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Group[]**](../Model/Group.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateInstitutionRolesList**
> \Swagger\Client\Model\Role[] privateInstitutionRolesList()

Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\InstitutionsApi();

try {
    $result = $api_instance->privateInstitutionRolesList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstitutionsApi->privateInstitutionRolesList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Role[]**](../Model/Role.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

