# Swagger\Client\DefaultApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**accountArticleReport**](DefaultApi.md#accountArticleReport) | **GET** /account/articles/export | Account Article Report
[**accountArticleReportGenerate**](DefaultApi.md#accountArticleReportGenerate) | **POST** /account/articles/export | Initiate a new Report


# **accountArticleReport**
> \Swagger\Client\Model\AccountReport[] accountArticleReport($group_id)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\DefaultApi();
$group_id = 789; // int | A group ID to filter by

try {
    $result = $api_instance->accountArticleReport($group_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->accountArticleReport: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| A group ID to filter by | [optional]

### Return type

[**\Swagger\Client\Model\AccountReport[]**](../Model/AccountReport.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **accountArticleReportGenerate**
> \Swagger\Client\Model\AccountReport accountArticleReportGenerate()

Initiate a new Report

Initiate a new Article Report for this Account

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$api_instance = new Swagger\Client\Api\DefaultApi();

try {
    $result = $api_instance->accountArticleReportGenerate();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->accountArticleReportGenerate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\AccountReport**](../Model/AccountReport.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

