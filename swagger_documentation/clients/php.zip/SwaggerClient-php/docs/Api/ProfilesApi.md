# Swagger\Client\ProfilesApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateUserProfile**](ProfilesApi.md#updateUserProfile) | **PUT** /account/profile/{user_id} | Update public profile
[**updateUserProfilePicture**](ProfilesApi.md#updateUserProfilePicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture


# **updateUserProfile**
> object updateUserProfile($user_id, $user_profile_data)

Update public profile

Updates the fields of the user's public profile.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProfilesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$user_id = 789; // int | User ID
$user_profile_data = new \Swagger\Client\Model\ProfileUpdateData(); // \Swagger\Client\Model\ProfileUpdateData | 

try {
    $result = $apiInstance->updateUserProfile($user_id, $user_profile_data);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProfilesApi->updateUserProfile: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| User ID |
 **user_profile_data** | [**\Swagger\Client\Model\ProfileUpdateData**](../Model/ProfileUpdateData.md)|  |

### Return type

**object**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **updateUserProfilePicture**
> object updateUserProfilePicture($user_id, $profile_picture)

Update public profile picture

Updates the profile picture of the user's public profile.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProfilesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$user_id = 789; // int | User ID
$profile_picture = "/path/to/file.txt"; // \SplFileObject | User profile picture

try {
    $result = $apiInstance->updateUserProfilePicture($user_id, $profile_picture);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProfilesApi->updateUserProfilePicture: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| User ID |
 **profile_picture** | **\SplFileObject**| User profile picture |

### Return type

**object**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

