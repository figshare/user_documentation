# ItemType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the item type. | [optional] 
**name** | **string** | The name of the item type | [optional] 
**string_id** | **string** | The string identifier of the item type. | [optional] 
**icon** | **string** | The string identifying the icon of the item type. | [optional] 
**public_description** | **string** | The description of the item type. | [optional] 
**is_selectable** | **int** | Filter by the selectable status | [optional] 
**url_name** | **string** | The URL name of the item type. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


