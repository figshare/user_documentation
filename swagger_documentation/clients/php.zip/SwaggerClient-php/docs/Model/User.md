# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | User id | 
**first_name** | **string** | First Name | 
**last_name** | **string** | Last Name | 
**name** | **string** | Full Name | 
**is_active** | **bool** | Account activity status | 
**url_name** | **string** | Name that appears in website url | 
**is_public** | **bool** | Account public status | 
**job_title** | **string** | User Job title | 
**orcid_id** | **string** | Orcid associated to this User | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


