# ArticleEmbargo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_embargoed** | **bool** | True if embargoed | [optional] 
**embargo_reason** | **string** | Reason for embargo | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


