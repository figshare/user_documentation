# ArticleEmbargoUpdater

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_embargoed** | **bool** | Confidentiality status | [optional] 
**embargo_date** | **string** | Date when the embargo expires and the article gets published | [optional] 
**embargo_type** | **string** | Embargo can be enabled at the article or the file level. Possible values: article, file | [optional] 
**embargo_reason** | **string** | Reason for setting embargo | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


