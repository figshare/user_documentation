# ArticleCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique identifier for article | [optional] 
**title** | **string** | Title of article | [optional] 
**doi** | **string** | DOI | [optional] 
**handle** | **string** | Handle | [optional] 
**url** | **string** | Api endpoint for article | [optional] 
**url_public_html** | **string** | Public site endpoint for article | [optional] 
**url_public_api** | **string** | Public Api endpoint for article | [optional] 
**url_private_html** | **string** | Private site endpoint for article | [optional] 
**url_private_api** | **string** | Private Api endpoint for article | [optional] 
**thumb** | **string** | Thumbnail image | [optional] 
**defined_type** | **int** | Type of article identificator | [optional] 
**defined_type_name** | **string** | Name of the article type identificator | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


