# ProjectCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **string** | Role inside this project | [optional] 
**storage** | **string** | Project storage type | [optional] 
**url** | **string** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **string** | Project title | 
**funding** | **string** | Project funding | 
**funding_list** | [**\Swagger\Client\Model\FundingInformation[]**](FundingInformation.md) | Full Project funding information | 
**description** | **string** | Project description | 
**collaborators** | [**\Swagger\Client\Model\Collaborator[]**](Collaborator.md) | List of project collaborators | 
**quota** | **int** | Project quota | 
**used_quota** | **int** | Project used quota | 
**created_date** | **string** | Date when project was created | 
**modified_date** | **string** | Date when project was last modified | 
**used_quota_private** | **int** | Project private quota used | 
**used_quota_public** | **int** | Project public quota used | 
**group_id** | **int** | Group of project if any | 
**account_id** | **int** | ID of the account owning the project | 
**custom_fields** | [**\Swagger\Client\Model\CustomArticleField[]**](CustomArticleField.md) | Collection custom fields | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


