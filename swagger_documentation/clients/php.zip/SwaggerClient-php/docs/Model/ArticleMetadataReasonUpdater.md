# ArticleMetadataReasonUpdater

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metadata_reason** | **string** | Reason for defining the article as metadata record | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


