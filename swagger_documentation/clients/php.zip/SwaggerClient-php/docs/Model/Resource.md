# Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | ID of resource item | [optional] [default to '']
**title** | **string** | Title of resource item | [optional] [default to '']
**doi** | **string** | DOI of resource item | [optional] [default to '']
**link** | **string** | Link of resource item | [optional] [default to '']
**status** | **string** | Status of resource item | [optional] [default to '']
**version** | **int** | Version of resource item | [optional] [default to 0]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


