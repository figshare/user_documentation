# CollectionCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Collection id | [optional] 
**title** | **string** | Collection title | [optional] 
**doi** | **string** | Collection DOI | [optional] 
**handle** | **string** | Collection Handle | [optional] 
**url** | **string** | Api endpoint | [optional] 
**timeline** | [**\Swagger\Client\Model\Timeline**](Timeline.md) | Various timeline dates | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


