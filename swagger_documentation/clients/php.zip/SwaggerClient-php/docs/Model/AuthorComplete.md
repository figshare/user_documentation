# AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Author id | 
**full_name** | **string** | Author full name | 
**is_active** | **bool** | True if author has published items | 
**url_name** | **string** | Author url name | 
**orcid_id** | **string** | Author Orcid | 
**institution_id** | **int** | Institution id | 
**group_id** | **int** | Group id | 
**first_name** | **string** | First Name | 
**last_name** | **string** | Last Name | 
**is_public** | **int** | if 1 then the author has published items | 
**job_title** | **string** | Job title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


