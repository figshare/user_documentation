# ProjectCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** | The title for this project - mandatory. 3 - 1000 characters. | 
**description** | **string** | Project description | [optional] 
**funding** | **string** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 
**funding_list** | [**\Swagger\Client\Model\FundingCreate[]**](FundingCreate.md) | Funding creation / update items | [optional] 
**group_id** | **int** | Only if project type is group. | [optional] 
**custom_fields** | **object** | List of key, values pairs to be associated with the project | [optional] 
**custom_fields_list** | [**\Swagger\Client\Model\CustomArticleFieldAdd[]**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


