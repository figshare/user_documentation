# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id | [optional] 
**first_name** | **string** | First Name | [optional] 
**last_name** | **string** | Last Name | [optional] 
**used_quota_private** | **int** | Account used private quota | [optional] 
**modified_date** | **string** | Date of last account modification | [optional] 
**used_quota** | **int** | Account total used quota | [optional] 
**created_date** | **string** | Date when account was created | [optional] 
**quota** | **int** | Account quota | [optional] 
**institution_user_id** | **string** | Account institution user id | [optional] 
**institution_id** | **int** | Account institution | [optional] 
**email** | **string** | User email | [optional] 
**used_quota_public** | **int** | Account public used quota | [optional] 
**pending_quota_request** | **bool** | True if a quota request is pending | [optional] 
**active** | **int** | Account activity status | [optional] 
**maximum_file_size** | **int** | Maximum upload size for account | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


