# LocationWarningsUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **string** | Url for entity | [optional] 
**warnings** | **string[]** | Issues encountered during the operation | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


