# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **int** | Parent category | [optional] 
**id** | **int** | Category id | [optional] 
**title** | **string** | Category title | [optional] 
**path** | **string** | Path to all ancestor ids | [optional] 
**source_id** | **string** | ID in original standard taxonomy | [optional] 
**taxonomy_id** | **int** | Internal id of taxonomy the category is part of | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


