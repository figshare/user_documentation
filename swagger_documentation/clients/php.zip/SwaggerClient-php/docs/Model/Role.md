# Role

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Role id | [optional] 
**name** | **string** | Role name | [optional] 
**category** | **string** | Role category | [optional] 
**description** | **string** | Role description | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


