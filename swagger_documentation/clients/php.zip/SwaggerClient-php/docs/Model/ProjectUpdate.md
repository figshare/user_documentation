# ProjectUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** | The title for this project - mandatory. 3 - 500 characters. | [optional] 
**description** | **string** | Project description | [optional] 
**funding** | **string** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


