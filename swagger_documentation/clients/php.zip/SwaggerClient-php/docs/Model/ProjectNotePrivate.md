# ProjectNotePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Project note id | [optional] 
**user_id** | **int** | User who wrote the note | [optional] 
**abstract** | **string** | Note Abstract - short/truncated content | [optional] 
**user_name** | **string** | Username of the one who wrote the note | [optional] 
**created_date** | **string** | Date when note was created | [optional] 
**modified_date** | **string** | Date when note was last modified | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


