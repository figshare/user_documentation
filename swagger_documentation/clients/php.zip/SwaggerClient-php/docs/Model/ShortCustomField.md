# ShortCustomField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Custom field id | 
**name** | **string** | Custom field name | 
**field_type** | **string** | Custom field type | 
**settings** | **object** | Settings for the custom field | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


