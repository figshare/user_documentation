(defproject figshare-api "2.0.0"
  :description "Figshare apiv2. Using Swagger 2.0"
  :dependencies [[org.clojure/clojure "1.7.0"]
                 [clj-http "2.0.0"]
                 [cheshire "5.5.0"]])
