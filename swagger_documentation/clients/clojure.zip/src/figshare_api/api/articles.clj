(ns figshare-api.api.articles
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn account-article-report-with-http-info
  "Account Article Report
  Return status on all reports generated for the account from the oauth credentials"
  ([] (account-article-report-with-http-info nil))
  ([{:keys [group-id ]}]
   (call-api "/account/articles/export" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"group_id" group-id }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn account-article-report
  "Account Article Report
  Return status on all reports generated for the account from the oauth credentials"
  ([] (account-article-report nil))
  ([optional-params]
   (:data (account-article-report-with-http-info optional-params))))

(defn account-article-report-generate-with-http-info
  "Initiate a new Report
  Initiate a new Article Report for this Account"
  []
  (call-api "/account/articles/export" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn account-article-report-generate
  "Initiate a new Report
  Initiate a new Article Report for this Account"
  []
  (:data (account-article-report-generate-with-http-info)))

(defn article-details-with-http-info
  "View article details
  View an article"
  [article-id ]
  (call-api "/articles/{article_id}" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn article-details
  "View article details
  View an article"
  [article-id ]
  (:data (article-details-with-http-info article-id)))

(defn article-file-details-with-http-info
  "Article file details
  File by id"
  [article-id file-id ]
  (call-api "/articles/{article_id}/files/{file_id}" :get
            {:path-params   {"article_id" article-id "file_id" file-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn article-file-details
  "Article file details
  File by id"
  [article-id file-id ]
  (:data (article-file-details-with-http-info article-id file-id)))

(defn article-files-with-http-info
  "List article files
  Files list for article"
  [article-id ]
  (call-api "/articles/{article_id}/files" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn article-files
  "List article files
  Files list for article"
  [article-id ]
  (:data (article-files-with-http-info article-id)))

(defn article-version-confidentiality-with-http-info
  "Public Article Confidentiality for article version
  Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article-id v-number ]
  (call-api "/articles/{article_id}/versions/{v_number}/confidentiality" :get
            {:path-params   {"article_id" article-id "v_number" v-number }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn article-version-confidentiality
  "Public Article Confidentiality for article version
  Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article-id v-number ]
  (:data (article-version-confidentiality-with-http-info article-id v-number)))

(defn article-version-details-with-http-info
  "Article details for version
  Article with specified version"
  [article-id v-number ]
  (call-api "/articles/{article_id}/versions/{v_number}" :get
            {:path-params   {"article_id" article-id "v_number" v-number }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn article-version-details
  "Article details for version
  Article with specified version"
  [article-id v-number ]
  (:data (article-version-details-with-http-info article-id v-number)))

(defn article-version-embargo-with-http-info
  "Public Article Embargo for article version
  Embargo for article version"
  [article-id v-number ]
  (call-api "/articles/{article_id}/versions/{v_number}/embargo" :get
            {:path-params   {"article_id" article-id "v_number" v-number }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn article-version-embargo
  "Public Article Embargo for article version
  Embargo for article version"
  [article-id v-number ]
  (:data (article-version-embargo-with-http-info article-id v-number)))

(defn article-version-update-with-http-info
  "Update article version
  Updating an article version by passing body parameters; request can also be made with the PATCH method."
  [article-id version-id article ]
  (call-api "/account/articles/{article_id}/versions/{version_id}/" :put
            {:path-params   {"article_id" article-id "version_id" version-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    article
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn article-version-update
  "Update article version
  Updating an article version by passing body parameters; request can also be made with the PATCH method."
  [article-id version-id article ]
  (:data (article-version-update-with-http-info article-id version-id article)))

(defn article-version-update-thumb-with-http-info
  "Update article version thumbnail
  For a given public article version update the article thumbnail by choosing one of the associated files"
  [article-id version-id file-id ]
  (call-api "/account/articles/{article_id}/versions/{version_id}/update_thumb" :put
            {:path-params   {"article_id" article-id "version_id" version-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    file-id
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn article-version-update-thumb
  "Update article version thumbnail
  For a given public article version update the article thumbnail by choosing one of the associated files"
  [article-id version-id file-id ]
  (:data (article-version-update-thumb-with-http-info article-id version-id file-id)))

(defn article-versions-with-http-info
  "List article versions
  List public article versions"
  [article-id ]
  (call-api "/articles/{article_id}/versions" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn article-versions
  "List article versions
  List public article versions"
  [article-id ]
  (:data (article-versions-with-http-info article-id)))

(defn articles-list-with-http-info
  "Public Articles
  Returns a list of public articles"
  ([] (articles-list-with-http-info nil))
  ([{:keys [x-cursor page page-size limit offset order order-direction institution published-since modified-since group resource-doi item-type doi handle ]}]
   (call-api "/articles" :get
             {:path-params   {}
              :header-params {"X-Cursor" x-cursor }
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset "order" order "order_direction" order-direction "institution" institution "published_since" published-since "modified_since" modified-since "group" group "resource_doi" resource-doi "item_type" item-type "doi" doi "handle" handle }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn articles-list
  "Public Articles
  Returns a list of public articles"
  ([] (articles-list nil))
  ([optional-params]
   (:data (articles-list-with-http-info optional-params))))

(defn articles-search-with-http-info
  "Public Articles Search
  Returns a list of public articles, filtered by the search parameters"
  ([] (articles-search-with-http-info nil))
  ([{:keys [x-cursor search ]}]
   (call-api "/articles/search" :post
             {:path-params   {}
              :header-params {"X-Cursor" x-cursor }
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn articles-search
  "Public Articles Search
  Returns a list of public articles, filtered by the search parameters"
  ([] (articles-search nil))
  ([optional-params]
   (:data (articles-search-with-http-info optional-params))))

(defn private-article-author-delete-with-http-info
  "Delete article author
  De-associate author from article"
  [article-id author-id ]
  (call-api "/account/articles/{article_id}/authors/{author_id}" :delete
            {:path-params   {"article_id" article-id "author_id" author-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-author-delete
  "Delete article author
  De-associate author from article"
  [article-id author-id ]
  (:data (private-article-author-delete-with-http-info article-id author-id)))

(defn private-article-authors-add-with-http-info
  "Add article authors
  Associate new authors with the article. This will add new authors to the list of already associated authors"
  [article-id authors ]
  (call-api "/account/articles/{article_id}/authors" :post
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    authors
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-authors-add
  "Add article authors
  Associate new authors with the article. This will add new authors to the list of already associated authors"
  [article-id authors ]
  (:data (private-article-authors-add-with-http-info article-id authors)))

(defn private-article-authors-list-with-http-info
  "List article authors
  List article authors"
  [article-id ]
  (call-api "/account/articles/{article_id}/authors" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-authors-list
  "List article authors
  List article authors"
  [article-id ]
  (:data (private-article-authors-list-with-http-info article-id)))

(defn private-article-authors-replace-with-http-info
  "Replace article authors
  Associate new authors with the article. This will remove all already associated authors and add these new ones"
  [article-id authors ]
  (call-api "/account/articles/{article_id}/authors" :put
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    authors
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-authors-replace
  "Replace article authors
  Associate new authors with the article. This will remove all already associated authors and add these new ones"
  [article-id authors ]
  (:data (private-article-authors-replace-with-http-info article-id authors)))

(defn private-article-categories-add-with-http-info
  "Add article categories
  Associate new categories with the article. This will add new categories to the list of already associated categories"
  [article-id categories ]
  (call-api "/account/articles/{article_id}/categories" :post
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    categories
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-categories-add
  "Add article categories
  Associate new categories with the article. This will add new categories to the list of already associated categories"
  [article-id categories ]
  (:data (private-article-categories-add-with-http-info article-id categories)))

(defn private-article-categories-list-with-http-info
  "List article categories
  List article categories"
  [article-id ]
  (call-api "/account/articles/{article_id}/categories" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-categories-list
  "List article categories
  List article categories"
  [article-id ]
  (:data (private-article-categories-list-with-http-info article-id)))

(defn private-article-categories-replace-with-http-info
  "Replace article categories
  Associate new categories with the article. This will remove all already associated categories and add these new ones"
  [article-id categories ]
  (call-api "/account/articles/{article_id}/categories" :put
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    categories
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-categories-replace
  "Replace article categories
  Associate new categories with the article. This will remove all already associated categories and add these new ones"
  [article-id categories ]
  (:data (private-article-categories-replace-with-http-info article-id categories)))

(defn private-article-category-delete-with-http-info
  "Delete article category
  De-associate category from article"
  [article-id category-id ]
  (call-api "/account/articles/{article_id}/categories/{category_id}" :delete
            {:path-params   {"article_id" article-id "category_id" category-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-category-delete
  "Delete article category
  De-associate category from article"
  [article-id category-id ]
  (:data (private-article-category-delete-with-http-info article-id category-id)))

(defn private-article-confidentiality-delete-with-http-info
  "Delete article confidentiality
  Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article-id ]
  (call-api "/account/articles/{article_id}/confidentiality" :delete
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-confidentiality-delete
  "Delete article confidentiality
  Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article-id ]
  (:data (private-article-confidentiality-delete-with-http-info article-id)))

(defn private-article-confidentiality-details-with-http-info
  "Article confidentiality details
  View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article-id ]
  (call-api "/account/articles/{article_id}/confidentiality" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-confidentiality-details
  "Article confidentiality details
  View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article-id ]
  (:data (private-article-confidentiality-details-with-http-info article-id)))

(defn private-article-confidentiality-update-with-http-info
  "Update article confidentiality
  Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article-id reason ]
  (call-api "/account/articles/{article_id}/confidentiality" :put
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    reason
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-confidentiality-update
  "Update article confidentiality
  Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article-id reason ]
  (:data (private-article-confidentiality-update-with-http-info article-id reason)))

(defn private-article-create-with-http-info
  "Create new Article
  Create a new Article by sending article information"
  [article ]
  (call-api "/account/articles" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    article
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-create
  "Create new Article
  Create a new Article by sending article information"
  [article ]
  (:data (private-article-create-with-http-info article)))

(defn private-article-delete-with-http-info
  "Delete article
  Delete an article"
  [article-id ]
  (call-api "/account/articles/{article_id}" :delete
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-delete
  "Delete article
  Delete an article"
  [article-id ]
  (:data (private-article-delete-with-http-info article-id)))

(defn private-article-details-with-http-info
  "Article details
  View a private article"
  [article-id ]
  (call-api "/account/articles/{article_id}" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-details
  "Article details
  View a private article"
  [article-id ]
  (:data (private-article-details-with-http-info article-id)))

(defn private-article-embargo-delete-with-http-info
  "Delete Article Embargo
  Will lift the embargo for the specified article"
  [article-id ]
  (call-api "/account/articles/{article_id}/embargo" :delete
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-embargo-delete
  "Delete Article Embargo
  Will lift the embargo for the specified article"
  [article-id ]
  (:data (private-article-embargo-delete-with-http-info article-id)))

(defn private-article-embargo-details-with-http-info
  "Article Embargo Details
  View a private article embargo details"
  [article-id ]
  (call-api "/account/articles/{article_id}/embargo" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-embargo-details
  "Article Embargo Details
  View a private article embargo details"
  [article-id ]
  (:data (private-article-embargo-details-with-http-info article-id)))

(defn private-article-embargo-update-with-http-info
  "Update Article Embargo
  Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality."
  [article-id embargo ]
  (call-api "/account/articles/{article_id}/embargo" :put
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    embargo
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-embargo-update
  "Update Article Embargo
  Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality."
  [article-id embargo ]
  (:data (private-article-embargo-update-with-http-info article-id embargo)))

(defn private-article-file-with-http-info
  "Single File
  View details of file for specified article"
  [article-id file-id ]
  (call-api "/account/articles/{article_id}/files/{file_id}" :get
            {:path-params   {"article_id" article-id "file_id" file-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-file
  "Single File
  View details of file for specified article"
  [article-id file-id ]
  (:data (private-article-file-with-http-info article-id file-id)))

(defn private-article-file-delete-with-http-info
  "File Delete
  Complete file upload"
  [article-id file-id ]
  (call-api "/account/articles/{article_id}/files/{file_id}" :delete
            {:path-params   {"article_id" article-id "file_id" file-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-file-delete
  "File Delete
  Complete file upload"
  [article-id file-id ]
  (:data (private-article-file-delete-with-http-info article-id file-id)))

(defn private-article-files-list-with-http-info
  "List article files
  List private files"
  [article-id ]
  (call-api "/account/articles/{article_id}/files" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-files-list
  "List article files
  List private files"
  [article-id ]
  (:data (private-article-files-list-with-http-info article-id)))

(defn private-article-private-link-with-http-info
  "List private links
  List private links"
  [article-id ]
  (call-api "/account/articles/{article_id}/private_links" :get
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-private-link
  "List private links
  List private links"
  [article-id ]
  (:data (private-article-private-link-with-http-info article-id)))

(defn private-article-private-link-create-with-http-info
  "Create private link
  Create new private link for this article"
  ([article-id ] (private-article-private-link-create-with-http-info article-id nil))
  ([article-id {:keys [private-link ]}]
   (call-api "/account/articles/{article_id}/private_links" :post
             {:path-params   {"article_id" article-id }
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    private-link
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-article-private-link-create
  "Create private link
  Create new private link for this article"
  ([article-id ] (private-article-private-link-create article-id nil))
  ([article-id optional-params]
   (:data (private-article-private-link-create-with-http-info article-id optional-params))))

(defn private-article-private-link-delete-with-http-info
  "Disable private link
  Disable/delete private link for this article"
  [article-id link-id ]
  (call-api "/account/articles/{article_id}/private_links/{link_id}" :delete
            {:path-params   {"article_id" article-id "link_id" link-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-private-link-delete
  "Disable private link
  Disable/delete private link for this article"
  [article-id link-id ]
  (:data (private-article-private-link-delete-with-http-info article-id link-id)))

(defn private-article-private-link-update-with-http-info
  "Update private link
  Update existing private link for this article"
  ([article-id link-id ] (private-article-private-link-update-with-http-info article-id link-id nil))
  ([article-id link-id {:keys [private-link ]}]
   (call-api "/account/articles/{article_id}/private_links/{link_id}" :put
             {:path-params   {"article_id" article-id "link_id" link-id }
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    private-link
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-article-private-link-update
  "Update private link
  Update existing private link for this article"
  ([article-id link-id ] (private-article-private-link-update article-id link-id nil))
  ([article-id link-id optional-params]
   (:data (private-article-private-link-update-with-http-info article-id link-id optional-params))))

(defn private-article-publish-with-http-info
  "Private Article Publish
  - If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted.
- When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed."
  [article-id ]
  (call-api "/account/articles/{article_id}/publish" :post
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-publish
  "Private Article Publish
  - If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted.
- When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed."
  [article-id ]
  (:data (private-article-publish-with-http-info article-id)))

(defn private-article-reserve-doi-with-http-info
  "Private Article Reserve DOI
  Reserve DOI for article"
  [article-id ]
  (call-api "/account/articles/{article_id}/reserve_doi" :post
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-reserve-doi
  "Private Article Reserve DOI
  Reserve DOI for article"
  [article-id ]
  (:data (private-article-reserve-doi-with-http-info article-id)))

(defn private-article-reserve-handle-with-http-info
  "Private Article Reserve Handle
  Reserve Handle for article"
  [article-id ]
  (call-api "/account/articles/{article_id}/reserve_handle" :post
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-reserve-handle
  "Private Article Reserve Handle
  Reserve Handle for article"
  [article-id ]
  (:data (private-article-reserve-handle-with-http-info article-id)))

(defn private-article-resource-with-http-info
  "Private Article Resource
  Edit article resource data."
  [article-id resource ]
  (call-api "/account/articles/{article_id}/resource" :post
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    resource
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-resource
  "Private Article Resource
  Edit article resource data."
  [article-id resource ]
  (:data (private-article-resource-with-http-info article-id resource)))

(defn private-article-update-with-http-info
  "Update article
  Updating an article by passing body parameters; request can also be made with the PATCH method."
  [article-id article ]
  (call-api "/account/articles/{article_id}" :put
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    article
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-update
  "Update article
  Updating an article by passing body parameters; request can also be made with the PATCH method."
  [article-id article ]
  (:data (private-article-update-with-http-info article-id article)))

(defn private-article-upload-complete-with-http-info
  "Complete Upload
  Complete file upload"
  [article-id file-id ]
  (call-api "/account/articles/{article_id}/files/{file_id}" :post
            {:path-params   {"article_id" article-id "file_id" file-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-upload-complete
  "Complete Upload
  Complete file upload"
  [article-id file-id ]
  (:data (private-article-upload-complete-with-http-info article-id file-id)))

(defn private-article-upload-initiate-with-http-info
  "Initiate Upload
  Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size)."
  [article-id file ]
  (call-api "/account/articles/{article_id}/files" :post
            {:path-params   {"article_id" article-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    file
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-article-upload-initiate
  "Initiate Upload
  Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size)."
  [article-id file ]
  (:data (private-article-upload-initiate-with-http-info article-id file)))

(defn private-articles-list-with-http-info
  "Private Articles
  Get Own Articles"
  ([] (private-articles-list-with-http-info nil))
  ([{:keys [page page-size limit offset ]}]
   (call-api "/account/articles" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-articles-list
  "Private Articles
  Get Own Articles"
  ([] (private-articles-list nil))
  ([optional-params]
   (:data (private-articles-list-with-http-info optional-params))))

(defn private-articles-search-with-http-info
  "Private Articles search
  Returns a list of private articles filtered by the search parameters"
  [search ]
  (call-api "/account/articles/search" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    search
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-articles-search
  "Private Articles search
  Returns a list of private articles filtered by the search parameters"
  [search ]
  (:data (private-articles-search-with-http-info search)))

