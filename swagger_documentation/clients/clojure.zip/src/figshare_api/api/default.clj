(ns figshare-api.api.default
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn account-article-report-with-http-info
  "Account Article Report
  Return status on all reports generated for the account from the oauth credentials"
  ([] (account-article-report-with-http-info nil))
  ([{:keys [group-id ]}]
   (call-api "/account/articles/export" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"group_id" group-id }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn account-article-report
  "Account Article Report
  Return status on all reports generated for the account from the oauth credentials"
  ([] (account-article-report nil))
  ([optional-params]
   (:data (account-article-report-with-http-info optional-params))))

(defn account-article-report-generate-with-http-info
  "Initiate a new Report
  Initiate a new Article Report for this Account"
  []
  (call-api "/account/articles/export" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn account-article-report-generate
  "Initiate a new Report
  Initiate a new Article Report for this Account"
  []
  (:data (account-article-report-generate-with-http-info)))

