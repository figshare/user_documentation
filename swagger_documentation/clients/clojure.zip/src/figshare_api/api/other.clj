(ns figshare-api.api.other
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn categories-list-with-http-info
  "Public Categories
  Returns a list of public categories"
  []
  (call-api "/categories" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn categories-list
  "Public Categories
  Returns a list of public categories"
  []
  (:data (categories-list-with-http-info)))

(defn file-download-with-http-info
  "Public File Download
  Starts the download of a file"
  [file-id ]
  (call-api "/file/download/{file_id}" :get
            {:path-params   {"file_id" file-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/force-download"]
             :auth-names    []}))

(defn file-download
  "Public File Download
  Starts the download of a file"
  [file-id ]
  (:data (file-download-with-http-info file-id)))

(defn item-types-list-with-http-info
  "Item Types
  Returns a list of Item Types available to the authenticated user. If no user is authenticated, returns the item types available for Figshare."
  ([] (item-types-list-with-http-info nil))
  ([{:keys [group-id ]}]
   (call-api "/item_types" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"group_id" group-id }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn item-types-list
  "Item Types
  Returns a list of Item Types available to the authenticated user. If no user is authenticated, returns the item types available for Figshare."
  ([] (item-types-list nil))
  ([optional-params]
   (:data (item-types-list-with-http-info optional-params))))

(defn licenses-list-with-http-info
  "Public Licenses
  Returns a list of public licenses"
  []
  (call-api "/licenses" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn licenses-list
  "Public Licenses
  Returns a list of public licenses"
  []
  (:data (licenses-list-with-http-info)))

(defn private-account-with-http-info
  "Private Account information
  Account information for token/personal token"
  []
  (call-api "/account" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-account
  "Private Account information
  Account information for token/personal token"
  []
  (:data (private-account-with-http-info)))

(defn private-funding-search-with-http-info
  "Search Funding
  Search for fundings"
  ([] (private-funding-search-with-http-info nil))
  ([{:keys [search ]}]
   (call-api "/account/funding/search" :post
             {:path-params   {}
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-funding-search
  "Search Funding
  Search for fundings"
  ([] (private-funding-search nil))
  ([optional-params]
   (:data (private-funding-search-with-http-info optional-params))))

(defn private-licenses-list-with-http-info
  "Private Account Licenses
  This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution."
  []
  (call-api "/account/licenses" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-licenses-list
  "Private Account Licenses
  This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution."
  []
  (:data (private-licenses-list-with-http-info)))

