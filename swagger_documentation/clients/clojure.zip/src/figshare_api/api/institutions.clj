(ns figshare-api.api.institutions
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn institution-articles-with-http-info
  "Public Licenses
  Returns a list of articles belonging to the institution"
  [institution-string-id resource-id filename ]
  (call-api "/institutions/{institution_string_id}/articles/filter-by" :get
            {:path-params   {"institution_string_id" institution-string-id }
             :header-params {}
             :query-params  {"resource_id" resource-id "filename" filename }
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn institution-articles
  "Public Licenses
  Returns a list of articles belonging to the institution"
  [institution-string-id resource-id filename ]
  (:data (institution-articles-with-http-info institution-string-id resource-id filename)))

(defn institution-hrfeed-upload-with-http-info
  "Private Institution HRfeed Upload
  More info in the <a href=\"#hr_feed\">HR Feed section</a>"
  ([] (institution-hrfeed-upload-with-http-info nil))
  ([{:keys [^File hrfeed ]}]
   (call-api "/institution/hrfeed/upload" :post
             {:path-params   {}
              :header-params {}
              :query-params  {}
              :form-params   {"hrfeed" hrfeed }
              :content-types ["multipart/form-data"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn institution-hrfeed-upload
  "Private Institution HRfeed Upload
  More info in the <a href=\"#hr_feed\">HR Feed section</a>"
  ([] (institution-hrfeed-upload nil))
  ([optional-params]
   (:data (institution-hrfeed-upload-with-http-info optional-params))))

(defn private-categories-list-with-http-info
  "Private Account Categories
  List institution categories (including parent Categories)"
  []
  (call-api "/account/categories" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-categories-list
  "Private Account Categories
  List institution categories (including parent Categories)"
  []
  (:data (private-categories-list-with-http-info)))

(defn private-institution-accounts-list-with-http-info
  "Private Account Institution Accounts
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  ([] (private-institution-accounts-list-with-http-info nil))
  ([{:keys [page page-size limit offset is-active ]}]
   (call-api "/account/institution/accounts" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset "is_active" is-active }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-institution-accounts-list
  "Private Account Institution Accounts
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  ([] (private-institution-accounts-list nil))
  ([optional-params]
   (:data (private-institution-accounts-list-with-http-info optional-params))))

(defn private-institution-accounts-search-with-http-info
  "Private Account Institution Accounts Search
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  [search ]
  (call-api "/account/institution/accounts/search" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    search
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-accounts-search
  "Private Account Institution Accounts Search
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  [search ]
  (:data (private-institution-accounts-search-with-http-info search)))

(defn private-institution-articles-with-http-info
  "Private Institution Articles
  Get Articles from own institution. User must be administrator of the institution"
  ([] (private-institution-articles-with-http-info nil))
  ([{:keys [page page-size limit offset order order-direction published-since modified-since status resource-doi item-type ]}]
   (call-api "/account/institution/articles" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset "order" order "order_direction" order-direction "published_since" published-since "modified_since" modified-since "status" status "resource_doi" resource-doi "item_type" item-type }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-institution-articles
  "Private Institution Articles
  Get Articles from own institution. User must be administrator of the institution"
  ([] (private-institution-articles nil))
  ([optional-params]
   (:data (private-institution-articles-with-http-info optional-params))))

(defn private-institution-details-with-http-info
  "Private Account Institutions
  Account institution details"
  []
  (call-api "/account/institution" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-details
  "Private Account Institutions
  Account institution details"
  []
  (:data (private-institution-details-with-http-info)))

(defn private-institution-groups-list-with-http-info
  "Private Account Institution Groups
  Returns the groups for which the account has administrative privileges (assigned and inherited)."
  []
  (call-api "/account/institution/groups" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-groups-list
  "Private Account Institution Groups
  Returns the groups for which the account has administrative privileges (assigned and inherited)."
  []
  (:data (private-institution-groups-list-with-http-info)))

