(ns figshare-api.api.institutions
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn account-institution-curation-with-http-info
  "Institution Curation Review
  Retrieve a certain curation review by its ID"
  [curation-id ]
  (call-api "/account/institution/review/{curation_id}" :get
            {:path-params   {"curation_id" curation-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn account-institution-curation
  "Institution Curation Review
  Retrieve a certain curation review by its ID"
  [curation-id ]
  (:data (account-institution-curation-with-http-info curation-id)))

(defn account-institution-curation-comments-with-http-info
  "Institution Curation Review Comments
  Retrieve a certain curation review's comments."
  ([curation-id ] (account-institution-curation-comments-with-http-info curation-id nil))
  ([curation-id {:keys [limit offset ]}]
   (call-api "/account/institution/review/{curation_id}/comments" :get
             {:path-params   {"curation_id" curation-id }
              :header-params {}
              :query-params  {"limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn account-institution-curation-comments
  "Institution Curation Review Comments
  Retrieve a certain curation review's comments."
  ([curation-id ] (account-institution-curation-comments curation-id nil))
  ([curation-id optional-params]
   (:data (account-institution-curation-comments-with-http-info curation-id optional-params))))

(defn account-institution-curation-comments_0-with-http-info
  "POST Institution Curation Review Comment
  Add a new comment to the review."
  [curation-id curation-comment ]
  (call-api "/account/institution/review/{curation_id}/comments" :post
            {:path-params   {"curation_id" curation-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    curation-comment
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn account-institution-curation-comments_0
  "POST Institution Curation Review Comment
  Add a new comment to the review."
  [curation-id curation-comment ]
  (:data (account-institution-curation-comments_0-with-http-info curation-id curation-comment)))

(defn account-institution-curations-with-http-info
  "Institution Curation Reviews
  Retrieve a list of curation reviews for this institution"
  ([] (account-institution-curations-with-http-info nil))
  ([{:keys [group-id article-id status limit offset ]}]
   (call-api "/account/institution/reviews" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"group_id" group-id "article_id" article-id "status" status "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn account-institution-curations
  "Institution Curation Reviews
  Retrieve a list of curation reviews for this institution"
  ([] (account-institution-curations nil))
  ([optional-params]
   (:data (account-institution-curations-with-http-info optional-params))))

(defn institution-articles-with-http-info
  "Public Licenses
  Returns a list of articles belonging to the institution"
  [institution-string-id resource-id filename ]
  (call-api "/institutions/{institution_string_id}/articles/filter-by" :get
            {:path-params   {"institution_string_id" institution-string-id }
             :header-params {}
             :query-params  {"resource_id" resource-id "filename" filename }
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn institution-articles
  "Public Licenses
  Returns a list of articles belonging to the institution"
  [institution-string-id resource-id filename ]
  (:data (institution-articles-with-http-info institution-string-id resource-id filename)))

(defn institution-hrfeed-upload-with-http-info
  "Private Institution HRfeed Upload
  More info in the <a href=\"#hr_feed\">HR Feed section</a>"
  ([] (institution-hrfeed-upload-with-http-info nil))
  ([{:keys [^File hrfeed ]}]
   (call-api "/institution/hrfeed/upload" :post
             {:path-params   {}
              :header-params {}
              :query-params  {}
              :form-params   {"hrfeed" hrfeed }
              :content-types ["multipart/form-data"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn institution-hrfeed-upload
  "Private Institution HRfeed Upload
  More info in the <a href=\"#hr_feed\">HR Feed section</a>"
  ([] (institution-hrfeed-upload nil))
  ([optional-params]
   (:data (institution-hrfeed-upload-with-http-info optional-params))))

(defn private-account-institution-user-with-http-info
  "Private Account Institution User
  Retrieve institution user information using the account_id"
  [account-id ]
  (call-api "/account/institution/users/{account_id}" :get
            {:path-params   {"account_id" account-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-account-institution-user
  "Private Account Institution User
  Retrieve institution user information using the account_id"
  [account-id ]
  (:data (private-account-institution-user-with-http-info account-id)))

(defn private-categories-list-with-http-info
  "Private Account Categories
  List institution categories (including parent Categories)"
  []
  (call-api "/account/categories" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-categories-list
  "Private Account Categories
  List institution categories (including parent Categories)"
  []
  (:data (private-categories-list-with-http-info)))

(defn private-institution-account-group-role-delete-with-http-info
  "Delete Institution Account Group Role
  Delete Institution Account Group Role"
  [account-id group-id role-id ]
  (call-api "/account/institution/roles/{account_id}/{group_id}/{role_id}" :delete
            {:path-params   {"account_id" account-id "group_id" group-id "role_id" role-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-account-group-role-delete
  "Delete Institution Account Group Role
  Delete Institution Account Group Role"
  [account-id group-id role-id ]
  (:data (private-institution-account-group-role-delete-with-http-info account-id group-id role-id)))

(defn private-institution-account-group-roles-with-http-info
  "List Institution Account Group Roles
  List Institution Account Group Roles"
  [account-id ]
  (call-api "/account/institution/roles/{account_id}" :get
            {:path-params   {"account_id" account-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-account-group-roles
  "List Institution Account Group Roles
  List Institution Account Group Roles"
  [account-id ]
  (:data (private-institution-account-group-roles-with-http-info account-id)))

(defn private-institution-account-group-roles-create-with-http-info
  "Add Institution Account Group Roles
  Add Institution Account Group Roles"
  [account-id account ]
  (call-api "/account/institution/roles/{account_id}" :post
            {:path-params   {"account_id" account-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    account
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-account-group-roles-create
  "Add Institution Account Group Roles
  Add Institution Account Group Roles"
  [account-id account ]
  (:data (private-institution-account-group-roles-create-with-http-info account-id account)))

(defn private-institution-accounts-create-with-http-info
  "Create new Institution Account
  Create a new Account by sending account information"
  [account ]
  (call-api "/account/institution/accounts" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    account
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-accounts-create
  "Create new Institution Account
  Create a new Account by sending account information"
  [account ]
  (:data (private-institution-accounts-create-with-http-info account)))

(defn private-institution-accounts-list-with-http-info
  "Private Account Institution Accounts
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  ([] (private-institution-accounts-list-with-http-info nil))
  ([{:keys [page page-size limit offset is-active institution-user-id email ]}]
   (call-api "/account/institution/accounts" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset "is_active" is-active "institution_user_id" institution-user-id "email" email }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-institution-accounts-list
  "Private Account Institution Accounts
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  ([] (private-institution-accounts-list nil))
  ([optional-params]
   (:data (private-institution-accounts-list-with-http-info optional-params))))

(defn private-institution-accounts-search-with-http-info
  "Private Account Institution Accounts Search
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  [search ]
  (call-api "/account/institution/accounts/search" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    search
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-accounts-search
  "Private Account Institution Accounts Search
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  [search ]
  (:data (private-institution-accounts-search-with-http-info search)))

(defn private-institution-accounts-update-with-http-info
  "Update Institution Account
  Update Institution Account"
  [account-id account ]
  (call-api "/account/institution/accounts/{account_id}" :put
            {:path-params   {"account_id" account-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    account
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-accounts-update
  "Update Institution Account
  Update Institution Account"
  [account-id account ]
  (:data (private-institution-accounts-update-with-http-info account-id account)))

(defn private-institution-articles-with-http-info
  "Private Institution Articles
  Get Articles from own institution. User must be administrator of the institution"
  ([] (private-institution-articles-with-http-info nil))
  ([{:keys [page page-size limit offset order order-direction published-since modified-since status resource-doi item-type ]}]
   (call-api "/account/institution/articles" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page-size "limit" limit "offset" offset "order" order "order_direction" order-direction "published_since" published-since "modified_since" modified-since "status" status "resource_doi" resource-doi "item_type" item-type }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-institution-articles
  "Private Institution Articles
  Get Articles from own institution. User must be administrator of the institution"
  ([] (private-institution-articles nil))
  ([optional-params]
   (:data (private-institution-articles-with-http-info optional-params))))

(defn private-institution-details-with-http-info
  "Private Account Institutions
  Account institution details"
  []
  (call-api "/account/institution" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-details
  "Private Account Institutions
  Account institution details"
  []
  (:data (private-institution-details-with-http-info)))

(defn private-institution-groups-list-with-http-info
  "Private Account Institution Groups
  Returns the groups for which the account has administrative privileges (assigned and inherited)."
  []
  (call-api "/account/institution/groups" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-groups-list
  "Private Account Institution Groups
  Returns the groups for which the account has administrative privileges (assigned and inherited)."
  []
  (:data (private-institution-groups-list-with-http-info)))

(defn private-institution-roles-list-with-http-info
  "Private Account Institution Roles
  Returns the roles available for groups and the institution group."
  []
  (call-api "/account/institution/roles" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-institution-roles-list
  "Private Account Institution Roles
  Returns the roles available for groups and the institution group."
  []
  (:data (private-institution-roles-list-with-http-info)))

