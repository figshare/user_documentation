
# ArticleComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Unique identifier for article |  [optional]
**title** | **String** | Title of article |  [optional]
**doi** | **String** | DOI |  [optional]
**url** | **String** | Api endpoint for article |  [optional]
**urlPublicHtml** | **String** | Public site endpoint for article |  [optional]
**urlPublicApi** | **String** | Public Api endpoint for article |  [optional]
**urlPrivateHtml** | **String** | Private site endpoint for article |  [optional]
**urlPrivateApi** | **String** | Private Api endpoint for article |  [optional]
**thumb** | **String** | Thumbnail image |  [optional]
**definedType** | **Long** | Integer which is mapped to item types as: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code |  [optional]



