
# FundingCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | A funding ID as returned by the Funding Search endpoint | 
**title** | **String** | The title of the new user created funding | 



