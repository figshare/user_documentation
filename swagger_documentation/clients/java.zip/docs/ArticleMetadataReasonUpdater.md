
# ArticleMetadataReasonUpdater

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metadataReason** | **String** | Reason for defining the article as metadata record | 



