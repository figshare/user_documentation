
# Collaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**roleName** | **String** | Collaborator role |  [optional]
**userId** | **Integer** | Collaborator id |  [optional]
**name** | **String** | Collaborator name |  [optional]



