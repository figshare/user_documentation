
# CollectionVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Version number |  [optional]
**url** | **String** | Api endpoint for the collection version |  [optional]



