
# ArticleVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **Long** | Version number |  [optional]
**url** | **String** | Api endpoint for the item version |  [optional]



