
# ArticleVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Version number |  [optional]
**url** | **String** | Api endpoint for the item version |  [optional]



