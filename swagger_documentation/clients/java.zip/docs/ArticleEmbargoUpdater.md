
# ArticleEmbargoUpdater

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isEmbargoed** | **Boolean** | Embargo status |  [optional]
**embargoDate** | **String** | Date when the embargo expires and the article gets published |  [optional]
**embargoType** | [**EmbargoTypeEnum**](#EmbargoTypeEnum) | Embargo can be enabled at the article or the file level. Possible values: article, file |  [optional]
**embargoReason** | **String** | Reason for setting embargo |  [optional]


<a name="EmbargoTypeEnum"></a>
## Enum: EmbargoTypeEnum
Name | Value
---- | -----
ARTICLE | &quot;article&quot;
FILE | &quot;file&quot;



