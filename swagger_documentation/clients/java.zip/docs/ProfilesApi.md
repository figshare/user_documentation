# ProfilesApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateUserProfile**](ProfilesApi.md#updateUserProfile) | **PUT** /account/profile/{user_id} | Update public profile
[**updateUserProfilePicture**](ProfilesApi.md#updateUserProfilePicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture


<a name="updateUserProfile"></a>
# **updateUserProfile**
> updateUserProfile(userId, userProfileData)

Update public profile

Updates the fields of the user&#39;s public profile.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProfilesApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProfilesApi apiInstance = new ProfilesApi();
Long userId = 789L; // Long | User ID
ProfileUpdateData userProfileData = new ProfileUpdateData(); // ProfileUpdateData | 
try {
    apiInstance.updateUserProfile(userId, userProfileData);
} catch (ApiException e) {
    System.err.println("Exception when calling ProfilesApi#updateUserProfile");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **Long**| User ID |
 **userProfileData** | [**ProfileUpdateData**](ProfileUpdateData.md)|  |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateUserProfilePicture"></a>
# **updateUserProfilePicture**
> updateUserProfilePicture(userId, profilePicture)

Update public profile picture

Updates the profile picture of the user&#39;s public profile.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProfilesApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProfilesApi apiInstance = new ProfilesApi();
Long userId = 789L; // Long | User ID
File profilePicture = new File("/path/to/file.txt"); // File | User profile picture
try {
    apiInstance.updateUserProfilePicture(userId, profilePicture);
} catch (ApiException e) {
    System.err.println("Exception when calling ProfilesApi#updateUserProfilePicture");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **Long**| User ID |
 **profilePicture** | **File**| User profile picture |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

