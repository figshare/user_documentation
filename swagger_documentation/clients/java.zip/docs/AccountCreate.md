
# AccountCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** | Email of account | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**groupId** | **Long** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | 
**institutionUserId** | **String** | Institution user id | 
**symplecticUserId** | **String** | Symplectic user id | 
**quota** | **Long** | Account quota | 
**isActive** | **Boolean** | Is account active | 



