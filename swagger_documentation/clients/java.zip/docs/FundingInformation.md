
# FundingInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Funding id |  [optional]
**title** | **String** | The funding name |  [optional]
**grantCode** | **String** | The grant code |  [optional]
**funderName** | **String** | Funder&#39;s name |  [optional]
**isUserDefined** | **Boolean** | Return whether the grant has been introduced manually |  [optional]
**url** | **String** | The grant url |  [optional]



