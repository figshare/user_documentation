
# LocationWarnings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entityId** | **Long** | Figshare ID of the entity |  [optional]
**location** | **String** | Url for entity |  [optional]
**warnings** | **List&lt;String&gt;** | Issues encountered during the operation |  [optional]



