
# LocationWarnings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** | Url for entity |  [optional]
**warnings** | **List&lt;String&gt;** | Issues encountered during the operation |  [optional]



