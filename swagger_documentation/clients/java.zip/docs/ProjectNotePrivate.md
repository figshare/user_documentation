
# ProjectNotePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Project note id |  [optional]
**userId** | **Long** | User who wrote the note |  [optional]
**_abstract** | **String** | Note Abstract - short/truncated content |  [optional]
**userName** | **String** | Username of the one who wrote the note |  [optional]
**createdDate** | **String** | Date when note was created |  [optional]
**modifiedDate** | **String** | Date when note was last modified |  [optional]



