
# AuthorsCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | **List&lt;Object&gt;** | List of authors to be assosciated with the article. The list can contain author ids or author names [{\&quot;id\&quot;: 12121}, {\&quot;id\&quot;: 34345}, {\&quot;name\&quot;: \&quot;John Doe\&quot;}]. No more than 10 authors. For adding more authors use the specific authors endpoint. | 



