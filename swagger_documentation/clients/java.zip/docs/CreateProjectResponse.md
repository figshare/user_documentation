
# CreateProjectResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entityId** | **Long** | Figshare ID of the entity |  [optional]
**location** | **String** | Url for entity |  [optional]



