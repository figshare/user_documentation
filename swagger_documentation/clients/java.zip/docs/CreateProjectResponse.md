
# CreateProjectResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entityId** | **Long** | Figshare ID of the entity | 
**location** | **String** | Url for entity | 



