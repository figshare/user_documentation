
# PrivateFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | File id |  [optional]
**name** | **String** | File name |  [optional]
**size** | **Long** | File size |  [optional]
**isLinkOnly** | **Boolean** | True if file is hosted somewhere else |  [optional]
**downloadUrl** | **String** | Url for file download |  [optional]
**suppliedMd5** | **String** | File supplied md5 |  [optional]
**computedMd5** | **String** | File computed md5 |  [optional]



