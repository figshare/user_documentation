
# AccountUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupId** | **Long** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups |  [optional]
**isActive** | **Boolean** | Is account active |  [optional]



