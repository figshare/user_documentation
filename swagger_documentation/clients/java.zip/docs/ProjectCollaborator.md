
# ProjectCollaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | Status of collaborator invitation |  [optional]
**roleName** | **String** | Collaborator role |  [optional]
**userId** | **Integer** | Collaborator id |  [optional]
**name** | **String** | Collaborator name |  [optional]



