
# ArticleCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Unique identifier for article |  [optional]
**title** | **String** | Title of article |  [optional]
**doi** | **String** | DOI |  [optional]
**handle** | **String** | Handle |  [optional]
**url** | **String** | Api endpoint for article |  [optional]
**urlPublicHtml** | **String** | Public site endpoint for article |  [optional]
**urlPublicApi** | **String** | Public Api endpoint for article |  [optional]
**urlPrivateHtml** | **String** | Private site endpoint for article |  [optional]
**urlPrivateApi** | **String** | Private Api endpoint for article |  [optional]
**thumb** | **String** | Thumbnail image |  [optional]
**definedType** | **Long** | Type of article identificator |  [optional]
**definedTypeName** | **String** | Name of the article type identificator |  [optional]
**timeline** | [**TimelineUpdate**](TimelineUpdate.md) | Various timeline dates |  [optional]



