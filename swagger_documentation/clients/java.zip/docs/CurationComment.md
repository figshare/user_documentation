
# CurationComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | The ID of the comment. |  [optional]
**accountId** | **Long** | The ID of the account which generated this comment. |  [optional]
**type** | [**TypeEnum**](#TypeEnum) | The ID of the account which generated this comment. |  [optional]
**text** | **String** | The value/content of the comment. |  [optional]


<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
COMMENT | &quot;comment&quot;
APPROVED | &quot;approved&quot;
REJECTED | &quot;rejected&quot;
CLOSED | &quot;closed&quot;



