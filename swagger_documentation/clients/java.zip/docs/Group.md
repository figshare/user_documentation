
# Group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Group id | 
**name** | **String** | Group name | 
**resourceId** | **String** | Group resource id | 
**parentId** | **Long** | Parent group if any | 
**associationCriteria** | **String** | HR code associated with group, if code exists | 



