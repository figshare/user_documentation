
# Group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Group id |  [optional]
**name** | **String** | Group name |  [optional]
**resourceId** | **String** | Group resource id |  [optional]
**parentId** | **Long** | Parent group if any |  [optional]
**associationCriteria** | **String** | HR code associated with group, if code exists |  [optional]



