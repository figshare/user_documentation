
# CollectionComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Collection id |  [optional]
**title** | **String** | Collection title |  [optional]
**doi** | **String** | Collection DOI |  [optional]
**handle** | **String** | Collection Handle |  [optional]
**url** | **String** | Api endpoint |  [optional]



