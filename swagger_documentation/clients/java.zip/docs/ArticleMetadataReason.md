
# ArticleMetadataReason

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isMetadataRecord** | **Boolean** | True if the article is metadata record |  [optional]



