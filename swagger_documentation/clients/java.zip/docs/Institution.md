
# Institution

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Institution id |  [optional]
**name** | **String** | Institution name |  [optional]



