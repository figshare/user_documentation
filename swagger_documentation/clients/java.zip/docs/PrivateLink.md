
# PrivateLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Private link id |  [optional]
**isActive** | **Boolean** | True if private link is active |  [optional]
**expiresDate** | **String** | Date when link will expire |  [optional]
**htmlLocation** | **String** | HTML url for private link |  [optional]



