
# ArticleCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** | Title of article | 
**description** | **String** | The article description. In a publisher case, usually this is the remote article description |  [optional]
**tags** | **List&lt;String&gt;** | List of tags to be associated with the article. Keywords can be used instead |  [optional]
**keywords** | **List&lt;String&gt;** | List of tags to be associated with the article. Tags can be used instead |  [optional]
**references** | **List&lt;String&gt;** | List of links to be associated with the article (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) |  [optional]
**categories** | **List&lt;Long&gt;** | List of category ids to be associated with the article(e.g [1, 23, 33, 66]) |  [optional]
**authors** | **List&lt;Object&gt;** | List of authors to be assosciated with the article. The list can contain author ids or author names. No more than 10 authors. For adding more authors use the specific authors endpoint. |  [optional]
**customFields** | **Object** | List of key, values pairs to be associated with the article |  [optional]
**definedType** | [**DefinedTypeEnum**](#DefinedTypeEnum) | Article type |  [optional]
**funding** | **String** | Grant number or funding authority |  [optional]
**fundingList** | [**List&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items |  [optional]
**license** | **Long** | License id for this article. |  [optional]
**doi** | **String** | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. |  [optional]
**resourceDoi** | **String** | Not applicable to regular users. In a publisher case, this is the publisher article DOI. |  [optional]
**resourceTitle** | **String** | Not applicable to regular users. In a publisher case, this is the publisher article title. |  [optional]
**groupId** | **Long** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups |  [optional]


<a name="DefinedTypeEnum"></a>
## Enum: DefinedTypeEnum
Name | Value
---- | -----
FIGURE | &quot;figure&quot;
MEDIA | &quot;media&quot;
DATASET | &quot;dataset&quot;
FILESET | &quot;fileset&quot;
POSTER | &quot;poster&quot;
PAPER | &quot;paper&quot;
PRESENTATION | &quot;presentation&quot;
THESIS | &quot;thesis&quot;
CODE | &quot;code&quot;
METADATA | &quot;metadata&quot;
PREPRINT | &quot;preprint&quot;
BOOK | &quot;book&quot;



