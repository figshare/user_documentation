
# AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Author id | 
**fullName** | **String** | Author full name | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**isActive** | **Boolean** | True if author has published items | 
**urlName** | **String** | Author url name | 
**orcidId** | **String** | Author Orcid | 
**institutionId** | **Long** | Institution id | 
**groupId** | **Long** | Group id | 
**isPublic** | **Long** | if 1 then the author has published items | 
**jobTitle** | **String** | Job title | 



