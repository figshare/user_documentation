
# ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Account id |  [optional]
**firstName** | **String** | First Name |  [optional]
**lastName** | **String** | Last Name |  [optional]
**institutionId** | **Long** | Account institution |  [optional]
**email** | **String** | User email |  [optional]
**active** | **Long** | Account activity status |  [optional]



