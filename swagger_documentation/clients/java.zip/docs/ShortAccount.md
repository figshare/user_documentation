
# ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Account id |  [optional]
**firstName** | **String** | First Name |  [optional]
**lastName** | **String** | Last Name |  [optional]
**institutionId** | **Long** | Account institution |  [optional]
**email** | **String** | User email |  [optional]
**active** | **Long** | Account activity status |  [optional]
**institutionUserId** | **String** | Account institution user id |  [optional]
**quota** | **Long** | Total storage available to account, in bytes |  [optional]
**usedQuota** | **Long** | Storage used by the account, in bytes |  [optional]
**userId** | **Long** | User id associated with account, useful for example for adding the account as an author to an item |  [optional]
**orcidId** | **String** | ORCID iD associated to account |  [optional]



