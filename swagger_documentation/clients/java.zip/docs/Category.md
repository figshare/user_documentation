
# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentId** | **Long** | Parent category |  [optional]
**id** | **Long** | Category id |  [optional]
**title** | **String** | Category title |  [optional]



