
# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentId** | **Long** | Parent category |  [optional]
**id** | **Long** | Category id |  [optional]
**title** | **String** | Category title |  [optional]
**path** | **String** | Path to all ancestor ids |  [optional]
**sourceId** | **String** | ID in original standard taxonomy |  [optional]
**taxonomyId** | **Long** | Internal id of taxonomy the category is part of |  [optional]



