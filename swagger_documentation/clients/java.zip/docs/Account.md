
# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Account id |  [optional]
**firstName** | **String** | First Name |  [optional]
**lastName** | **String** | Last Name |  [optional]
**usedQuotaPrivate** | **Long** | Account used private quota |  [optional]
**modifiedDate** | **String** | Date of last account modification |  [optional]
**usedQuota** | **Long** | Account total used quota |  [optional]
**createdDate** | **String** | Date when account was created |  [optional]
**quota** | **Long** | Account quota |  [optional]
**groupId** | **Long** | Account group id |  [optional]
**institutionUserId** | **String** | Account institution user id |  [optional]
**institutionId** | **Long** | Account institution |  [optional]
**email** | **String** | User email |  [optional]
**usedQuotaPublic** | **Long** | Account public used quota |  [optional]
**pendingQuotaRequest** | **Boolean** | True if a quota request is pending |  [optional]
**active** | **Long** | Account activity status |  [optional]
**maximumFileSize** | **Long** | Maximum upload size for account |  [optional]



