# CollectionComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Collection id | [optional] [default to null]
**Title** | **string** | Collection title | [optional] [default to null]
**Doi** | **string** | Collection DOI | [optional] [default to null]
**Handle** | **string** | Collection Handle | [optional] [default to null]
**Url** | **string** | Api endpoint | [optional] [default to null]
**Timeline** | [**Timeline**](Timeline.md) | Various timeline dates | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


