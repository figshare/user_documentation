# ProfileUpdateData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstName** | **string** | First name | [optional] [default to null]
**LastName** | **string** | Last Name | [optional] [default to null]
**Orcid** | **string** | User ORCID | [optional] [default to null]
**JobTitle** | **string** | User job title | [optional] [default to null]
**FieldsOfInterest** | **[]int64** | User fields of interest (category ids) | [optional] [default to null]
**FieldsOfInterestBySourceId** | **[]string** | User fields of interest (category source IDs), supersedes the fields_of_interest property | [optional] [default to null]
**Location** | **string** | User location | [optional] [default to null]
**Facebook** | **string** | User facebook URL | [optional] [default to null]
**X** | **string** | User X (twitter) URL | [optional] [default to null]
**Linkedin** | **string** | User linkedin URL | [optional] [default to null]
**Bio** | **string** | User biographical information | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


