# ArticleConfidentiality

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsConfidential** | **bool** | True if article is confidential | [optional] [default to null]
**Reason** | **string** | Reason for confidentiality | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


