# Group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Group id | [optional] [default to null]
**Name** | **string** | Group name | [optional] [default to null]
**ResourceId** | **string** | Group resource id | [optional] [default to null]
**ParentId** | **int64** | Parent group if any | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


