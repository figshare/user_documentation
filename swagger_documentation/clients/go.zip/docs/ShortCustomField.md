# ShortCustomField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Custom field id | [default to null]
**Name** | **string** | Custom field name | [default to null]
**FieldType** | **string** | Custom field type | [default to null]
**Settings** | **interface{}** | Settings for the custom field | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


