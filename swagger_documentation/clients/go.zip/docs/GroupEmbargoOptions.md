# GroupEmbargoOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Embargo option id | [default to null]
**Type_** | **string** | Embargo permission type | [default to null]
**IpName** | **string** | IP range name; value appears if type is ip_range | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


