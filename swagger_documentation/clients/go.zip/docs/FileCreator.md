# FileCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Link** | **string** | Url for an existing file that will not be uploaded on figshare | [optional] [default to null]
**Md5** | **string** | MD5 sum pre computed on the client side | [optional] [default to null]
**Name** | **string** | File name including the extension | [optional] [default to null]
**Size** | **int64** | File size in bytes | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


