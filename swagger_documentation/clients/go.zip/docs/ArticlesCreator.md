# ArticlesCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Articles** | **[]int64** | List of article ids | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


