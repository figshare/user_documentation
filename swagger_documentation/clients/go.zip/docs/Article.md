# Article

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Unique identifier for article | [optional] [default to null]
**Title** | **string** | Title of article | [optional] [default to null]
**Doi** | **string** | DOI | [optional] [default to null]
**Handle** | **string** | Handle | [optional] [default to null]
**Url** | **string** | Api endpoint for article | [optional] [default to null]
**UrlPublicHtml** | **string** | Public site endpoint for article | [optional] [default to null]
**UrlPublicApi** | **string** | Public Api endpoint for article | [optional] [default to null]
**UrlPrivateHtml** | **string** | Private site endpoint for article | [optional] [default to null]
**UrlPrivateApi** | **string** | Private Api endpoint for article | [optional] [default to null]
**Thumb** | **string** | Thumbnail image | [optional] [default to null]
**DefinedType** | **int64** | Type of article identificator | [optional] [default to null]
**DefinedTypeName** | **string** | Name of the article type identificator | [optional] [default to null]
**Timeline** | [**TimelineUpdate**](TimelineUpdate.md) | Various timeline dates | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


