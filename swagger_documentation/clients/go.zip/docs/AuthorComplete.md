# AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Author id | [default to null]
**FullName** | **string** | Author full name | [default to null]
**FirstName** | **string** | First Name | [default to null]
**LastName** | **string** | Last Name | [default to null]
**IsActive** | **bool** | True if author has published items | [default to null]
**UrlName** | **string** | Author url name | [default to null]
**OrcidId** | **string** | Author Orcid | [default to null]
**InstitutionId** | **int64** | Institution id | [default to null]
**GroupId** | **int64** | Group id | [default to null]
**IsPublic** | **int64** | if 1 then the author has published items | [default to null]
**JobTitle** | **string** | Job title | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


