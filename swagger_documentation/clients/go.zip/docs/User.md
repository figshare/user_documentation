# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | User id | [optional] [default to null]
**FirstName** | **string** | First Name | [optional] [default to null]
**LastName** | **string** | Last Name | [optional] [default to null]
**Name** | **string** | Full Name | [optional] [default to null]
**IsActive** | **bool** | Account activity status | [optional] [default to null]
**UrlName** | **string** | Name that appears in website url | [optional] [default to null]
**IsPublic** | **bool** | Account public status | [optional] [default to null]
**JobTitle** | **string** | User Job title | [optional] [default to null]
**OrcidId** | **string** | Orcid associated to this User | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


