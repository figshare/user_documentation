# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParentId** | **int64** | Parent category | [optional] [default to null]
**Id** | **int64** | Category id | [optional] [default to null]
**Title** | **string** | Category title | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


