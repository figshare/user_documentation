# ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Account id | [optional] [default to null]
**FirstName** | **string** | First Name | [optional] [default to null]
**LastName** | **string** | Last Name | [optional] [default to null]
**InstitutionId** | **int64** | Account institution | [optional] [default to null]
**Email** | **string** | User email | [optional] [default to null]
**Active** | **int64** | Account activity status | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


