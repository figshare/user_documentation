# Author

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Author id | [optional] [default to null]
**FullName** | **string** | Author full name | [optional] [default to null]
**IsActive** | **bool** | True if author has published items | [optional] [default to null]
**UrlName** | **string** | Author url name | [optional] [default to null]
**OrcidId** | **string** | Author Orcid | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


