# \DefaultApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AccountArticleReport**](DefaultApi.md#AccountArticleReport) | **Get** /account/articles/export | Account Article Report
[**AccountArticleReportGenerate**](DefaultApi.md#AccountArticleReportGenerate) | **Post** /account/articles/export | Initiate a new Report


# **AccountArticleReport**
> []AccountReport AccountArticleReport($groupId)

Account Article Report

Return status on all reports generated for the account from the oauth credentials


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **int64**| A group ID to filter by | [optional] 

### Return type

[**[]AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AccountArticleReportGenerate**
> AccountReport AccountArticleReportGenerate()

Initiate a new Report

Initiate a new Article Report for this Account


### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

