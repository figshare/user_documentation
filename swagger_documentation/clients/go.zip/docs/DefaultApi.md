# \DefaultApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AccountArticleReportGenerate**](DefaultApi.md#AccountArticleReportGenerate) | **Post** /account/articles/export | Initiate a new Report


# **AccountArticleReportGenerate**
> AccountReport AccountArticleReportGenerate()

Initiate a new Report

Initiate a new Article Report for this Account


### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

