# PrivateLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Private link id | [optional] [default to null]
**IsActive** | **bool** | True if private link is active | [optional] [default to null]
**ExpiresDate** | **string** | Date when link will expire | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


