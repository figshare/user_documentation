# License

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Value** | **int64** | License value | [default to null]
**Name** | **string** | License name | [default to null]
**Url** | **string** | License url | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


