# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Account id | [optional] [default to null]
**FirstName** | **string** | First Name | [optional] [default to null]
**LastName** | **string** | Last Name | [optional] [default to null]
**UsedQuotaPrivate** | **int64** | Account used private quota | [optional] [default to null]
**ModifiedDate** | **string** | Date of last account modification | [optional] [default to null]
**UsedQuota** | **int64** | Account total used quota | [optional] [default to null]
**CreatedDate** | **string** | Date when account was created | [optional] [default to null]
**Quota** | **int64** | Account quota | [optional] [default to null]
**GroupId** | **int64** | Account group id | [optional] [default to null]
**InstitutionUserId** | **string** | Account institution user id | [optional] [default to null]
**InstitutionId** | **int64** | Account institution | [optional] [default to null]
**Email** | **string** | User email | [optional] [default to null]
**UsedQuotaPublic** | **int64** | Account public used quota | [optional] [default to null]
**PendingQuotaRequest** | **bool** | True if a quota request is pending | [optional] [default to null]
**Active** | **int64** | Account activity status | [optional] [default to null]
**MaximumFileSize** | **int64** | Maximum upload size for account | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


