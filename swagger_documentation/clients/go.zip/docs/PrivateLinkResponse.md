# PrivateLinkResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Location** | **string** | Url for private link | [default to null]
**HtmlLocation** | **string** | HTML url for private link | [default to null]
**Token** | **string** | Token for private link | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


