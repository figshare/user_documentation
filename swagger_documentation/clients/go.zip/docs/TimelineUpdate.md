# TimelineUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstOnline** | **string** | Online posted date | [optional] [default to null]
**PublisherPublication** | **string** | Publish date | [optional] [default to null]
**PublisherAcceptance** | **string** | Date when the item was accepted for publication | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


