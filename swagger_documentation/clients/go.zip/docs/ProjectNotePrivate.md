# ProjectNotePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Project note id | [optional] [default to null]
**UserId** | **int64** | User who wrote the note | [optional] [default to null]
**Abstract** | **string** | Note Abstract - short/truncated content | [optional] [default to null]
**UserName** | **string** | Username of the one who wrote the note | [optional] [default to null]
**CreatedDate** | **string** | Date when note was created | [optional] [default to null]
**ModifiedDate** | **string** | Date when note was last modified | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


