# ArticleEmbargoUpdater

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsEmbargoed** | **bool** | Confidentiality status | [optional] [default to null]
**EmbargoDate** | **string** | Date when the embargo expires and the article gets published | [optional] [default to null]
**EmbargoType** | **string** | Embargo can be enabled at the article or the file level. Possible values: article, file | [optional] [default to null]
**EmbargoReason** | **string** | Reason for setting embargo | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


