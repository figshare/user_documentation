# ProjectCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** | The title for this project - mandatory. 3 - 500 characters. | [default to null]
**Description** | **string** | Project description | [optional] [default to null]
**Funding** | **string** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] [default to null]
**FundingList** | [**[]FundingCreate**](FundingCreate.md) | Funding creation / update items | [optional] [default to null]
**GroupId** | **int64** | Only if project type is group. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


