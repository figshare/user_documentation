# PublicFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | File id | [optional] [default to null]
**Name** | **string** | File name | [optional] [default to null]
**Size** | **int64** | File size | [optional] [default to null]
**IsLinkOnly** | **bool** | True if file is hosted somewhere else | [optional] [default to null]
**DownloadUrl** | **string** | Url for file download | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


