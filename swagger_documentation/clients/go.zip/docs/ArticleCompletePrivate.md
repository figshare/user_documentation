# ArticleCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Unique identifier for article | [optional] [default to null]
**Title** | **string** | Title of article | [optional] [default to null]
**Doi** | **string** | DOI | [optional] [default to null]
**Url** | **string** | Api endpoint for article | [optional] [default to null]
**UrlPublicHtml** | **string** | Public site endpoint for article | [optional] [default to null]
**UrlPublicApi** | **string** | Public Api endpoint for article | [optional] [default to null]
**UrlPrivateHtml** | **string** | Private site endpoint for article | [optional] [default to null]
**UrlPrivateApi** | **string** | Private Api endpoint for article | [optional] [default to null]
**Thumb** | **string** | Thumbnail image | [optional] [default to null]
**DefinedType** | **int64** | Integer which is mapped to item types as: 1 - Figure, 2 - Media, 3 - Dataset, 4 - Fileset, 5 - Poster, 6 - Paper, 7 - Presentation, 8 - Thesis, 9 - Code, 11 - Metadata, 12 - Preprint | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


