# ProfileUpdateDataPersonalProfiles

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Label** | **string** | Label for the personal profile link | [optional] [default to null]
**Url** | **string** | URL for the personal profile link | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


