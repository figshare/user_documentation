package 

import (
	"net/http"
	"fmt"
	"github.com/gorilla/mux"
)

type Route struct {
	Name        string
	Method      string
	Pattern     string
	HandlerFunc http.HandlerFunc
}

type Routes []Route

func NewRouter() *mux.Router {
	router := mux.NewRouter().StrictSlash(true)
	for _, route := range routes {
		var handler http.Handler
		handler = route.HandlerFunc
		handler = Logger(handler, route.Name)

		router.
			Methods(route.Method).
			Path(route.Pattern).
			Name(route.Name).
			Handler(handler)
	}

	return router
}

func Index(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Hello World!")
}

var routes = Routes{
	Route{
		"Index",
		"GET",
		"/v2/",
		Index,
	},

	Route{
		"ArticleDetails",
		"GET",
		"/v2/articles/{article_id}",
		ArticleDetails,
	},

	Route{
		"ArticleFileDetails",
		"GET",
		"/v2/articles/{article_id}/files/{file_id}",
		ArticleFileDetails,
	},

	Route{
		"ArticleFiles",
		"GET",
		"/v2/articles/{article_id}/files",
		ArticleFiles,
	},

	Route{
		"ArticleVersionConfidentiality",
		"GET",
		"/v2/articles/{article_id}/versions/{v_number}/confidentiality",
		ArticleVersionConfidentiality,
	},

	Route{
		"ArticleVersionDetails",
		"GET",
		"/v2/articles/{article_id}/versions/{v_number}",
		ArticleVersionDetails,
	},

	Route{
		"ArticleVersionEmbargo",
		"GET",
		"/v2/articles/{article_id}/versions/{v_number}/embargo",
		ArticleVersionEmbargo,
	},

	Route{
		"ArticleVersions",
		"GET",
		"/v2/articles/{article_id}/versions",
		ArticleVersions,
	},

	Route{
		"ArticlesList",
		"GET",
		"/v2/articles",
		ArticlesList,
	},

	Route{
		"ArticlesSearch",
		"POST",
		"/v2/articles/search",
		ArticlesSearch,
	},

	Route{
		"PrivateArticleAuthorDelete",
		"DELETE",
		"/v2/account/articles/{article_id}/authors/{author_id}",
		PrivateArticleAuthorDelete,
	},

	Route{
		"PrivateArticleAuthorsAdd",
		"POST",
		"/v2/account/articles/{article_id}/authors",
		PrivateArticleAuthorsAdd,
	},

	Route{
		"PrivateArticleAuthorsList",
		"GET",
		"/v2/account/articles/{article_id}/authors",
		PrivateArticleAuthorsList,
	},

	Route{
		"PrivateArticleAuthorsReplace",
		"PUT",
		"/v2/account/articles/{article_id}/authors",
		PrivateArticleAuthorsReplace,
	},

	Route{
		"PrivateArticleCategoriesAdd",
		"POST",
		"/v2/account/articles/{article_id}/categories",
		PrivateArticleCategoriesAdd,
	},

	Route{
		"PrivateArticleCategoriesList",
		"GET",
		"/v2/account/articles/{article_id}/categories",
		PrivateArticleCategoriesList,
	},

	Route{
		"PrivateArticleCategoriesReplace",
		"PUT",
		"/v2/account/articles/{article_id}/categories",
		PrivateArticleCategoriesReplace,
	},

	Route{
		"PrivateArticleCategoryDelete",
		"DELETE",
		"/v2/account/articles/{article_id}/categories/{category_id}",
		PrivateArticleCategoryDelete,
	},

	Route{
		"PrivateArticleConfidentialityDelete",
		"DELETE",
		"/v2/account/articles/{article_id}/confidentiality",
		PrivateArticleConfidentialityDelete,
	},

	Route{
		"PrivateArticleConfidentialityDetails",
		"GET",
		"/v2/account/articles/{article_id}/confidentiality",
		PrivateArticleConfidentialityDetails,
	},

	Route{
		"PrivateArticleConfidentialityUpdate",
		"PUT",
		"/v2/account/articles/{article_id}/confidentiality",
		PrivateArticleConfidentialityUpdate,
	},

	Route{
		"PrivateArticleCreate",
		"POST",
		"/v2/account/articles",
		PrivateArticleCreate,
	},

	Route{
		"PrivateArticleDelete",
		"DELETE",
		"/v2/account/articles/{article_id}",
		PrivateArticleDelete,
	},

	Route{
		"PrivateArticleDetails",
		"GET",
		"/v2/account/articles/{article_id}",
		PrivateArticleDetails,
	},

	Route{
		"PrivateArticleEmbargoDelete",
		"DELETE",
		"/v2/account/articles/{article_id}/embargo",
		PrivateArticleEmbargoDelete,
	},

	Route{
		"PrivateArticleEmbargoDetails",
		"GET",
		"/v2/account/articles/{article_id}/embargo",
		PrivateArticleEmbargoDetails,
	},

	Route{
		"PrivateArticleEmbargoUpdate",
		"PUT",
		"/v2/account/articles/{article_id}/embargo",
		PrivateArticleEmbargoUpdate,
	},

	Route{
		"PrivateArticleFile",
		"GET",
		"/v2/account/articles/{article_id}/files/{file_id}",
		PrivateArticleFile,
	},

	Route{
		"PrivateArticleFileDelete",
		"DELETE",
		"/v2/account/articles/{article_id}/files/{file_id}",
		PrivateArticleFileDelete,
	},

	Route{
		"PrivateArticleFilesList",
		"GET",
		"/v2/account/articles/{article_id}/files",
		PrivateArticleFilesList,
	},

	Route{
		"PrivateArticlePrivateLink",
		"GET",
		"/v2/account/articles/{article_id}/private_links",
		PrivateArticlePrivateLink,
	},

	Route{
		"PrivateArticlePrivateLinkCreate",
		"POST",
		"/v2/account/articles/{article_id}/private_links",
		PrivateArticlePrivateLinkCreate,
	},

	Route{
		"PrivateArticlePrivateLinkDelete",
		"DELETE",
		"/v2/account/articles/{article_id}/private_links/{link_id}",
		PrivateArticlePrivateLinkDelete,
	},

	Route{
		"PrivateArticlePrivateLinkUpdate",
		"PUT",
		"/v2/account/articles/{article_id}/private_links/{link_id}",
		PrivateArticlePrivateLinkUpdate,
	},

	Route{
		"PrivateArticlePublish",
		"POST",
		"/v2/account/articles/{article_id}/publish",
		PrivateArticlePublish,
	},

	Route{
		"PrivateArticleReserveDoi",
		"POST",
		"/v2/account/articles/{article_id}/reserve_doi",
		PrivateArticleReserveDoi,
	},

	Route{
		"PrivateArticleUpdate",
		"PUT",
		"/v2/account/articles/{article_id}",
		PrivateArticleUpdate,
	},

	Route{
		"PrivateArticleUploadComplete",
		"POST",
		"/v2/account/articles/{article_id}/files/{file_id}",
		PrivateArticleUploadComplete,
	},

	Route{
		"PrivateArticleUploadInitiate",
		"POST",
		"/v2/account/articles/{article_id}/files",
		PrivateArticleUploadInitiate,
	},

	Route{
		"PrivateArticlesList",
		"GET",
		"/v2/account/articles",
		PrivateArticlesList,
	},

	Route{
		"PrivateArticlesSearch",
		"POST",
		"/v2/account/articles/search",
		PrivateArticlesSearch,
	},

	Route{
		"PrivateAuthorDetails",
		"GET",
		"/v2/account/authors/{author_id}",
		PrivateAuthorDetails,
	},

	Route{
		"PrivateAuthorsSearch",
		"POST",
		"/v2/account/authors/search",
		PrivateAuthorsSearch,
	},

	Route{
		"CollectionArticles",
		"GET",
		"/v2/collections/{collection_id}/articles",
		CollectionArticles,
	},

	Route{
		"CollectionDetails",
		"GET",
		"/v2/collections/{collection_id}",
		CollectionDetails,
	},

	Route{
		"CollectionVersionDetails",
		"GET",
		"/v2/collections/{collection_id}/versions/{version_id}",
		CollectionVersionDetails,
	},

	Route{
		"CollectionVersions",
		"GET",
		"/v2/collections/{collection_id}/versions",
		CollectionVersions,
	},

	Route{
		"CollectionsList",
		"GET",
		"/v2/collections",
		CollectionsList,
	},

	Route{
		"CollectionsSearch",
		"POST",
		"/v2/collections/search",
		CollectionsSearch,
	},

	Route{
		"PrivateCollectionArticleDelete",
		"DELETE",
		"/v2/account/collections/{collection_id}/articles/{article_id}",
		PrivateCollectionArticleDelete,
	},

	Route{
		"PrivateCollectionArticlesAdd",
		"POST",
		"/v2/account/collections/{collection_id}/articles",
		PrivateCollectionArticlesAdd,
	},

	Route{
		"PrivateCollectionArticlesList",
		"GET",
		"/v2/account/collections/{collection_id}/articles",
		PrivateCollectionArticlesList,
	},

	Route{
		"PrivateCollectionArticlesReplace",
		"PUT",
		"/v2/account/collections/{collection_id}/articles",
		PrivateCollectionArticlesReplace,
	},

	Route{
		"PrivateCollectionAuthorDelete",
		"DELETE",
		"/v2/account/collections/{collection_id}/authors/{author_id}",
		PrivateCollectionAuthorDelete,
	},

	Route{
		"PrivateCollectionAuthorsAdd",
		"POST",
		"/v2/account/collections/{collection_id}/authors",
		PrivateCollectionAuthorsAdd,
	},

	Route{
		"PrivateCollectionAuthorsList",
		"GET",
		"/v2/account/collections/{collection_id}/authors",
		PrivateCollectionAuthorsList,
	},

	Route{
		"PrivateCollectionAuthorsReplace",
		"PUT",
		"/v2/account/collections/{collection_id}/authors",
		PrivateCollectionAuthorsReplace,
	},

	Route{
		"PrivateCollectionCategoriesAdd",
		"POST",
		"/v2/account/collections/{collection_id}/categories",
		PrivateCollectionCategoriesAdd,
	},

	Route{
		"PrivateCollectionCategoriesList",
		"GET",
		"/v2/account/collections/{collection_id}/categories",
		PrivateCollectionCategoriesList,
	},

	Route{
		"PrivateCollectionCategoriesReplace",
		"PUT",
		"/v2/account/collections/{collection_id}/categories",
		PrivateCollectionCategoriesReplace,
	},

	Route{
		"PrivateCollectionCategoryDelete",
		"DELETE",
		"/v2/account/collections/{collection_id}/categories/{category_id}",
		PrivateCollectionCategoryDelete,
	},

	Route{
		"PrivateCollectionCreate",
		"POST",
		"/v2/account/collections",
		PrivateCollectionCreate,
	},

	Route{
		"PrivateCollectionDelete",
		"DELETE",
		"/v2/account/collections/{collection_id}",
		PrivateCollectionDelete,
	},

	Route{
		"PrivateCollectionDetails",
		"GET",
		"/v2/account/collections/{collection_id}",
		PrivateCollectionDetails,
	},

	Route{
		"PrivateCollectionPrivateLinkCreate",
		"POST",
		"/v2/account/collections/{collection_id}/private_links",
		PrivateCollectionPrivateLinkCreate,
	},

	Route{
		"PrivateCollectionPrivateLinkDelete",
		"DELETE",
		"/v2/account/collections/{collection_id}/private_links/{link_id}",
		PrivateCollectionPrivateLinkDelete,
	},

	Route{
		"PrivateCollectionPrivateLinkUpdate",
		"PUT",
		"/v2/account/collections/{collection_id}/private_links/{link_id}",
		PrivateCollectionPrivateLinkUpdate,
	},

	Route{
		"PrivateCollectionPrivateLinksList",
		"GET",
		"/v2/account/collections/{collection_id}/private_links",
		PrivateCollectionPrivateLinksList,
	},

	Route{
		"PrivateCollectionPublish",
		"POST",
		"/v2/account/collections/{collection_id}/publish",
		PrivateCollectionPublish,
	},

	Route{
		"PrivateCollectionReserveDoi",
		"POST",
		"/v2/account/collections/{collection_id}/reserve_doi",
		PrivateCollectionReserveDoi,
	},

	Route{
		"PrivateCollectionUpdate",
		"PUT",
		"/v2/account/collections/{collection_id}",
		PrivateCollectionUpdate,
	},

	Route{
		"PrivateCollectionsList",
		"GET",
		"/v2/account/collections",
		PrivateCollectionsList,
	},

	Route{
		"PrivateCollectionsSearch",
		"POST",
		"/v2/account/collections/search",
		PrivateCollectionsSearch,
	},

	Route{
		"InstitutionArticles",
		"GET",
		"/v2/institutions/{institution_string_id}/articles/filter-by",
		InstitutionArticles,
	},

	Route{
		"InstitutionHrfeedUpload",
		"POST",
		"/v2/institution/hrfeed/upload",
		InstitutionHrfeedUpload,
	},

	Route{
		"PrivateCategoriesList",
		"GET",
		"/v2/account/categories",
		PrivateCategoriesList,
	},

	Route{
		"PrivateInstitutionAccountsList",
		"GET",
		"/v2/account/institution/accounts",
		PrivateInstitutionAccountsList,
	},

	Route{
		"PrivateInstitutionAccountsSearch",
		"POST",
		"/v2/account/institution/accounts/search",
		PrivateInstitutionAccountsSearch,
	},

	Route{
		"PrivateInstitutionArticles",
		"GET",
		"/v2/account/institution/articles",
		PrivateInstitutionArticles,
	},

	Route{
		"PrivateInstitutionDetails",
		"GET",
		"/v2/account/institution",
		PrivateInstitutionDetails,
	},

	Route{
		"PrivateInstitutionGroupsList",
		"GET",
		"/v2/account/institution/groups",
		PrivateInstitutionGroupsList,
	},

	Route{
		"CategoriesList",
		"GET",
		"/v2/categories",
		CategoriesList,
	},

	Route{
		"FileDownload",
		"GET",
		"/v2/file/download/{file_id}",
		FileDownload,
	},

	Route{
		"LicensesList",
		"GET",
		"/v2/licenses",
		LicensesList,
	},

	Route{
		"PrivateAccount",
		"GET",
		"/v2/account",
		PrivateAccount,
	},

	Route{
		"PrivateLicensesList",
		"GET",
		"/v2/account/licenses",
		PrivateLicensesList,
	},

	Route{
		"PrivateProjectArticleDelete",
		"DELETE",
		"/v2/account/projects/{project_id}/articles/{article_id}",
		PrivateProjectArticleDelete,
	},

	Route{
		"PrivateProjectArticleDetails",
		"GET",
		"/v2/account/projects/{project_id}/articles/{article_id}",
		PrivateProjectArticleDetails,
	},

	Route{
		"PrivateProjectArticleFile",
		"GET",
		"/v2/account/projects/{project_id}/articles/{article_id}/files/{file_id}",
		PrivateProjectArticleFile,
	},

	Route{
		"PrivateProjectArticleFiles",
		"GET",
		"/v2/account/projects/{project_id}/articles/{article_id}/files",
		PrivateProjectArticleFiles,
	},

	Route{
		"PrivateProjectArticlesCreate",
		"POST",
		"/v2/account/projects/{project_id}/articles",
		PrivateProjectArticlesCreate,
	},

	Route{
		"PrivateProjectArticlesList",
		"GET",
		"/v2/account/projects/{project_id}/articles",
		PrivateProjectArticlesList,
	},

	Route{
		"PrivateProjectCollaboratorDelete",
		"DELETE",
		"/v2/account/projects/{project_id}/collaborators/{user_id}",
		PrivateProjectCollaboratorDelete,
	},

	Route{
		"PrivateProjectCollaboratorsInvite",
		"POST",
		"/v2/account/projects/{project_id}/collaborators",
		PrivateProjectCollaboratorsInvite,
	},

	Route{
		"PrivateProjectCollaboratorsList",
		"GET",
		"/v2/account/projects/{project_id}/collaborators",
		PrivateProjectCollaboratorsList,
	},

	Route{
		"PrivateProjectCreate",
		"POST",
		"/v2/account/projects",
		PrivateProjectCreate,
	},

	Route{
		"PrivateProjectDelete",
		"DELETE",
		"/v2/account/projects/{project_id}",
		PrivateProjectDelete,
	},

	Route{
		"PrivateProjectDetails",
		"GET",
		"/v2/account/projects/{project_id}",
		PrivateProjectDetails,
	},

	Route{
		"PrivateProjectLeave",
		"POST",
		"/v2/account/projects/{project_id}/leave",
		PrivateProjectLeave,
	},

	Route{
		"PrivateProjectNote",
		"GET",
		"/v2/account/projects/{project_id}/notes/{note_id}",
		PrivateProjectNote,
	},

	Route{
		"PrivateProjectNoteDelete",
		"DELETE",
		"/v2/account/projects/{project_id}/notes/{note_id}",
		PrivateProjectNoteDelete,
	},

	Route{
		"PrivateProjectNoteUpdate",
		"PUT",
		"/v2/account/projects/{project_id}/notes/{note_id}",
		PrivateProjectNoteUpdate,
	},

	Route{
		"PrivateProjectNotesCreate",
		"POST",
		"/v2/account/projects/{project_id}/notes",
		PrivateProjectNotesCreate,
	},

	Route{
		"PrivateProjectNotesList",
		"GET",
		"/v2/account/projects/{project_id}/notes",
		PrivateProjectNotesList,
	},

	Route{
		"PrivateProjectPublish",
		"POST",
		"/v2/account/projects/{project_id}/publish",
		PrivateProjectPublish,
	},

	Route{
		"PrivateProjectUpdate",
		"PUT",
		"/v2/account/projects/{project_id}",
		PrivateProjectUpdate,
	},

	Route{
		"PrivateProjectsList",
		"GET",
		"/v2/account/projects",
		PrivateProjectsList,
	},

	Route{
		"PrivateProjectsSearch",
		"POST",
		"/v2/account/projects/search",
		PrivateProjectsSearch,
	},

	Route{
		"ProjectArticles",
		"GET",
		"/v2/projects/{project_id}/articles",
		ProjectArticles,
	},

	Route{
		"ProjectDetails",
		"GET",
		"/v2/projects/{project_id}",
		ProjectDetails,
	},

	Route{
		"ProjectsList",
		"GET",
		"/v2/projects",
		ProjectsList,
	},

	Route{
		"ProjectsSearch",
		"POST",
		"/v2/projects/search",
		ProjectsSearch,
	},

}