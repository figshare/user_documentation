# SwaggerClient::Institution

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Institution id | [optional] 
**name** | **String** | Institution name | [optional] 


