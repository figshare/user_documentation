# SwaggerClient::ArticleEmbargo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_embargoed** | **BOOLEAN** | True if embargoed | [optional] 
**embargo_title** | **String** | Title for embargo | [optional] 
**embargo_reason** | **String** | Reason for embargo | [optional] 
**embargo_options** | **Array&lt;Object&gt;** | List of embargo permissions that are associated with the article. If the type is logged_in and the group_ids list is empty, then the whole institution can see the article; if there are multiple group_ids, then only users that are under those groups can see the article. | [optional] 


