# SwaggerClient::ProjectCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **String** | Role inside this project | [optional] 
**storage** | **String** | Project storage type | [optional] 
**url** | **String** | Api endpoint | 
**id** | **Integer** | Project id | 
**title** | **String** | Project title | 
**funding** | **String** | Project funding | 
**funding_list** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [**Array&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators | 
**quota** | **Integer** | Project quota | 
**used_quota** | **Integer** | Project used quota | 
**created_date** | **String** | Date when project was created | 
**modified_date** | **String** | Date when project was last modified | 
**used_quota_private** | **Integer** | Project private quota used | 
**used_quota_public** | **Integer** | Project public quota used | 
**group_id** | **Integer** | Group of project if any | 
**account_id** | **Integer** | ID of the account owning the project | 
**custom_fields** | [**Array&lt;CustomArticleField&gt;**](CustomArticleField.md) | Collection custom fields | 


