# SwaggerClient::AccountReport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | A unique ID for the AccountRecord | [optional] 
**account_id** | **Integer** | The ID of the account which generated this report. | [optional] 
**created_date** | **String** | Date when the AccountReport was requested | [optional] 
**status** | **String** | Status of the report | [optional] 
**download_url** | **String** | The download link for the generated XLSX | [optional] 
**group_id** | **Integer** | The group ID that was used to filter the report, if any. | [optional] 


