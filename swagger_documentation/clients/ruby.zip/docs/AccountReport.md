# SwaggerClient::AccountReport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | A unique ID for the AccountRecord | 
**account_id** | **Integer** | The ID of the account which generated this report. | 
**created_date** | **String** | Date when the AccountReport was requested | 
**status** | **String** | Status of the report | 
**download_url** | **String** | The download link for the generated XLSX | 
**group_id** | **Integer** | The group ID that was used to filter the report, if any. | 


