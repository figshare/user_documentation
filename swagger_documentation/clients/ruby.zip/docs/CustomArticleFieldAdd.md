# SwaggerClient::CustomArticleFieldAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Custom  metadata name | 
**value** | **Object** | Custom metadata value (can be either a string or an array of strings) | 


