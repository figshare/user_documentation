# SwaggerClient::PrivateLinkResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** | Url for private link | [optional] 
**token** | **String** | Token for private link | [optional] 


