# SwaggerClient::ArticleCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**figshare_url** | **String** | Article public url | [optional] 
**download_disabled** | **BOOLEAN** | If true, downloading of files for this article is disabled | [optional] 
**files** | [**Array&lt;PublicFile&gt;**](PublicFile.md) | List of article files | [optional] 
**authors** | [**Array&lt;Author&gt;**](Author.md) | List of article authors | [optional] 
**custom_fields** | [**Array&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values | [optional] 
**embargo_options** | [**Array&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md) | List of embargo options | [optional] 
**citation** | **String** | Article citation | [optional] 
**confidential_reason** | **String** | Confidentiality reason | [optional] 
**is_confidential** | **BOOLEAN** | Article Confidentiality | [optional] 
**size** | **Integer** | Article size | [optional] 
**funding** | **String** | Article funding | [optional] 
**funding_list** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Article funding information | [optional] 
**tags** | **Array&lt;String&gt;** | List of article tags | [optional] 
**version** | **Integer** | Article version | [optional] 
**is_active** | **BOOLEAN** | True if article is active | [optional] 
**is_metadata_record** | **BOOLEAN** | True if article has no files | [optional] 
**metadata_reason** | **String** | Article metadata reason | [optional] 
**status** | **String** | Article status | [optional] 
**description** | **String** | Article description | [optional] 
**is_embargoed** | **BOOLEAN** | True if article is embargoed | [optional] 
**is_public** | **BOOLEAN** | True if article is published | [optional] 
**created_date** | **String** | Date when article was created | [optional] 
**has_linked_file** | **BOOLEAN** | True if any files are linked to the article | [optional] 
**categories** | [**Array&lt;Category&gt;**](Category.md) | List of categories selected for the article | [optional] 
**license** | [**License**](License.md) | Article selected license | [optional] 
**embargo_title** | **String** | Title for embargo | [optional] 
**embargo_reason** | **String** | Reason for embargo | [optional] 
**references** | **Array&lt;String&gt;** | List of references | [optional] 
**related_materials** | [**Array&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**id** | **Integer** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**url_public_html** | **String** | Public site endpoint for article | 
**url_public_api** | **String** | Public Api endpoint for article | 
**url_private_html** | **String** | Private site endpoint for article | 
**url_private_api** | **String** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **String** | Thumbnail image | 
**defined_type** | **Integer** | Type of article identifier | 
**defined_type_name** | **String** | Name of the article type identifier | 
**account_id** | **Integer** | ID of the account owning the article | 


