# SwaggerClient::CurationComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | The ID of the comment. | [optional] 
**account_id** | **Integer** | The ID of the account which generated this comment. | [optional] 
**type** | **String** | The ID of the account which generated this comment. | [optional] 
**text** | **String** | The value/content of the comment. | [optional] 


