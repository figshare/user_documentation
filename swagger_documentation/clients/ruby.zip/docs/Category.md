# SwaggerClient::Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **Integer** | Parent category | [optional] 
**id** | **Integer** | Category id | [optional] 
**title** | **String** | Category title | [optional] 
**path** | **String** | Path to all ancestor ids | [optional] 
**source_id** | **String** | ID in original standard taxonomy | [optional] 
**taxonomy_id** | **Integer** | Internal id of taxonomy the category is part of | [optional] 


