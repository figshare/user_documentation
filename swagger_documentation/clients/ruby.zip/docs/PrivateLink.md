# SwaggerClient::PrivateLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Private link id | 
**is_active** | **BOOLEAN** | True if private link is active | 
**expires_date** | **String** | Date when link will expire | 
**html_location** | **String** | HTML url for private link | 


