# SwaggerClient::PrivateLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Private link id | [optional] 
**is_active** | **BOOLEAN** | True if private link is active | [optional] 
**expires_date** | **String** | Date when link will expire | [optional] 
**html_location** | **String** | HTML url for private link | [optional] 


