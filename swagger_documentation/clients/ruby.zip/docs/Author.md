# SwaggerClient::Author

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Author id | 
**full_name** | **String** | Author full name | 
**first_name** | **String** | Author first name | 
**last_name** | **String** | Author last name | 
**is_active** | **BOOLEAN** | True if author has published items | 
**url_name** | **String** | Author url name | 
**orcid_id** | **String** | Author Orcid | 


