# SwaggerClient::ShortCustomField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Custom field id | [optional] 
**name** | **String** | Custom field name | [optional] 
**field_type** | **String** | Custom field type | [optional] 


