# SwaggerClient::ShortCustomField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Custom field id | 
**name** | **String** | Custom field name | 
**field_type** | **String** | Custom field type | 


