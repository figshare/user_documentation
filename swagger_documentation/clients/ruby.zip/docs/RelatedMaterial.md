# SwaggerClient::RelatedMaterial

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | The ID of the related material; can be used to add existing materials of the same account to items. | [optional] 
**identifier** | **String** | The related material identifier (e.g., DOI, Handle, ISBN) | [optional] 
**title** | **String** | The related material title | [optional] 
**relation** | **String** | The relation between the item and the related material; defaults to &#39;References&#39; | [optional] [default to &quot;References&quot;]
**identifier_type** | **String** | The type of the identifier of the related material; defaults to &#39;URL&#39; | [optional] [default to &quot;URL&quot;]
**is_linkout** | **BOOLEAN** | Flag for highlighting this related material in the call-out box | [optional] 
**link** | **String** | The full hyperlink for the identifier | [optional] 


