# SwaggerClient::DefaultApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**account_article_report_generate**](DefaultApi.md#account_article_report_generate) | **POST** /account/articles/export | Initiate a new Report


# **account_article_report_generate**
> AccountReport account_article_report_generate

Initiate a new Report

Initiate a new Article Report for this Account

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::DefaultApi.new

begin
  #Initiate a new Report
  result = api_instance.account_article_report_generate
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling DefaultApi->account_article_report_generate: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json



