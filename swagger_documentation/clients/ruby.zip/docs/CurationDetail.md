# SwaggerClient::CurationDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | The review id | [optional] 
**group_id** | **Integer** | The group in which the article is present. | [optional] 
**account_id** | **Integer** | The ID of the account of the owner of the article of this review. | [optional] 
**assigned_to** | **Integer** | The ID of the account to which this review is assigned. | [optional] 
**article_id** | **Integer** | The ID of the article of this review. | [optional] 
**version** | **Integer** | The Version number of the article in review. | [optional] 
**comments_count** | **Integer** | The number of comments in the review. | [optional] 
**status** | **String** | The status of the review. | [optional] 
**created_date** | **String** | The creation date of the review. | [optional] 
**modified_date** | **String** | The date the review has been modified. | [optional] 


