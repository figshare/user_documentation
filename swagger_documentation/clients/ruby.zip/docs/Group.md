# SwaggerClient::Group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Group id | [optional] 
**name** | **String** | Group name | [optional] 
**resource_id** | **String** | Group resource id | [optional] 
**parent_id** | **Integer** | Parent group if any | [optional] 
**association_criteria** | **String** | HR code associated with group, if code exists | [optional] 


