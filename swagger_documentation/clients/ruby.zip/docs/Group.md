# SwaggerClient::Group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Group id | 
**name** | **String** | Group name | 
**resource_id** | **String** | Group resource id | 
**parent_id** | **Integer** | Parent group if any | 
**association_criteria** | **String** | HR code associated with group, if code exists | 


