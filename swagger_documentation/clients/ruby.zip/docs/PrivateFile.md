# SwaggerClient::PrivateFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | File id | 
**name** | **String** | File name | 
**size** | **Integer** | File size | 
**is_link_only** | **BOOLEAN** | True if file is hosted somewhere else | 
**download_url** | **String** | Url for file download | 
**supplied_md5** | **String** | File supplied md5 | 
**computed_md5** | **String** | File computed md5 | 
**mimetype** | **String** | MIME Type of the file, it defaults to an empty string | [optional] 
**viewer_type** | **String** | File viewer type | 
**preview_state** | **String** | File preview state | 
**upload_url** | **String** | Upload url for file | 
**upload_token** | **String** | Token for file upload | 
**is_attached_to_public_version** | **BOOLEAN** | True if the file is attached to a public item version | 


