# SwaggerClient::ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Account id | [optional] 
**first_name** | **String** | First Name | [optional] 
**last_name** | **String** | Last Name | [optional] 
**institution_id** | **Integer** | Account institution | [optional] 
**email** | **String** | User email | [optional] 
**active** | **Integer** | Account activity status | [optional] 
**institution_user_id** | **String** | Account institution user id | [optional] 
**quota** | **Integer** | Total storage available to account, in bytes | [optional] 
**used_quota** | **Integer** | Storage used by the account, in bytes | [optional] 
**user_id** | **Integer** | User id associated with account, useful for example for adding the account as an author to an item | [optional] 
**orcid_id** | **String** | ORCID iD associated to account | [optional] 


