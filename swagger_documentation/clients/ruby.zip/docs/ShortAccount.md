# SwaggerClient::ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Account id | [optional] 
**first_name** | **String** | First Name | [optional] 
**last_name** | **String** | Last Name | [optional] 
**institution_id** | **Integer** | Account institution | [optional] 
**email** | **String** | User email | [optional] 
**active** | **Integer** | Account activity status | [optional] 


