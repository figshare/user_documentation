# SwaggerClient::Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | ID of resource item | [optional] [default to &#39;&#39;]
**title** | **String** | Title of resource item | [optional] [default to &#39;&#39;]
**doi** | **String** | DOI of resource item | [optional] [default to &#39;&#39;]
**link** | **String** | Link of resource item | [optional] [default to &#39;&#39;]
**status** | **String** | Status of resource item | [optional] [default to &#39;&#39;]
**version** | **Integer** | Version of resource item | [optional] [default to 0]


