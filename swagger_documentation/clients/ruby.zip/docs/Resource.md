# SwaggerClient::Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | ID of resource item | [optional] [default to &quot;&quot;]
**title** | **String** | Title of resource item | [optional] [default to &quot;&quot;]
**doi** | **String** | DOI of resource item | [optional] [default to &quot;&quot;]
**link** | **String** | Link of resource item | [optional] [default to &quot;&quot;]
**status** | **String** | Status of resource item | [optional] [default to &quot;&quot;]
**version** | **Integer** | Version of resource item | [optional] [default to 0]


