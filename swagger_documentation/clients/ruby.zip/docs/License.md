# SwaggerClient::License

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Integer** | License value | [optional] 
**name** | **String** | License name | [optional] 
**url** | **String** | License url | [optional] 


