# SwaggerClient::License

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Integer** | License value | 
**name** | **String** | License name | 
**url** | **String** | License url | 


