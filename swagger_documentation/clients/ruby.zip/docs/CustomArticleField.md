# SwaggerClient::CustomArticleField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Custom  metadata name | [optional] 
**value** | **String** | Custom metadata value | [optional] 


