# SwaggerClient::ArticleMetadataReasonUpdater

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metadata_reason** | **String** | Reason for defining the article as metadata record | 


