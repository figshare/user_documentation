# SwaggerClient::AccountGroupRolesCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


