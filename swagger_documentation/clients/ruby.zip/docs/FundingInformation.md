# SwaggerClient::FundingInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Funding id | [optional] 
**title** | **String** | The funding name | [optional] 
**grant_code** | **String** | The grant code | [optional] 
**funder_name** | **String** | Funder&#39;s name | [optional] 
**is_user_defined** | **BOOLEAN** | Return whether the grant has been introduced manually | [optional] 
**url** | **String** | The grant url | [optional] 


