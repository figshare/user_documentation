# SwaggerClient::FundingInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Funding id | 
**title** | **String** | The funding name | 
**grant_code** | **String** | The grant code | 
**funder_name** | **String** | Funder&#39;s name | 
**is_user_defined** | **Integer** | Return 1 whether the grant has been introduced manually, 0 otherwise | 
**url** | **String** | The grant url | 


