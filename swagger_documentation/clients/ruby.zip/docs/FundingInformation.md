# SwaggerClient::FundingInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Funding id | 
**title** | **String** | The funding name | 
**grant_code** | **String** | The grant code | 
**funder_name** | **String** | Funder&#39;s name | 
**is_user_defined** | **BOOLEAN** | Return whether the grant has been introduced manually | 
**url** | **String** | The grant url | 


