# SwaggerClient::ProjectComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Api endpoint | [optional] 
**id** | **Integer** | Project id | [optional] 
**title** | **String** | Project title | [optional] 


