# SwaggerClient::ConfidentialityCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **String** | Reason for confidentiality | [optional] 


