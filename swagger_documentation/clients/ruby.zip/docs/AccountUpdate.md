# SwaggerClient::AccountUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_id** | **Integer** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | 
**is_active** | **BOOLEAN** | Is account active | 


