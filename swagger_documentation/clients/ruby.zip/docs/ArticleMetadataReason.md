# SwaggerClient::ArticleMetadataReason

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_metadata_record** | **BOOLEAN** | True if the article is metadata record | [optional] 


