# SwaggerClient::LocationWarnings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entity_id** | **Integer** | Figshare ID of the entity | 
**location** | **String** | Url for entity | 
**warnings** | **Array&lt;String&gt;** | Issues encountered during the operation | 


