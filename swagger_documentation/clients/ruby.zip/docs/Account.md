# SwaggerClient::Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Account id | 
**first_name** | **String** | First Name | 
**last_name** | **String** | Last Name | 
**used_quota_private** | **Integer** | Account used private quota | 
**modified_date** | **String** | Date of last account modification | 
**used_quota** | **Integer** | Account total used quota | 
**created_date** | **String** | Date when account was created | 
**quota** | **Integer** | Account quota | 
**group_id** | **Integer** | Account group id | 
**institution_user_id** | **String** | Account institution user id | 
**institution_id** | **Integer** | Account institution | 
**email** | **String** | User email | 
**used_quota_public** | **Integer** | Account public used quota | 
**pending_quota_request** | **BOOLEAN** | True if a quota request is pending | 
**active** | **Integer** | Account activity status | 
**maximum_file_size** | **Integer** | Maximum upload size for account | 


