# SwaggerClient::ArticleHandle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handle** | **String** | Reserved Handle | [optional] 


