# SwaggerClient::ProfileUpdateData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | **String** | First name | [optional] 
**last_name** | **String** | Last Name | [optional] 
**orcid** | **String** | User ORCID | [optional] 
**job_title** | **String** | User job title | [optional] 
**fields_of_interest** | **Array&lt;Integer&gt;** | User fields of interest (category ids) | [optional] 
**location** | **String** | User location | [optional] 
**facebook** | **String** | User facebook URL | [optional] 
**x** | **String** | User X (twitter) URL | [optional] 
**linkedin** | **String** | User linkedin URL | [optional] 
**bio** | **String** | User biographical information | [optional] 


