# SwaggerClient::ArticleVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Version number | [optional] 
**url** | **String** | Api endpoint for the item version | [optional] 


