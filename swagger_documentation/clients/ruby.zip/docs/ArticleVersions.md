# SwaggerClient::ArticleVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **Integer** | Version number | [optional] 
**url** | **String** | Api endpoint for the item version | [optional] 


