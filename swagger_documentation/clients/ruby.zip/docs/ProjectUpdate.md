# SwaggerClient::ProjectUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** | The title for this project - mandatory. 3 - 1000 characters. | [optional] 
**description** | **String** | Project description | [optional] 
**funding** | **String** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 
**funding_list** | [**Array&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items | [optional] 


