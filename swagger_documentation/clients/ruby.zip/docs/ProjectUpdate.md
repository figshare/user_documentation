# SwaggerClient::ProjectUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** | The title for this project - mandatory. 3 - 1000 characters. | [optional] 
**description** | **String** | Project description | [optional] 
**funding** | **String** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 
**funding_list** | [**Array&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items | [optional] 
**custom_fields** | **Object** | List of key, values pairs to be associated with the project | [optional] 
**custom_fields_list** | [**Array&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values, supersedes custom_fields parameter | [optional] 


